# /anti-piratage

Commande administrateur persistante pour créer un salon piège anti-comptes compromis / arnaques.

## Configuration

Utilise `/anti-piratage action:Configurer / modifier` puis choisis :
- `salon` : salon texte surveillé ;
- `sanction` : ban définitif, exclusion ou muet 1 jour ;
- `raison` : raison de modération facultative ;
- `titre` : titre personnalisé de l'embed ;
- `texte` : texte personnalisé de l'embed ;
- `couleur` : couleur HEX facultative.

Le bot publie et tente d'épingler l'embed d'avertissement. La configuration est stockée dans SQLite et reste active après redémarrage.

Tout message d'un membre non-administrateur dans le salon configuré est supprimé puis déclenche automatiquement la sanction choisie. Le propriétaire du serveur, les administrateurs, les bots et webhooks sont ignorés.

## Autres actions

- `/anti-piratage action:Statut`
- `/anti-piratage action:Désactiver`

## Permissions du bot

Selon la sanction choisie, le bot doit disposer de :
- Voir le salon / Envoyer des messages / Gérer les messages ;
- Bannir des membres pour le ban ;
- Expulser des membres pour l'exclusion ;
- Modérer les membres pour le muet 1 jour ;
- Gérer les messages pour épingler l'avertissement.

Le rôle du bot doit être placé au-dessus des membres qu'il doit modérer.
