import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder,
    Events,
    ModalBuilder,
    PermissionsBitField,
    TextInputBuilder,
    TextInputStyle
} from "discord.js";

export function installAutorank(client) {
    const ROLE_AMBASSADOR = "1536231480957735042";
    const ROLE_AGENT = "1536231480047444048";
    const ROLE_MANAGER = "1536231478843809842";
    const ROLE_DIRECTOR = "1536231476687933450";
    const ROLE_FOUNDER = "1536231475694014526";
    const ROLE_COMMUNITY_CM = "1536231477531123795";

    const ROLE_EXTRA_AFTER_VALIDATION = "1536231491779035158";
    const ROLE_AUTORANK_VALIDATOR = "1539254411728265499";
    const LOG_CHANNEL_ID = "1536231686549803011";
    const FORM_EXPIRATION_MS = 15 * 60 * 1000;

    const pendingForms = new Map();

    const autorankChoices = {
    ambassadeur: {
        name: "Ambassadeur",
        roleId: ROLE_AMBASSADOR
    },
    agent: {
        name: "Agent",
        roleId: ROLE_AGENT
    },
    directeur: {
        name: "Directeur",
        roleId: ROLE_DIRECTOR
    },
    manager: {
        name: "Manager",
        roleId: ROLE_MANAGER
    },
    fondateur: {
        name: "Fondateur",
        roleId: ROLE_FOUNDER
    },
    communitycm: {
        name: "Community CM",
        roleId: ROLE_COMMUNITY_CM
    }
};

    const getFormKey = (guildId, userId) => `${guildId}:${userId}`;

    function canValidate(interaction) {
        const isAdministrator = interaction.member.permissions.has(
            PermissionsBitField.Flags.Administrator
        );

        const hasValidatorRole =
            ROLE_AUTORANK_VALIDATOR !== "REMPLACE_PAR_ID_ROLE_VALIDATEUR" &&
            interaction.member.roles.cache.has(ROLE_AUTORANK_VALIDATOR);

        return isAdministrator || hasValidatorRole;
    }

    async function privateReply(interaction, content) {
        const payload = { content, ephemeral: true };
        if (interaction.replied || interaction.deferred) {
            return interaction.followUp(payload).catch(() => null);
        }
        return interaction.reply(payload).catch(() => null);
    }

    client.on(Events.InteractionCreate, async (interaction) => {
        try {
            if (interaction.isChatInputCommand() && interaction.commandName === "autorank") {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`autorank:open:${interaction.user.id}`)
                        .setLabel("Ouvrir le formulaire")
                        .setEmoji("📋")
                        .setStyle(ButtonStyle.Primary)
                );

                return interaction.reply({
                    content: "📋 Clique sur le bouton pour remplir ton formulaire d'autorank.",
                    components: [row],
                    ephemeral: true,
                });
            }

            if (interaction.isButton() && interaction.customId.startsWith("autorank:open:")) {
                const [, , ownerId] = interaction.customId.split(":");
                if (interaction.user.id !== ownerId) {
                    return privateReply(interaction, "❌ Ce formulaire ne t'appartient pas.");
                }

                const modal = new ModalBuilder()
                    .setCustomId(`autorank:form:${interaction.user.id}`)
                    .setTitle("Formulaire Autorank")
                    .addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId("pseudo")
                                .setLabel("Pseudo")
                                .setPlaceholder("Entre ton pseudo")
                                .setStyle(TextInputStyle.Short)
                                .setMinLength(2)
                                .setMaxLength(50)
                                .setRequired(true)
                        ),
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId("agence")
                                .setLabel("Agence")
                                .setPlaceholder("Entre le nom de ton agence")
                                .setStyle(TextInputStyle.Short)
                                .setMinLength(2)
                                .setMaxLength(100)
                                .setRequired(true)
                        )
                    );

                return interaction.showModal(modal);
            }

            if (interaction.isModalSubmit() && interaction.customId.startsWith("autorank:form:")) {
                const [, , ownerId] = interaction.customId.split(":");
                if (interaction.user.id !== ownerId) {
                    return privateReply(interaction, "❌ Ce formulaire ne t'appartient pas.");
                }

                const pseudo = interaction.fields.getTextInputValue("pseudo").trim();
                const agence = interaction.fields.getTextInputValue("agence").trim();
                const key = getFormKey(interaction.guildId, interaction.user.id);

                pendingForms.set(key, {
                    pseudo,
                    agence,
                    userId: interaction.user.id,
                    guildId: interaction.guildId,
                    createdAt: Date.now(),
                });

const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
        .setCustomId(`autorank:choice:agent:${interaction.user.id}`)
        .setLabel("Agent")
        .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
        .setCustomId(`autorank:choice:directeur:${interaction.user.id}`)
        .setLabel("Directeur")
        .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
        .setCustomId(`autorank:choice:manager:${interaction.user.id}`)
        .setLabel("Manager")
        .setStyle(ButtonStyle.Secondary)
);

const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
        .setCustomId(`autorank:choice:fondateur:${interaction.user.id}`)
        .setLabel("Fondateur")
        .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
        .setCustomId(`autorank:choice:ambassadeur:${interaction.user.id}`)
        .setLabel("Ambassadeur")
        .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
        .setCustomId(`autorank:choice:communitycm:${interaction.user.id}`)
        .setLabel("Community CM")
        .setStyle(ButtonStyle.Secondary)
);

                return interaction.reply({
                    content: `Merci **${pseudo}** ! Choisis maintenant ton **rôle d'agence** :`,
                    components: [row1,row2],
                    ephemeral: true,
                });
            }

            if (interaction.isButton() && interaction.customId.startsWith("autorank:choice:")) {
                const [, , choiceKey, ownerId] = interaction.customId.split(":");
                if (interaction.user.id !== ownerId) {
                    return privateReply(interaction, "❌ Ces boutons ne t'appartiennent pas.");
                }

                const selectedRole = autorankChoices[choiceKey];
                if (!selectedRole) {
                    return privateReply(interaction, "❌ Le rôle choisi est invalide.");
                }

                const key = getFormKey(interaction.guildId, interaction.user.id);
                const data = pendingForms.get(key);
                if (!data) {
                    return interaction.update({
                        content: "❌ Le formulaire a expiré. Recommence avec `/autorank`.",
                        components: [],
                    });
                }

                const logChannel = interaction.guild.channels.cache.get(LOG_CHANNEL_ID);
                if (!logChannel?.isTextBased()) {
                    return privateReply(interaction, "❌ Le salon de validation est introuvable.");
                }

                const requestEmbed = new EmbedBuilder()
                    .setTitle("Nouvel autorank à valider")
                    .setColor("#7A00FF")
                    .setThumbnail(interaction.user.displayAvatarURL())
                    .addFields(
                        { name: "Pseudo", value: data.pseudo, inline: true },
                        { name: "Agence", value: data.agence, inline: true },
                        { name: "Rôle demandé", value: selectedRole.name, inline: true },
                        { name: "Utilisateur", value: `${interaction.user}\n\`${interaction.user.id}\`` }
                    )
                    .setFooter({ text: `Demande de ${interaction.user.tag}` })
                    .setTimestamp();

                const adminRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`autorank:accept:${interaction.user.id}:${selectedRole.roleId}`)
                        .setLabel("Accepter")
                        .setEmoji("✅")
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId(`autorank:deny:${interaction.user.id}:${selectedRole.roleId}`)
                        .setLabel("Refuser")
                        .setEmoji("❌")
                        .setStyle(ButtonStyle.Danger)
                );

                await logChannel.send({ embeds: [requestEmbed], components: [adminRow] });
                pendingForms.delete(key);

                await interaction.update({
                    content: `🕒 Ta demande pour le rôle **${selectedRole.name}** a été envoyée à l'administration.`,
                    components: [],
                });

                setTimeout(() => interaction.deleteReply().catch(() => null), 5000);
                return;
            }

            if (
                interaction.isButton() &&
                (interaction.customId.startsWith("autorank:accept:") ||
                 interaction.customId.startsWith("autorank:deny:"))
            ) {
                if (!canValidate(interaction)) {
                    return privateReply(interaction, "❌ Tu n'as pas la permission de traiter cette demande.");
                }

                const [, action, userId, roleId] = interaction.customId.split(":");
                if (!['accept', 'deny'].includes(action) || !/^\d+$/.test(userId) || !/^\d+$/.test(roleId)) {
                    return privateReply(interaction, "❌ Les informations du bouton sont invalides.");
                }

                const member = await interaction.guild.members.fetch(userId).catch(() => null);
                if (!member) {
                    return privateReply(interaction, "❌ Le membre est introuvable ou a quitté le serveur.");
                }

                const originalEmbed = interaction.message.embeds[0];
                if (!originalEmbed) {
                    return privateReply(interaction, "❌ L'embed de la demande est introuvable.");
                }

                if (action === "accept") {
                    const requestedRole = interaction.guild.roles.cache.get(roleId);
                    const extraRole = interaction.guild.roles.cache.get(ROLE_EXTRA_AFTER_VALIDATION);
                    if (!requestedRole || !extraRole) {
                        return privateReply(interaction, "❌ Un des rôles configurés est introuvable.");
                    }

                    const botMember = interaction.guild.members.me;
                    if (
                        requestedRole.position >= botMember.roles.highest.position ||
                        extraRole.position >= botMember.roles.highest.position
                    ) {
                        return privateReply(interaction, "❌ Le rôle du bot doit être placé au-dessus des deux rôles à attribuer.");
                    }

                    await member.roles.add(
                        [requestedRole.id, extraRole.id],
                        `Autorank validé par ${interaction.user.tag}`
                    );

                    const acceptedEmbed = EmbedBuilder.from(originalEmbed)
                        .setTitle("Autorank accepté")
                        .setColor("#57F287")
                        .addFields({
                            name: "Décision",
                            value: `✅ Accepté par ${interaction.user}\nRôles attribués : ${requestedRole} et ${extraRole}`,
                        });

                    await interaction.update({ embeds: [acceptedEmbed], components: [] });
                    await member.send(
                        `🎉 Ton autorank sur **${interaction.guild.name}** a été accepté.\n` +
                        `Tu as reçu les rôles **${requestedRole.name}** et **${extraRole.name}**.`
                    ).catch(() => null);
                    return;
                }

                const deniedEmbed = EmbedBuilder.from(originalEmbed)
                    .setTitle("Autorank refusé")
                    .setColor("#ED4245")
                    .addFields({
                        name: "Décision",
                        value: `❌ Refusé par ${interaction.user}`,
                    });

                await interaction.update({ embeds: [deniedEmbed], components: [] });
                await member.send(
                    `⚠️ Ton autorank sur **${interaction.guild.name}** a été refusé par l'administration.`
                ).catch(() => null);
            }
        } catch (error) {
            console.error("Erreur Autorank :", error);
            if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: "❌ Une erreur est survenue pendant l'autorank.",
                    ephemeral: true,
                }).catch(() => null);
            }
        }
    });

    setInterval(() => {
        const now = Date.now();
        for (const [key, data] of pendingForms.entries()) {
            if (now - data.createdAt >= FORM_EXPIRATION_MS) pendingForms.delete(key);
        }
    }, 5 * 60 * 1000);
}
