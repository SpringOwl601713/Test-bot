import fs from "node:fs";
import path from "node:path";
import { ChannelType, PermissionFlagsBits } from "discord.js";

const dataFile = path.resolve(process.cwd(), "data/security.json");

function loadData() {
    try {
        if (!fs.existsSync(dataFile)) return {};
        return JSON.parse(fs.readFileSync(dataFile, "utf8"));
    } catch (error) {
        console.error("❌ Impossible de lire data/security.json :", error);
        return {};
    }
}

function saveData(data) {
    try {
        fs.mkdirSync(path.dirname(dataFile), { recursive: true });
        fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error("❌ Impossible d'écrire data/security.json :", error);
    }
}

export class SecurityManager {
    constructor(client) {
        this.client = client;
        this.data = loadData();
        this.joinHistory = new Map();
        this.autoLockInProgress = new Set();
    }

    get(guildId) {
        const current = this.data[guildId] || {};
        return {
            antiRaidEnabled: Boolean(current.antiRaidEnabled),
            joinThreshold: Number(current.joinThreshold) || 6,
            windowSeconds: Number(current.windowSeconds) || 10,
            locked: Boolean(current.locked),
            lockReason: current.lockReason || null,
            lockedAt: current.lockedAt || null,
            previousSendMessages: current.previousSendMessages || {}
        };
    }

    update(guildId, patch) {
        this.data[guildId] = { ...this.get(guildId), ...patch };
        saveData(this.data);
        return this.get(guildId);
    }

    setAntiRaid(guildId, enabled, { threshold, windowSeconds } = {}) {
        return this.update(guildId, {
            antiRaidEnabled: Boolean(enabled),
            joinThreshold: Math.max(3, Math.min(30, Number(threshold) || this.get(guildId).joinThreshold)),
            windowSeconds: Math.max(3, Math.min(60, Number(windowSeconds) || this.get(guildId).windowSeconds))
        });
    }

    async lockGuild(guild, reason = "Verrouillage de sécurité") {
        const settings = this.get(guild.id);
        if (settings.locked) return { alreadyLocked: true, changed: 0, failed: 0 };

        const me = guild.members.me;
        if (!me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
            throw new Error("MISSING_MANAGE_CHANNELS");
        }

        const previous = {};
        let changed = 0;
        let failed = 0;

        const channels = [...guild.channels.cache.values()].filter(channel =>
            channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildAnnouncement
        );

        for (const channel of channels) {
            try {
                const overwrite = channel.permissionOverwrites.cache.get(guild.roles.everyone.id);
                const allowed = overwrite?.allow?.has(PermissionFlagsBits.SendMessages) ?? false;
                const denied = overwrite?.deny?.has(PermissionFlagsBits.SendMessages) ?? false;
                previous[channel.id] = allowed ? true : denied ? false : null;

                await channel.permissionOverwrites.edit(
                    guild.roles.everyone,
                    { SendMessages: false },
                    { reason }
                );
                changed++;
            } catch (error) {
                failed++;
                console.warn(`⚠️ Impossible de verrouiller #${channel.name}:`, error?.message || error);
            }
        }

        this.update(guild.id, {
            locked: true,
            lockReason: reason,
            lockedAt: Date.now(),
            previousSendMessages: previous
        });

        return { alreadyLocked: false, changed, failed };
    }

    async unlockGuild(guild, reason = "Fin du verrouillage de sécurité") {
        const settings = this.get(guild.id);
        if (!settings.locked) return { alreadyUnlocked: true, changed: 0, failed: 0 };

        const me = guild.members.me;
        if (!me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
            throw new Error("MISSING_MANAGE_CHANNELS");
        }

        let changed = 0;
        let failed = 0;

        for (const [channelId, oldValue] of Object.entries(settings.previousSendMessages || {})) {
            const channel = guild.channels.cache.get(channelId);
            if (!channel) continue;

            try {
                await channel.permissionOverwrites.edit(
                    guild.roles.everyone,
                    { SendMessages: oldValue === null ? null : oldValue },
                    { reason }
                );
                changed++;
            } catch (error) {
                failed++;
                console.warn(`⚠️ Impossible de restaurer #${channel.name}:`, error?.message || error);
            }
        }

        this.update(guild.id, {
            locked: false,
            lockReason: null,
            lockedAt: null,
            previousSendMessages: {}
        });

        return { alreadyUnlocked: false, changed, failed };
    }

    async handleMemberJoin(member) {
        const guildId = member.guild.id;
        const settings = this.get(guildId);
        if (!settings.antiRaidEnabled || settings.locked) return;

        const now = Date.now();
        const cutoff = now - settings.windowSeconds * 1000;
        const history = (this.joinHistory.get(guildId) || []).filter(ts => ts >= cutoff);
        history.push(now);
        this.joinHistory.set(guildId, history);

        if (history.length < settings.joinThreshold || this.autoLockInProgress.has(guildId)) return;

        this.autoLockInProgress.add(guildId);
        try {
            const result = await this.lockGuild(
                member.guild,
                `Anti-raid Nexora : ${history.length} arrivées en ${settings.windowSeconds}s`
            );
            console.warn(
                `🛡️ Anti-raid déclenché sur ${member.guild.name}: ${history.length} arrivées, ${result.changed} salon(s) verrouillé(s).`
            );
        } catch (error) {
            console.error("❌ Anti-raid : verrouillage automatique impossible :", error);
        } finally {
            this.autoLockInProgress.delete(guildId);
        }
    }
}
