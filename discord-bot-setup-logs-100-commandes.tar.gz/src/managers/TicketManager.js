import fs from "node:fs";
import path from "node:path";
import {
    ActionRowBuilder,
    AttachmentBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType,
    EmbedBuilder,
    PermissionFlagsBits,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder
} from "discord.js";
import db from "../database/Database.js";

const imageDir = path.resolve("./data/ticket-images");
fs.mkdirSync(imageDir, { recursive: true });

function safeExt(name = "image.png", contentType = "") {
    const ext = path.extname(name).toLowerCase();
    if ([".png", ".jpg", ".jpeg", ".gif", ".webp"].includes(ext)) return ext;
    if (contentType === "image/jpeg") return ".jpg";
    if (contentType === "image/gif") return ".gif";
    if (contentType === "image/webp") return ".webp";
    return ".png";
}

function slug(value) {
    return String(value || "ticket")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9-]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 45) || "ticket";
}

function parseEmoji(raw) {
    if (!raw) return null;
    const value = raw.trim();
    const custom = value.match(/^<a?:([^:]+):(\d+)>$/);
    if (custom) return { name: custom[1], id: custom[2], animated: value.startsWith("<a:") };
    return { name: value };
}

export class TicketManager {
    constructor(client) {
        this.client = client;
    }

    getPanel(guildId, panelName) {
        return db.prepare("SELECT * FROM ticket_panels WHERE guild_id = ? AND panel_name = ? COLLATE NOCASE").get(guildId, panelName) || null;
    }

    getPanelById(panelId) {
        return db.prepare("SELECT * FROM ticket_panels WHERE id = ?").get(panelId) || null;
    }

    listPanels(guildId) {
        return db.prepare("SELECT * FROM ticket_panels WHERE guild_id = ? ORDER BY panel_name COLLATE NOCASE").all(guildId);
    }

    getOptions(panelId) {
        return db.prepare("SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY position ASC, id ASC").all(panelId);
    }

    async configurePanel(guild, { panelName, channelId, categoryId, transcriptChannelId, title, description, color, image }) {
        const existing = this.getPanel(guild.id, panelName);
        let imagePath = existing?.image_path || null;

        if (image) {
            const response = await fetch(image.url);
            if (!response.ok) throw new Error("Impossible de télécharger l’image envoyée.");
            const buffer = Buffer.from(await response.arrayBuffer());
            if (buffer.length > 10 * 1024 * 1024) throw new Error("Image trop volumineuse (10 Mo max).");
            const ext = safeExt(image.name, image.contentType);
            const fileBase = `${guild.id}-${slug(panelName)}`;
            imagePath = path.join(imageDir, `${fileBase}${ext}`);
            for (const oldExt of [".png", ".jpg", ".jpeg", ".gif", ".webp"]) {
                const old = path.join(imageDir, `${fileBase}${oldExt}`);
                if (old !== imagePath && fs.existsSync(old)) fs.rmSync(old, { force: true });
            }
            fs.writeFileSync(imagePath, buffer);
        }

        db.prepare(`
            INSERT INTO ticket_panels (
                guild_id, panel_name, enabled, channel_id, category_id, message_id,
                embed_title, embed_description, embed_color, image_path, transcript_channel_id, updated_at
            ) VALUES (?, ?, 1, ?, ?, NULL, ?, ?, ?, ?, ?, unixepoch())
            ON CONFLICT(guild_id, panel_name) DO UPDATE SET
                enabled=1,
                channel_id=excluded.channel_id,
                category_id=excluded.category_id,
                embed_title=excluded.embed_title,
                embed_description=excluded.embed_description,
                embed_color=excluded.embed_color,
                image_path=excluded.image_path,
                transcript_channel_id=excluded.transcript_channel_id,
                updated_at=unixepoch()
        `).run(guild.id, panelName, channelId, categoryId || null, title, description, color, imagePath, transcriptChannelId || null);

        return this.getPanel(guild.id, panelName);
    }

    addOption(panelId, { label, description, emoji, supportRoleId }) {
        const count = this.getOptions(panelId).length;
        if (count >= 25) throw new Error("Discord limite un menu à 25 demandes.");
        db.prepare(`
            INSERT INTO ticket_options (panel_id, label, description, emoji, support_role_id, position)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(panel_id, label) DO UPDATE SET
                description=excluded.description,
                emoji=excluded.emoji,
                support_role_id=excluded.support_role_id
        `).run(panelId, label, description || null, emoji || null, supportRoleId || null, count);
    }

    removeOption(panelId, label) {
        return db.prepare("DELETE FROM ticket_options WHERE panel_id = ? AND label = ? COLLATE NOCASE").run(panelId, label).changes > 0;
    }

    setEnabled(panelId, enabled) {
        db.prepare("UPDATE ticket_panels SET enabled = ?, updated_at = unixepoch() WHERE id = ?").run(enabled ? 1 : 0, panelId);
    }

    deletePanel(panelId) {
        db.prepare("DELETE FROM ticket_panels WHERE id = ?").run(panelId);
    }

    buildPanelComponents(panel, options) {
        if (!options.length) return [];
        const menu = new StringSelectMenuBuilder()
            .setCustomId(`ticket:open:${panel.id}`)
            .setPlaceholder("Sélectionnez une catégorie...")
            .setMinValues(1)
            .setMaxValues(1)
            .setDisabled(!panel.enabled);

        for (const item of options.slice(0, 25)) {
            const option = new StringSelectMenuOptionBuilder()
                .setLabel(item.label)
                .setValue(String(item.id));
            if (item.description) option.setDescription(item.description.slice(0, 100));
            if (item.emoji) {
                const parsed = parseEmoji(item.emoji);
                if (parsed) option.setEmoji(parsed);
            }
            menu.addOptions(option);
        }

        return [new ActionRowBuilder().addComponents(menu)];
    }

    async publishPanel(guild, panel) {
        const channel = guild.channels.cache.get(panel.channel_id) || await guild.channels.fetch(panel.channel_id).catch(() => null);
        if (!channel?.isTextBased?.()) throw new Error("Le salon configuré n’existe plus ou n’est pas textuel.");
        const options = this.getOptions(panel.id);
        if (!options.length) throw new Error("Ajoute au moins une demande avant de publier le panneau.");

        const embed = new EmbedBuilder()
            .setColor(parseInt(panel.embed_color || "5865F2", 16))
            .setTitle(panel.embed_title || "🎫 Support")
            .setDescription(panel.embed_description || "Sélectionnez une catégorie pour ouvrir un ticket.")
            .setTimestamp();

        const payload = {
            embeds: [embed],
            components: this.buildPanelComponents(panel, options),
            allowedMentions: { parse: [] }
        };

        if (panel.image_path && fs.existsSync(panel.image_path)) {
            const filename = `ticket-panel${path.extname(panel.image_path) || ".png"}`;
            payload.files = [new AttachmentBuilder(panel.image_path, { name: filename })];
            embed.setImage(`attachment://${filename}`);
        }

        let message = null;
        if (panel.message_id) message = await channel.messages.fetch(panel.message_id).catch(() => null);
        if (message) {
            await message.edit(payload);
        } else {
            message = await channel.send(payload);
            db.prepare("UPDATE ticket_panels SET message_id = ?, updated_at = unixepoch() WHERE id = ?").run(message.id, panel.id);
        }
        return message;
    }

    async handleOpen(interaction) {
        const panelId = Number(interaction.customId.split(":")[2]);
        const optionId = Number(interaction.values?.[0]);
        const panel = this.getPanelById(panelId);
        if (!panel || panel.guild_id !== interaction.guild.id || !panel.enabled) {
            return interaction.reply({ content: "❌ Ce panneau de tickets est désactivé ou introuvable.", ephemeral: true });
        }
        const option = db.prepare("SELECT * FROM ticket_options WHERE id = ? AND panel_id = ?").get(optionId, panelId);
        if (!option) return interaction.reply({ content: "❌ Cette demande n’existe plus.", ephemeral: true });

        const existing = db.prepare("SELECT * FROM ticket_opened WHERE panel_id = ? AND option_id = ? AND user_id = ? AND closed = 0").get(panelId, optionId, interaction.user.id);
        if (existing) {
            const existingChannel = interaction.guild.channels.cache.get(existing.channel_id) || await interaction.guild.channels.fetch(existing.channel_id).catch(() => null);
            if (existingChannel) {
                return interaction.reply({ content: `ℹ️ Tu as déjà un ticket ouvert pour cette demande : <#${existing.channel_id}>`, ephemeral: true });
            }
            db.prepare("UPDATE ticket_opened SET closed = 1 WHERE id = ?").run(existing.id);
        }

        await interaction.deferReply({ ephemeral: true });
        const me = interaction.guild.members.me;
        if (!me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return interaction.editReply("❌ Le bot doit avoir la permission **Gérer les salons** pour créer des tickets.");
        }

        const overwrites = [
            { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.EmbedLinks] },
            { id: me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages] }
        ];
        if (option.support_role_id) {
            overwrites.push({ id: option.support_role_id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] });
        }

        const channel = await interaction.guild.channels.create({
            name: `${slug(option.label)}-${slug(interaction.user.username)}`.slice(0, 90),
            type: ChannelType.GuildText,
            parent: panel.category_id || undefined,
            topic: `Ticket ${option.label} • ${interaction.user.tag} (${interaction.user.id})`,
            permissionOverwrites: overwrites,
            reason: `Ticket ouvert par ${interaction.user.tag}`
        });

        db.prepare(`INSERT INTO ticket_opened (panel_id, option_id, guild_id, channel_id, user_id, closed, created_at) VALUES (?, ?, ?, ?, ?, 0, unixepoch())`)
            .run(panelId, optionId, interaction.guild.id, channel.id, interaction.user.id);

        const welcome = new EmbedBuilder()
            .setColor(parseInt(panel.embed_color || "5865F2", 16))
            .setTitle(`🎫 ${option.label}`)
            .setDescription(`${interaction.user}, ton ticket est ouvert.\n\n${option.description || "Explique ta demande ici et l’équipe te répondra dès que possible."}`)
            .setFooter({ text: panel.panel_name })
            .setTimestamp();

        const close = new ButtonBuilder()
            .setCustomId(`ticket:close:${channel.id}`)
            .setLabel("Fermer le ticket")
            .setEmoji("🔒")
            .setStyle(ButtonStyle.Danger);

        await channel.send({
            content: option.support_role_id ? `<@&${option.support_role_id}>` : undefined,
            embeds: [welcome],
            components: [new ActionRowBuilder().addComponents(close)],
            allowedMentions: option.support_role_id ? { roles: [option.support_role_id] } : { parse: [] }
        });

        return interaction.editReply(`✅ Ton ticket a été créé : <#${channel.id}>`);
    }


    escapeHtml(value) {
        return String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[char]));
    }

    async fetchAllMessages(channel) {
        const all = [];
        let before;
        while (true) {
            const batch = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) });
            if (!batch.size) break;
            all.push(...batch.values());
            before = batch.last().id;
            if (batch.size < 100) break;
        }
        return all.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
    }

    async createTranscript(channel, row, panel, option, closedBy) {
        const messages = await this.fetchAllMessages(channel);
        const openedAt = new Date((row.created_at || Math.floor(Date.now()/1000)) * 1000);
        const closedAt = new Date();
        const lines = messages.map(message => {
            const author = this.escapeHtml(message.author?.tag || message.author?.username || "Utilisateur inconnu");
            const avatar = this.escapeHtml(message.author?.displayAvatarURL?.({ size: 64 }) || "");
            const time = new Date(message.createdTimestamp).toLocaleString("fr-FR");
            const content = this.escapeHtml(message.cleanContent || message.content || "").replace(/\n/g, "<br>");
            const attachments = [...message.attachments.values()].map(a => `<div class="attachment">📎 <a href="${this.escapeHtml(a.url)}">${this.escapeHtml(a.name || "Pièce jointe")}</a></div>`).join("");
            const embeds = message.embeds?.length ? `<div class="embed-note">${message.embeds.length} embed(s) Discord dans ce message</div>` : "";
            return `<article><img src="${avatar}" alt=""><div><header><b>${author}</b><time>${time}</time></header><div class="content">${content || "<i>(sans texte)</i>"}</div>${attachments}${embeds}</div></article>`;
        }).join("\n");
        return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Transcript ${this.escapeHtml(channel.name)}</title><style>body{font-family:Arial,sans-serif;background:#111318;color:#e7e9ee;margin:0;padding:24px}.wrap{max-width:900px;margin:auto}.meta,article{background:#1e2128;border:1px solid #30343d;border-radius:12px;padding:16px;margin:12px 0}article{display:grid;grid-template-columns:48px 1fr;gap:12px}article img{width:42px;height:42px;border-radius:50%}header{display:flex;gap:12px;align-items:baseline}time{color:#9aa1ad;font-size:12px}.content{margin-top:8px;line-height:1.45}.attachment,.embed-note{margin-top:8px;color:#b7bdc8}a{color:#8ea1ff}h1{margin-bottom:4px}.muted{color:#9aa1ad}</style></head><body><div class="wrap"><h1>Transcript — #${this.escapeHtml(channel.name)}</h1><div class="meta"><b>Panneau :</b> ${this.escapeHtml(panel?.panel_name || "Inconnu")}<br><b>Demande :</b> ${this.escapeHtml(option?.label || "Inconnue")}<br><b>Ouvert par :</b> ${this.escapeHtml(row.user_id)}<br><b>Ouvert le :</b> ${openedAt.toLocaleString("fr-FR")}<br><b>Fermé par :</b> ${this.escapeHtml(closedBy.tag || closedBy.username)} (${this.escapeHtml(closedBy.id)})<br><b>Fermé le :</b> ${closedAt.toLocaleString("fr-FR")}<br><b>Messages :</b> ${messages.length}</div>${lines || '<div class="meta muted">Aucun message.</div>'}</div></body></html>`;
    }

    async handleClose(interaction) {
        const channelId = interaction.customId.split(":")[2];
        if (interaction.channelId !== channelId) return interaction.reply({ content: "❌ Ticket invalide.", ephemeral: true });
        const row = db.prepare("SELECT * FROM ticket_opened WHERE guild_id = ? AND channel_id = ? AND closed = 0").get(interaction.guild.id, channelId);
        if (!row) return interaction.reply({ content: "ℹ️ Ce ticket est déjà fermé ou non suivi.", ephemeral: true });

        const panel = this.getPanelById(row.panel_id);
        const option = db.prepare("SELECT * FROM ticket_options WHERE id = ?").get(row.option_id);
        const member = interaction.member;
        const canClose = interaction.user.id === row.user_id ||
            member?.permissions?.has(PermissionFlagsBits.ManageChannels) ||
            (option?.support_role_id && member?.roles?.cache?.has(option.support_role_id));
        if (!canClose) return interaction.reply({ content: "❌ Tu n’as pas la permission de fermer ce ticket.", ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        let transcriptSent = false;
        let transcriptError = null;
        if (panel?.transcript_channel_id) {
            try {
                const logChannel = interaction.guild.channels.cache.get(panel.transcript_channel_id) || await interaction.guild.channels.fetch(panel.transcript_channel_id).catch(() => null);
                if (!logChannel?.isTextBased?.()) throw new Error("Le salon de transcripts configuré est introuvable.");
                const html = await this.createTranscript(interaction.channel, row, panel, option, interaction.user);
                const filename = `transcript-${slug(panel.panel_name)}-${channelId}.html`;
                const file = new AttachmentBuilder(Buffer.from(html, "utf8"), { name: filename });
                const summary = new EmbedBuilder()
                    .setColor(0x5865F2)
                    .setTitle("📄 Transcript de ticket")
                    .setDescription(`**Panneau :** ${panel.panel_name}\n**Demande :** ${option?.label || "Inconnue"}\n**Ouvert par :** <@${row.user_id}>\n**Fermé par :** ${interaction.user}\n**Salon :** #${interaction.channel.name}`)
                    .setTimestamp();
                await logChannel.send({ embeds: [summary], files: [file], allowedMentions: { parse: [] } });
                transcriptSent = true;
            } catch (error) {
                transcriptError = error;
                console.error("❌ Transcript ticket :", error);
            }
        }

        db.prepare("UPDATE ticket_opened SET closed = 1, closed_at = unixepoch() WHERE id = ?").run(row.id);
        await interaction.editReply(transcriptSent
            ? "🔒 Ticket fermé. 📄 Transcript enregistré. Le salon sera supprimé dans quelques secondes."
            : panel?.transcript_channel_id
                ? `🔒 Ticket fermé, mais le transcript n’a pas pu être envoyé (${transcriptError?.message || "erreur inconnue"}). Le salon sera supprimé dans quelques secondes.`
                : "🔒 Ticket fermé. Aucun salon de transcripts n’est configuré pour ce panneau. Le salon sera supprimé dans quelques secondes.");
        setTimeout(() => {
            interaction.channel?.delete(`Ticket fermé par ${interaction.user.tag}`).catch(() => {});
        }, 5000);
    }
}
