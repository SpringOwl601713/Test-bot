import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from "discord.js";
import fs from "node:fs";
import path from "node:path";

const FILE = path.resolve("data/giveaways.json");

function parseDuration(raw) {
  const m = String(raw || "").trim().toLowerCase().match(/^(\d+)\s*(s|m|h|d|j)$/);
  if (!m) return null;
  const n = Number(m[1]);
  const mult = { s:1000, m:60000, h:3600000, d:86400000, j:86400000 }[m[2]];
  const ms = n * mult;
  return ms >= 10000 && ms <= 30 * 86400000 ? ms : null;
}

export class GiveawayManager {
  constructor(client) {
    this.client = client;
    this.data = {};
    this.timers = new Map();
    this.load();
  }
  load() { try { this.data = JSON.parse(fs.readFileSync(FILE,"utf8")); } catch { this.data = {}; } }
  save() { fs.mkdirSync(path.dirname(FILE),{recursive:true}); fs.writeFileSync(FILE, JSON.stringify(this.data,null,2)); }
  key(g,m){ return `${g}:${m}`; }
  async start(){
    for (const g of Object.values(this.data)) if (!g.ended) this.schedule(g);
  }
  schedule(g){
    const key=this.key(g.guildId,g.messageId); clearTimeout(this.timers.get(key));
    const delay=Math.max(0, Math.min(g.endAt-Date.now(), 2147483647));
    this.timers.set(key,setTimeout(async()=>{
      if (g.endAt-Date.now()>1000) return this.schedule(g);
      await this.endByIds(g.guildId,g.messageId).catch(console.error);
    },delay));
  }
  row(messageId, disabled=false){
    return new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`giveaway:join:${messageId}`).setLabel("🎉 Participer").setStyle(ButtonStyle.Success).setDisabled(disabled));
  }
  embed(g, ended=false, winners=[]){
    const e=new EmbedBuilder().setTitle(`🎉 Giveaway — ${g.prize}`).setColor(0xFEE75C)
      .setDescription(ended ? `Giveaway terminé !\n\n🏆 **Gagnant(s) :** ${winners.length ? winners.map(x=>`<@${x}>`).join(", ") : "Aucun participant valide."}` : `Clique sur **🎉 Participer** pour tenter ta chance !\n\n🏆 **${g.winnerCount} gagnant(s)**\n⏰ Fin <t:${Math.floor(g.endAt/1000)}:R>\n👥 Participants : **${g.participants.length}**`)
      .setFooter({text:`ID : ${g.messageId || "création..."}`}).setTimestamp(ended ? Date.now() : g.endAt);
    if (g.text) e.addFields({name:"Informations",value:g.text.slice(0,1024)});
    if (g.imageUrl) e.setImage(g.imageUrl);
    return e;
  }
  async create(interaction){
    const duration=parseDuration(interaction.options.getString("durée"));
    if(!duration) return interaction.reply({content:"❌ Durée invalide. Exemples : `30s`, `10m`, `2h`, `3j` (10 secondes à 30 jours).",ephemeral:true});
    const channel=interaction.options.getChannel("salon") || interaction.channel;
    if(!channel?.isTextBased()) return interaction.reply({content:"❌ Choisis un salon textuel.",ephemeral:true});
    const image=interaction.options.getAttachment("image");
    if(image && !(image.contentType?.startsWith("image/") || /\.(png|jpe?g|gif|webp)$/i.test(image.name||""))) return interaction.reply({content:"❌ Le fichier choisi doit être une image.",ephemeral:true});
    await interaction.deferReply({ephemeral:true});
    const g={guildId:interaction.guildId,channelId:channel.id,messageId:null,prize:interaction.options.getString("prix"),winnerCount:interaction.options.getInteger("gagnants"),text:interaction.options.getString("texte")||"",imageUrl:image?.url||null,endAt:Date.now()+duration,participants:[],ended:false,createdBy:interaction.user.id};
    const msg=await channel.send({embeds:[this.embed(g)],components:[this.row("pending")]});
    g.messageId=msg.id; await msg.edit({embeds:[this.embed(g)],components:[this.row(msg.id)]});
    this.data[this.key(g.guildId,g.messageId)]=g; this.save(); this.schedule(g);
    return interaction.editReply(`✅ Giveaway créé dans <#${channel.id}>. ID : \`${msg.id}\``);
  }
  async join(interaction){
    const id=interaction.customId.split(":").pop(), g=this.data[this.key(interaction.guildId,id)];
    if(!g || g.ended || Date.now()>=g.endAt) return interaction.reply({content:"❌ Ce giveaway est terminé.",ephemeral:true});
    if(interaction.user.bot) return interaction.reply({content:"❌ Les bots ne peuvent pas participer.",ephemeral:true});
    const i=g.participants.indexOf(interaction.user.id);
    if(i>=0){ g.participants.splice(i,1); this.save(); await interaction.update({embeds:[this.embed(g)],components:[this.row(g.messageId)]}); return interaction.followUp({content:"↩️ Ta participation a été retirée.",ephemeral:true}); }
    g.participants.push(interaction.user.id); this.save(); await interaction.update({embeds:[this.embed(g)],components:[this.row(g.messageId)]});
    return interaction.followUp({content:"🎉 Participation enregistrée !",ephemeral:true});
  }
  pick(g){
    const pool=[...new Set(g.participants)]; const out=[];
    while(pool.length && out.length<g.winnerCount){ out.push(pool.splice(Math.floor(Math.random()*pool.length),1)[0]); }
    return out;
  }
  async endByIds(guildId,messageId){
    const g=this.data[this.key(guildId,messageId)]; if(!g || g.ended) return null;
    g.ended=true; g.winners=this.pick(g); this.save();
    const channel=await this.client.channels.fetch(g.channelId).catch(()=>null); const msg=channel ? await channel.messages.fetch(g.messageId).catch(()=>null) : null;
    if(msg) await msg.edit({embeds:[this.embed(g,true,g.winners)],components:[this.row(g.messageId,true)]});
    if(channel) await channel.send({content:g.winners.length?`🎉 Félicitations ${g.winners.map(x=>`<@${x}>`).join(", ")} ! Vous gagnez **${g.prize}** !`:`😕 Giveaway **${g.prize}** terminé sans participant valide.`,allowedMentions:{users:g.winners}});
    return g;
  }
  async end(interaction){
    await interaction.deferReply({ephemeral:true}); const g=await this.endByIds(interaction.guildId,interaction.options.getString("id"));
    return interaction.editReply(g?"✅ Giveaway terminé.":"❌ Giveaway introuvable ou déjà terminé.");
  }
  async reroll(interaction){
    const id=interaction.options.getString("id"), g=this.data[this.key(interaction.guildId,id)];
    if(!g || !g.ended) return interaction.reply({content:"❌ Giveaway introuvable ou pas encore terminé.",ephemeral:true});
    const count=interaction.options.getInteger("gagnants") || g.winnerCount;
    const pool=[...new Set(g.participants)].filter(x=>!(g.winners||[]).includes(x)); const winners=[];
    while(pool.length && winners.length<count) winners.push(pool.splice(Math.floor(Math.random()*pool.length),1)[0]);
    if(!winners.length) return interaction.reply({content:"❌ Aucun autre participant disponible.",ephemeral:true});
    const channel=await this.client.channels.fetch(g.channelId).catch(()=>null);
    if(channel) await channel.send({content:`🔄 **Nouveau tirage — ${g.prize}**\n🎉 ${winners.map(x=>`<@${x}>`).join(", ")}`,allowedMentions:{users:winners}});
    return interaction.reply({content:`✅ Nouveau(x) gagnant(s) : ${winners.map(x=>`<@${x}>`).join(", ")}`,ephemeral:true,allowedMentions:{users:winners}});
  }
}
