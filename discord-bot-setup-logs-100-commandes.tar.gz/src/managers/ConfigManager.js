import db from "../database/Database.js";

const getStatement = db.prepare(`
    SELECT
        guild_id AS guildId,
        notify_channel_id AS notifyChannelId,
        ping_role_id AS pingRoleId
    FROM guild_settings
    WHERE guild_id = ?
`);

const upsertStatement = db.prepare(`
    INSERT INTO guild_settings (
        guild_id,
        notify_channel_id,
        ping_role_id,
        updated_at
    )
    VALUES (?, ?, ?, unixepoch())
    ON CONFLICT(guild_id) DO UPDATE SET
        notify_channel_id = excluded.notify_channel_id,
        ping_role_id = excluded.ping_role_id,
        updated_at = unixepoch()
`);

export class ConfigManager {
    static get(guildId) {
        return getStatement.get(guildId) ?? {
            guildId,
            notifyChannelId: null,
            pingRoleId: null
        };
    }

    static update(guildId, patch) {
        const current = this.get(guildId);

        const next = {
            guildId,
            notifyChannelId:
                patch.notifyChannelId !== undefined
                    ? patch.notifyChannelId
                    : current.notifyChannelId,
            pingRoleId:
                patch.pingRoleId !== undefined
                    ? patch.pingRoleId
                    : current.pingRoleId
        };

        upsertStatement.run(
            next.guildId,
            next.notifyChannelId,
            next.pingRoleId
        );

        return next;
    }
}
