import { EmbedBuilder, PermissionFlagsBits } from "discord.js";
import db from "../database/Database.js";

const DEFAULT_TITLE = "🚨 Scam Catcher";
const DEFAULT_DESCRIPTION = "Ce salon sert à attraper les comptes piratés qui diffusent des arnaques. Tout message posté ici déclenche automatiquement la sanction configurée.\n\n**Les administrateurs et le propriétaire du serveur sont protégés et ne sont jamais sanctionnés.**";

function normalizeHex(value) {
    const cleaned = String(value || "EF4444").replace(/^#/, "").trim();
    return /^[0-9a-fA-F]{6}$/.test(cleaned) ? cleaned.toUpperCase() : "EF4444";
}

export class AntiPiracyManager {
    constructor(client) {
        this.client = client;
        this.processing = new Set();
    }

    get(guildId) {
        const row = db.prepare("SELECT * FROM anti_piracy_settings WHERE guild_id = ?").get(guildId);
        if (!row) return null;
        return {
            guildId: row.guild_id,
            enabled: Boolean(row.enabled),
            channelId: row.channel_id,
            action: row.action,
            reason: row.reason,
            embedTitle: row.embed_title,
            embedDescription: row.embed_description,
            embedColor: row.embed_color,
            warningMessageId: row.warning_message_id
        };
    }

    buildEmbed(settings) {
        return new EmbedBuilder()
            .setColor(parseInt(normalizeHex(settings.embedColor), 16))
            .setTitle(settings.embedTitle || DEFAULT_TITLE)
            .setDescription(settings.embedDescription || DEFAULT_DESCRIPTION)
            .setFooter({ text: `Protection automatique • Sanction : ${this.actionLabel(settings.action)}` })
            .setTimestamp();
    }

    actionLabel(action) {
        return ({ ban: "Bannissement définitif", kick: "Exclusion", timeout_1d: "Muet 1 jour" })[action] || action;
    }

    async configure(guild, { channel, action, reason, title, description, color }) {
        const current = this.get(guild.id);
        const settings = {
            guildId: guild.id,
            enabled: true,
            channelId: channel.id,
            action,
            reason: reason || "Message envoyé dans le salon anti-piratage",
            embedTitle: title || DEFAULT_TITLE,
            embedDescription: description || DEFAULT_DESCRIPTION,
            embedColor: normalizeHex(color),
            warningMessageId: current?.warningMessageId || null
        };

        let warningMessage = null;
        if (current?.warningMessageId && current.channelId === channel.id) {
            try { warningMessage = await channel.messages.fetch(current.warningMessageId); } catch {}
        }

        if (warningMessage) {
            await warningMessage.edit({ embeds: [this.buildEmbed(settings)], allowedMentions: { parse: [] } });
        } else {
            warningMessage = await channel.send({ embeds: [this.buildEmbed(settings)], allowedMentions: { parse: [] } });
            try { await warningMessage.pin(`Configuration /anti-piratage`); } catch {}
        }

        settings.warningMessageId = warningMessage.id;
        db.prepare(`
            INSERT INTO anti_piracy_settings
                (guild_id, enabled, channel_id, action, reason, embed_title, embed_description, embed_color, warning_message_id, updated_at)
            VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?, unixepoch())
            ON CONFLICT(guild_id) DO UPDATE SET
                enabled = 1,
                channel_id = excluded.channel_id,
                action = excluded.action,
                reason = excluded.reason,
                embed_title = excluded.embed_title,
                embed_description = excluded.embed_description,
                embed_color = excluded.embed_color,
                warning_message_id = excluded.warning_message_id,
                updated_at = unixepoch()
        `).run(guild.id, channel.id, action, settings.reason, settings.embedTitle, settings.embedDescription, settings.embedColor, settings.warningMessageId);

        return this.get(guild.id);
    }

    disable(guildId) {
        db.prepare("UPDATE anti_piracy_settings SET enabled = 0, updated_at = unixepoch() WHERE guild_id = ?").run(guildId);
        return this.get(guildId);
    }

    async handleMessage(message) {
        if (!message.guild || !message.member || message.author?.bot || message.webhookId) return;
        const settings = this.get(message.guild.id);
        if (!settings?.enabled || message.channelId !== settings.channelId) return;

        const member = message.member;
        if (member.id === message.guild.ownerId) return;
        if (member.permissions.has(PermissionFlagsBits.Administrator)) return;

        const key = `${message.guild.id}:${member.id}`;
        if (this.processing.has(key)) {
            try { if (message.deletable) await message.delete(); } catch {}
            return;
        }
        this.processing.add(key);

        try {
            try { if (message.deletable) await message.delete(); } catch (error) {
                console.error("❌ Anti-piratage : impossible de supprimer le message :", error);
            }

            const reason = settings.reason || "Déclenchement du salon anti-piratage";
            if (settings.action === "ban") {
                if (!member.bannable) throw new Error("MEMBER_NOT_BANNABLE");
                await member.ban({ reason });
            } else if (settings.action === "kick") {
                if (!member.kickable) throw new Error("MEMBER_NOT_KICKABLE");
                await member.kick(reason);
            } else if (settings.action === "timeout_1d") {
                if (!member.moderatable) throw new Error("MEMBER_NOT_MODERATABLE");
                await member.timeout(24 * 60 * 60 * 1000, reason);
            }
        } catch (error) {
            console.error(`❌ Anti-piratage : sanction impossible pour ${member.user.tag} :`, error);
        } finally {
            setTimeout(() => this.processing.delete(key), 3000).unref?.();
        }
    }
}
