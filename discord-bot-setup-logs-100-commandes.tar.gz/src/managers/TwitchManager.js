import { EmbedBuilder } from "discord.js";
import { TwitchAccountManager } from "./TwitchAccountManager.js";

function normalizeLogin(value) {
    return String(value || "")
        .trim()
        .replace(/^https?:\/\/(www\.)?twitch\.tv\//i, "")
        .replace(/^@/, "")
        .split(/[/?#]/)[0]
        .toLowerCase();
}

function fillTemplate(template, data) {
    return String(template || "")
        .replaceAll("{name}", data.name)
        .replaceAll("{login}", data.login)
        .replaceAll("{url}", data.url)
        .replaceAll("{title}", data.title || "")
        .replaceAll("{game}", data.game || "")
        .replaceAll("{viewers}", String(data.viewers ?? 0));
}

function parseColor(value) {
    const normalized = String(value || "9146FF").trim().replace(/^#/, "");
    if (!/^[0-9a-f]{6}$/i.test(normalized)) return 0x9146ff;
    return Number.parseInt(normalized, 16);
}

export class TwitchManager {
    constructor(client, { clientId, clientSecret, intervalMs = 60_000 } = {}) {
        this.client = client;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.intervalMs = Math.max(intervalMs, 30_000);
        this.token = null;
        this.tokenExpiresAt = 0;
        this.cache = new Map();
        this.timer = null;
        this.running = false;
    }

    get configured() {
        return Boolean(this.clientId && this.clientSecret);
    }

    cacheKey(guildId, login) {
        return `${guildId}:${login}`;
    }

    async getAppToken(force = false) {
        if (!force && this.token && Date.now() < this.tokenExpiresAt - 60_000) {
            return this.token;
        }

        const body = new URLSearchParams({
            client_id: this.clientId,
            client_secret: this.clientSecret,
            grant_type: "client_credentials"
        });

        const response = await fetch("https://id.twitch.tv/oauth2/token", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body
        });

        if (!response.ok) {
            throw new Error(`OAuth Twitch ${response.status}: ${await response.text()}`);
        }

        const data = await response.json();
        this.token = data.access_token;
        this.tokenExpiresAt = Date.now() + Number(data.expires_in || 3600) * 1000;
        return this.token;
    }

    async helix(path, retry = true) {
        const token = await this.getAppToken();
        const response = await fetch(`https://api.twitch.tv/helix${path}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                "Client-Id": this.clientId
            }
        });

        if (response.status === 401 && retry) {
            await this.getAppToken(true);
            return this.helix(path, false);
        }

        if (!response.ok) {
            throw new Error(`Twitch Helix ${response.status}: ${await response.text()}`);
        }

        return response.json();
    }

    async resolveUser(login) {
        const clean = normalizeLogin(login);
        if (!clean) return null;
        const data = await this.helix(`/users?login=${encodeURIComponent(clean)}`);
        return data.data?.[0] || null;
    }

    async getStream(userId) {
        const data = await this.helix(`/streams?user_id=${encodeURIComponent(userId)}`);
        return data.data?.[0] || null;
    }

    async configureAccount(guildId, options) {
        if (!this.configured) {
            throw new Error("TWITCH_CLIENT_ID ou TWITCH_CLIENT_SECRET manque dans le .env.");
        }

        const login = normalizeLogin(options.login);
        if (!/^[a-z0-9_]{4,25}$/i.test(login)) {
            throw new Error("Nom Twitch invalide.");
        }

        const user = await this.resolveUser(login);
        if (!user) {
            throw new Error(`Le compte Twitch @${login} est introuvable.`);
        }

        const saved = TwitchAccountManager.upsert(guildId, {
            ...options,
            login,
            twitchUserId: user.id
        });

        const stream = await this.getStream(user.id);
        this.cache.set(this.cacheKey(guildId, login), Boolean(stream));

        if (stream) {
            await this.sendNotification(guildId, saved, stream, user);
        }

        return { account: saved, user, isLive: Boolean(stream) };
    }

    async sendNotification(guildId, account, stream, knownUser = null) {
        const channel = await this.client.channels.fetch(account.notifyChannelId).catch(() => null);
        if (!channel?.isTextBased() || !("send" in channel)) return;

        const user = knownUser || await this.resolveUser(account.login).catch(() => null);
        const displayName = user?.display_name || stream.user_name || account.login;
        const liveUrl = `https://www.twitch.tv/${account.login}`;
        const data = {
            name: displayName,
            login: account.login,
            url: liveUrl,
            title: stream.title || "",
            game: stream.game_name || "",
            viewers: stream.viewer_count || 0
        };

        const titleTemplate = account.embedTitle || "🟣 {name} est en LIVE sur Twitch !";
        const descTemplate = account.embedDescription ||
            "**{name}** vient de lancer un stream.\n\n🎮 **{game}**\n📝 {title}\n👥 {viewers} spectateur(s)\n\n▶️ [Regarder le live]({url})";

        const embed = new EmbedBuilder()
            .setColor(parseColor(account.embedColor))
            .setTitle(fillTemplate(titleTemplate, data).slice(0, 256))
            .setURL(liveUrl)
            .setDescription(fillTemplate(descTemplate, data).slice(0, 4096))
            .setFooter({ text: "👑🔥 Nexora Légend Agency • Twitch" })
            .setTimestamp(new Date(stream.started_at || Date.now()));

        if (user?.profile_image_url) {
            embed.setThumbnail(user.profile_image_url);
        }

        if (account.imageUrl) {
            embed.setImage(account.imageUrl);
        } else if (stream.thumbnail_url) {
            const thumbnail = stream.thumbnail_url
                .replace("{width}", "1280")
                .replace("{height}", "720");
            embed.setImage(`${thumbnail}?t=${Date.now()}`);
        }

        const ping = account.pingRoleId ? `<@&${account.pingRoleId}> ` : "";
        await channel.send({
            content: `${ping}🟣 **${displayName} vient de lancer un LIVE Twitch !**`,
            embeds: [embed],
            allowedMentions: account.pingRoleId ? { roles: [account.pingRoleId] } : { parse: [] }
        });
    }

    async scan(notify = true) {
        if (!this.configured || this.running) return;
        this.running = true;

        try {
            for (const guild of this.client.guilds.cache.values()) {
                for (const account of TwitchAccountManager.list(guild.id)) {
                    if (!account.enabled) continue;

                    try {
                        let userId = account.twitchUserId;
                        let user = null;
                        if (!userId) {
                            user = await this.resolveUser(account.login);
                            if (!user) continue;
                            userId = user.id;
                            TwitchAccountManager.upsert(guild.id, {
                                ...account,
                                twitchUserId: userId
                            });
                        }

                        const stream = await this.getStream(userId);
                        const live = Boolean(stream);
                        const key = this.cacheKey(guild.id, account.login);

                        if (!this.cache.has(key)) {
                            this.cache.set(key, live);
                            continue;
                        }

                        const previous = this.cache.get(key);
                        this.cache.set(key, live);

                        if (notify && live && previous === false) {
                            await this.sendNotification(guild.id, account, stream, user);
                        }
                    } catch (error) {
                        console.warn(`⚠️ Twitch @${account.login}:`, error?.message || error);
                    }
                }
            }
        } finally {
            this.running = false;
        }
    }

    async start() {
        if (!this.configured) {
            console.warn("⚠️ Twitch désactivé : ajoute TWITCH_CLIENT_ID et TWITCH_CLIENT_SECRET dans .env.");
            return;
        }

        await this.scan(false);
        this.timer = setInterval(() => this.scan(true).catch(console.error), this.intervalMs);
        console.log(`✅ Surveillance Twitch active toutes les ${this.intervalMs / 1000}s.`);
    }
}
