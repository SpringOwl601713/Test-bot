import db from "../database/Database.js";

const listStatement = db.prepare(`
    SELECT username
    FROM tiktok_accounts
    WHERE guild_id = ? AND COALESCE(enabled, 1) = 1
    ORDER BY username COLLATE NOCASE ASC
`);

const listAllStatement = db.prepare(`
    SELECT
        username,
        COALESCE(enabled, 1) AS enabled,
        notify_channel_id AS notifyChannelId,
        ping_role_id AS pingRoleId,
        image_url AS imageUrl
    FROM tiktok_accounts
    WHERE guild_id = ?
    ORDER BY username COLLATE NOCASE ASC
`);

const getStatement = db.prepare(`
    SELECT
        username,
        COALESCE(enabled, 1) AS enabled,
        notify_channel_id AS notifyChannelId,
        ping_role_id AS pingRoleId,
        image_url AS imageUrl
    FROM tiktok_accounts
    WHERE guild_id = ? AND username = ?
`);

const insertStatement = db.prepare(`
    INSERT OR IGNORE INTO tiktok_accounts (guild_id, username, enabled)
    VALUES (?, ?, 1)
`);

const removeStatement = db.prepare(`
    DELETE FROM tiktok_accounts
    WHERE guild_id = ? AND username = ?
`);

const existsStatement = db.prepare(`
    SELECT 1
    FROM tiktok_accounts
    WHERE guild_id = ? AND username = ?
`);

const updateStatement = db.prepare(`
    UPDATE tiktok_accounts
    SET enabled = ?, notify_channel_id = ?, ping_role_id = ?, image_url = ?
    WHERE guild_id = ? AND username = ?
`);

export class TikTokAccountManager {
    static list(guildId) {
        return listStatement.all(guildId).map(row => row.username);
    }

    static listAll(guildId) {
        return listAllStatement.all(guildId).map(row => ({
            ...row,
            enabled: Boolean(row.enabled)
        }));
    }

    static get(guildId, username) {
        const row = getStatement.get(guildId, username);
        return row ? { ...row, enabled: Boolean(row.enabled) } : null;
    }

    static exists(guildId, username) {
        return Boolean(existsStatement.get(guildId, username));
    }

    static addMany(guildId, usernames) {
        const added = [];
        const duplicates = [];

        db.exec("BEGIN");

        try {
            for (const username of usernames) {
                const result = insertStatement.run(guildId, username);

                if (Number(result.changes) === 1) {
                    added.push(username);
                } else {
                    duplicates.push(username);
                }
            }

            db.exec("COMMIT");
        } catch (error) {
            db.exec("ROLLBACK");
            throw error;
        }

        return { added, duplicates };
    }

    static update(guildId, username, patch) {
        const current = this.get(guildId, username);
        if (!current) return null;

        const next = {
            username,
            enabled: patch.enabled !== undefined ? Boolean(patch.enabled) : current.enabled,
            notifyChannelId:
                patch.notifyChannelId !== undefined
                    ? patch.notifyChannelId
                    : current.notifyChannelId,
            pingRoleId:
                patch.pingRoleId !== undefined
                    ? patch.pingRoleId
                    : current.pingRoleId,
            imageUrl:
                patch.imageUrl !== undefined
                    ? patch.imageUrl
                    : current.imageUrl
        };

        updateStatement.run(
            next.enabled ? 1 : 0,
            next.notifyChannelId,
            next.pingRoleId,
            next.imageUrl,
            guildId,
            username
        );

        return next;
    }

    static remove(guildId, username) {
        const result = removeStatement.run(guildId, username);
        return Number(result.changes) === 1;
    }
}
