import db from "../database/Database.js";

const listStatement = db.prepare(`
    SELECT
        slug,
        notify_channel_id AS notifyChannelId,
        ping_role_id AS pingRoleId,
        embed_title AS embedTitle,
        embed_description AS embedDescription,
        embed_color AS embedColor,
        image_url AS imageUrl,
        COALESCE(enabled, 1) AS enabled
    FROM kick_accounts
    WHERE guild_id = ?
    ORDER BY slug COLLATE NOCASE ASC
`);

const getStatement = db.prepare(`
    SELECT
        slug,
        notify_channel_id AS notifyChannelId,
        ping_role_id AS pingRoleId,
        embed_title AS embedTitle,
        embed_description AS embedDescription,
        embed_color AS embedColor,
        image_url AS imageUrl,
        COALESCE(enabled, 1) AS enabled
    FROM kick_accounts
    WHERE guild_id = ? AND slug = ?
`);

const upsertStatement = db.prepare(`
    INSERT INTO kick_accounts (
        guild_id, slug, notify_channel_id, ping_role_id,
        embed_title, embed_description, embed_color, image_url, enabled, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, unixepoch())
    ON CONFLICT(guild_id, slug) DO UPDATE SET
        notify_channel_id = excluded.notify_channel_id,
        ping_role_id = excluded.ping_role_id,
        embed_title = excluded.embed_title,
        embed_description = excluded.embed_description,
        embed_color = excluded.embed_color,
        image_url = excluded.image_url,
        enabled = 1,
        updated_at = unixepoch()
`);

const removeStatement = db.prepare(`
    DELETE FROM kick_accounts
    WHERE guild_id = ? AND slug = ?
`);

export class KickAccountManager {
    static list(guildId) {
        return listStatement.all(guildId).map(row => ({
            ...row,
            enabled: Boolean(row.enabled)
        }));
    }

    static get(guildId, slug) {
        const row = getStatement.get(guildId, slug);
        return row ? { ...row, enabled: Boolean(row.enabled) } : null;
    }

    static upsert(guildId, account) {
        upsertStatement.run(
            guildId,
            account.slug,
            account.notifyChannelId,
            account.pingRoleId || null,
            account.embedTitle || null,
            account.embedDescription || null,
            account.embedColor || "53FC18",
            account.imageUrl || null
        );
        return this.get(guildId, account.slug);
    }

    static remove(guildId, slug) {
        const result = removeStatement.run(guildId, slug);
        return Number(result.changes) === 1;
    }
}
