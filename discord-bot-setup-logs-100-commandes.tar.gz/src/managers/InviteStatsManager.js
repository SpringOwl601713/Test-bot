import fs from "node:fs";
import path from "node:path";
import {
    AttachmentBuilder,
    EmbedBuilder,
    PermissionFlagsBits
} from "discord.js";
import db from "../database/Database.js";

const imageDir = path.resolve("./data/invites-images");
fs.mkdirSync(imageDir, { recursive: true });

function safeExt(name = "image.png", contentType = "") {
    const ext = path.extname(name).toLowerCase();
    if ([".png", ".jpg", ".jpeg", ".gif", ".webp"].includes(ext)) return ext;
    if (contentType === "image/jpeg") return ".jpg";
    if (contentType === "image/gif") return ".gif";
    if (contentType === "image/webp") return ".webp";
    return ".png";
}

function vars(template, data) {
    return String(template || "")
        .replaceAll("{membre}", data.membre)
        .replaceAll("{serveur}", data.serveur)
        .replaceAll("{invitations}", String(data.invitations))
        .replaceAll("{arrivees}", String(data.arrivees))
        .replaceAll("{departs}", String(data.departs));
}

export class InviteStatsManager {
    constructor(client) {
        this.client = client;
        this.inviteCache = new Map();
    }

    async start() {
        for (const guild of this.client.guilds.cache.values()) {
            await this.refreshInvites(guild).catch(() => {});
        }
    }

    getSettings(guildId) {
        return db.prepare("SELECT * FROM invite_stats_settings WHERE guild_id = ?").get(guildId) || null;
    }

    async configure(guild, { channelId, image, title, description }) {
        const current = this.getSettings(guild.id);
        let imagePath = current?.image_path || null;

        if (image) {
            const response = await fetch(image.url);
            if (!response.ok) throw new Error("Impossible de télécharger l’image.");
            const buffer = Buffer.from(await response.arrayBuffer());
            if (buffer.length > 10 * 1024 * 1024) throw new Error("L’image est trop volumineuse (10 Mo max).");
            const ext = safeExt(image.name, image.contentType);
            imagePath = path.join(imageDir, `${guild.id}${ext}`);
            for (const oldExt of [".png", ".jpg", ".jpeg", ".gif", ".webp"]) {
                const old = path.join(imageDir, `${guild.id}${oldExt}`);
                if (old !== imagePath && fs.existsSync(old)) fs.rmSync(old, { force: true });
            }
            fs.writeFileSync(imagePath, buffer);
        }

        const defaultTitle = "📨 Invitations de {membre}";
        const defaultDescription = "✅ **{arrivees}** arrivée(s)\n❌ **{departs}** départ(s)\n✨ **{invitations}** invitation(s) active(s)\n\nServeur : **{serveur}**";

        db.prepare(`
            INSERT INTO invite_stats_settings
                (guild_id, enabled, channel_id, embed_title, embed_description, image_path, updated_at)
            VALUES (?, 1, ?, ?, ?, ?, unixepoch())
            ON CONFLICT(guild_id) DO UPDATE SET
                enabled = 1,
                channel_id = excluded.channel_id,
                embed_title = excluded.embed_title,
                embed_description = excluded.embed_description,
                image_path = excluded.image_path,
                updated_at = unixepoch()
        `).run(
            guild.id,
            channelId,
            title || current?.embed_title || defaultTitle,
            description || current?.embed_description || defaultDescription,
            imagePath
        );

        await this.refreshInvites(guild).catch(() => {});
        return this.getSettings(guild.id);
    }

    setEnabled(guildId, enabled) {
        db.prepare("UPDATE invite_stats_settings SET enabled = ?, updated_at = unixepoch() WHERE guild_id = ?")
            .run(enabled ? 1 : 0, guildId);
    }

    async refreshInvites(guild) {
        const me = guild.members.me;
        if (!me?.permissions.has(PermissionFlagsBits.ManageGuild)) return;
        const invites = await guild.invites.fetch();
        this.inviteCache.set(guild.id, new Map(invites.map(inv => [inv.code, inv.uses || 0])));
    }

    async handleInviteChange(guild) {
        await this.refreshInvites(guild).catch(() => {});
    }

    async detectUsedInvite(guild) {
        const me = guild.members.me;
        if (!me?.permissions.has(PermissionFlagsBits.ManageGuild)) return null;
        const before = this.inviteCache.get(guild.id) || new Map();
        const current = await guild.invites.fetch();
        let used = null;
        for (const invite of current.values()) {
            const oldUses = before.get(invite.code) || 0;
            if ((invite.uses || 0) > oldUses) {
                used = invite;
                break;
            }
        }
        this.inviteCache.set(guild.id, new Map(current.map(inv => [inv.code, inv.uses || 0])));
        return used;
    }

    async handleMemberJoin(member) {
        let usedInvite = null;
        try { usedInvite = await this.detectUsedInvite(member.guild); } catch {}
        const inviterId = usedInvite?.inviter?.id || null;

        db.prepare(`
            INSERT INTO invite_stats_member_history (guild_id, member_id, inviter_id, invite_code, joined_at)
            VALUES (?, ?, ?, ?, unixepoch())
            ON CONFLICT(guild_id, member_id) DO UPDATE SET
                inviter_id = excluded.inviter_id,
                invite_code = excluded.invite_code,
                joined_at = unixepoch()
        `).run(member.guild.id, member.id, inviterId, usedInvite?.code || null);

        if (inviterId) {
            db.prepare(`
                INSERT INTO inviter_stats (guild_id, inviter_id, joins, leaves, updated_at)
                VALUES (?, ?, 1, 0, unixepoch())
                ON CONFLICT(guild_id, inviter_id) DO UPDATE SET
                    joins = joins + 1,
                    updated_at = unixepoch()
            `).run(member.guild.id, inviterId);
        }
    }

    async handleMemberLeave(member) {
        const row = db.prepare("SELECT * FROM invite_stats_member_history WHERE guild_id = ? AND member_id = ?")
            .get(member.guild.id, member.id);
        if (row?.inviter_id) {
            db.prepare(`
                INSERT INTO inviter_stats (guild_id, inviter_id, joins, leaves, updated_at)
                VALUES (?, ?, 0, 1, unixepoch())
                ON CONFLICT(guild_id, inviter_id) DO UPDATE SET
                    leaves = leaves + 1,
                    updated_at = unixepoch()
            `).run(member.guild.id, row.inviter_id);
        }
        db.prepare("DELETE FROM invite_stats_member_history WHERE guild_id = ? AND member_id = ?")
            .run(member.guild.id, member.id);
    }

    getStats(guildId, userId) {
        const row = db.prepare("SELECT joins, leaves FROM inviter_stats WHERE guild_id = ? AND inviter_id = ?")
            .get(guildId, userId) || { joins: 0, leaves: 0 };
        const joins = Number(row.joins || 0);
        const leaves = Number(row.leaves || 0);
        return { joins, leaves, active: Math.max(0, joins - leaves) };
    }

    async sendStats(guild, member) {
        const settings = this.getSettings(guild.id);
        if (!settings?.enabled) throw new Error("Le système /invites est désactivé sur ce serveur.");
        const channel = guild.channels.cache.get(settings.channel_id) || await guild.channels.fetch(settings.channel_id).catch(() => null);
        if (!channel?.isTextBased?.()) throw new Error("Le salon configuré pour /invites est introuvable.");

        const stats = this.getStats(guild.id, member.id);
        let currentInviteUses = 0;
        try {
            if (guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) {
                const invites = await guild.invites.fetch();
                for (const invite of invites.values()) {
                    if (invite.inviter?.id === member.id) currentInviteUses += invite.uses || 0;
                }
            }
        } catch {}

        // Au premier démarrage, Discord peut déjà avoir un historique d'utilisations
        // que notre base locale n'a pas encore observé. On conserve donc la valeur
        // la plus élevée entre les utilisations actuelles des liens et le compteur local.
        const arrivals = Math.max(stats.joins, currentInviteUses);
        const active = Math.max(0, arrivals - stats.leaves);
        const data = {
            membre: `<@${member.id}>`,
            serveur: guild.name,
            invitations: active,
            arrivees: arrivals,
            departs: stats.leaves
        };

        const embed = new EmbedBuilder()
            .setColor(0x5865f2)
            .setTitle(vars(settings.embed_title || "📨 Invitations de {membre}", data))
            .setDescription(vars(settings.embed_description || "✅ **{arrivees}** arrivée(s)\n❌ **{departs}** départ(s)\n✨ **{invitations}** invitation(s) active(s)", data))
            .setThumbnail(member.displayAvatarURL({ size: 256 }))
            .setFooter({ text: `Demandé sur ${guild.name}` })
            .setTimestamp();

        const payload = { embeds: [embed], allowedMentions: { parse: ["users"] } };
        if (settings.image_path && fs.existsSync(settings.image_path)) {
            const filename = `invites${path.extname(settings.image_path) || ".png"}`;
            payload.files = [new AttachmentBuilder(settings.image_path, { name: filename })];
            embed.setImage(`attachment://${filename}`);
        }
        return channel.send(payload);
    }
    async getDetailedStats(guild, userId) {
        const local = this.getStats(guild.id, userId);
        let totalUses = 0;
        try {
            if (guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) {
                const invites = await guild.invites.fetch();
                for (const invite of invites.values()) {
                    if (invite.inviter?.id === userId) totalUses += invite.uses || 0;
                }
            }
        } catch {}
        const total = Math.max(local.joins, totalUses);
        const real = Math.max(0, total - local.leaves);
        return { real, total, leaves: local.leaves };
    }

    async getLeaderboard(guild, limit = 10) {
        const rows = db.prepare(`
            SELECT inviter_id, joins, leaves
            FROM inviter_stats
            WHERE guild_id = ?
            ORDER BY (joins - leaves) DESC, joins DESC
            LIMIT 100
        `).all(guild.id);

        // Ajoute aussi les créateurs de liens actuellement présents, même si le bot
        // n'a pas encore observé une arrivée depuis son installation.
        const ids = new Set(rows.map(r => r.inviter_id));
        try {
            if (guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) {
                const invites = await guild.invites.fetch();
                for (const invite of invites.values()) if (invite.inviter?.id) ids.add(invite.inviter.id);
            }
        } catch {}

        const result = [];
        for (const id of ids) {
            const stats = await this.getDetailedStats(guild, id);
            if (stats.total > 0 || stats.leaves > 0) result.push({ userId: id, ...stats });
        }
        result.sort((a, b) => b.real - a.real || b.total - a.total || a.leaves - b.leaves);
        return result.slice(0, limit);
    }

}
