import fs from "node:fs";
import path from "node:path";
import { AttachmentBuilder, EmbedBuilder } from "discord.js";
import db from "../database/Database.js";

const imageDir = path.resolve("./data/effectif-images");
fs.mkdirSync(imageDir, { recursive: true });
function safeExt(name="image.png", type="") { const e=path.extname(name).toLowerCase(); if ([".png",".jpg",".jpeg",".gif",".webp"].includes(e)) return e; if(type==="image/jpeg")return ".jpg"; if(type==="image/gif")return ".gif"; if(type==="image/webp")return ".webp"; return ".png"; }
function vars(t,g){return String(t||"").replaceAll("{serveur}",g.name).replaceAll("{membres}",String(g.memberCount));}
export class EffectifManager {
 constructor(client){this.client=client;}
 getSettings(id){return db.prepare("SELECT * FROM staff_effectif_settings WHERE guild_id=?").get(id)||null;}
 getRoles(id){return db.prepare("SELECT * FROM staff_effectif_roles WHERE guild_id=? ORDER BY position ASC").all(id);}
 async configure(guild,{channelId,title,description,color,image}){
  let imagePath=this.getSettings(guild.id)?.image_path||null;
  if(image){const r=await fetch(image.url); if(!r.ok)throw new Error("Impossible de télécharger l’image."); const b=Buffer.from(await r.arrayBuffer()); if(b.length>10*1024*1024)throw new Error("Image trop volumineuse (10 Mo max)."); const ext=safeExt(image.name,image.contentType); imagePath=path.join(imageDir,`${guild.id}${ext}`); for(const x of [".png",".jpg",".jpeg",".gif",".webp"]){const old=path.join(imageDir,`${guild.id}${x}`);if(old!==imagePath&&fs.existsSync(old))fs.rmSync(old,{force:true});} fs.writeFileSync(imagePath,b);}
  db.prepare(`INSERT INTO staff_effectif_settings(guild_id,enabled,channel_id,message_id,embed_title,embed_description,embed_color,image_path,updated_at) VALUES(?,1,?,NULL,?,?,?,?,unixepoch()) ON CONFLICT(guild_id) DO UPDATE SET enabled=1,channel_id=excluded.channel_id,embed_title=excluded.embed_title,embed_description=excluded.embed_description,embed_color=excluded.embed_color,image_path=excluded.image_path,updated_at=unixepoch()`).run(guild.id,channelId,title,description,color,imagePath);
  await this.refresh(guild,true);
 }
 addRole(guildId,roleId){const n=this.getRoles(guildId).length;db.prepare("INSERT OR IGNORE INTO staff_effectif_roles(guild_id,role_id,position) VALUES(?,?,?)").run(guildId,roleId,n);}
 removeRole(guildId,roleId){db.prepare("DELETE FROM staff_effectif_roles WHERE guild_id=? AND role_id=?").run(guildId,roleId);}
 setEnabled(id,v){db.prepare("UPDATE staff_effectif_settings SET enabled=?,updated_at=unixepoch() WHERE guild_id=?").run(v?1:0,id);}
 async refresh(guild,force=false){const st=this.getSettings(guild.id);if(!st||(!st.enabled&&!force))return;const ch=guild.channels.cache.get(st.channel_id)||await guild.channels.fetch(st.channel_id).catch(()=>null);if(!ch?.isTextBased?.())return;
  const roles=this.getRoles(guild.id); let total=new Set(); const fields=[];
  for(const rr of roles){const role=guild.roles.cache.get(rr.role_id)||await guild.roles.fetch(rr.role_id).catch(()=>null);if(!role)continue;const members=[...role.members.values()].filter(m=>!m.user.bot);members.forEach(m=>total.add(m.id));fields.push({name:`${role.name} (${members.length})`,value:members.length?members.map(m=>`<@${m.id}>`).join("\n").slice(0,1024):"*Aucun membre*",inline:false});}
  const embed=new EmbedBuilder().setColor(parseInt(st.embed_color||"5865F2",16)).setTitle(vars(st.embed_title,guild)).setDescription(`${vars(st.embed_description,guild)}\n**${total.size} membre(s) de l’effectif**`).addFields(fields.slice(0,25)).setFooter({text:"Mis à jour automatiquement"}).setTimestamp();
  const payload={embeds:[embed],allowedMentions:{parse:[]}};if(st.image_path&&fs.existsSync(st.image_path)){const fn=`effectif${path.extname(st.image_path)||'.png'}`;payload.files=[new AttachmentBuilder(st.image_path,{name:fn})];embed.setImage(`attachment://${fn}`);}
  let msg=null;if(st.message_id)msg=await ch.messages.fetch(st.message_id).catch(()=>null);if(msg)await msg.edit(payload);else{msg=await ch.send(payload);db.prepare("UPDATE staff_effectif_settings SET message_id=?,updated_at=unixepoch() WHERE guild_id=?").run(msg.id,guild.id);} }
 async handleMemberUpdate(oldM,newM){const tracked=new Set(this.getRoles(newM.guild.id).map(x=>x.role_id));if(!tracked.size)return;const changed=[...tracked].some(id=>oldM.roles.cache.has(id)!==newM.roles.cache.has(id));if(changed)await this.refresh(newM.guild);}
}
