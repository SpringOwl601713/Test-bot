import fs from "node:fs";
import path from "node:path";
import { AttachmentBuilder, EmbedBuilder, PermissionFlagsBits } from "discord.js";
import db from "../database/Database.js";

const imageDir = path.resolve("./data/recovery-images");
fs.mkdirSync(imageDir, { recursive: true });

function safeExt(name = "image.png", contentType = "") {
  const ext = path.extname(name).toLowerCase();
  if ([".png", ".jpg", ".jpeg", ".gif", ".webp"].includes(ext)) return ext;
  if (contentType === "image/jpeg") return ".jpg";
  if (contentType === "image/gif") return ".gif";
  if (contentType === "image/webp") return ".webp";
  return ".png";
}
function vars(text, member, count, nickRestored) {
  return String(text || "")
    .replaceAll("{membre}", `<@${member.id}>`)
    .replaceAll("{serveur}", member.guild.name)
    .replaceAll("{roles}", String(count))
    .replaceAll("{pseudo}", nickRestored ? "Oui" : "Non");
}

export class RecoveryManager {
  constructor(client) { this.client = client; }
  getSettings(guildId) { return db.prepare("SELECT * FROM recovery_settings WHERE guild_id=?").get(guildId) || null; }
  getRoles(guildId) { return db.prepare("SELECT role_id FROM recovery_allowed_roles WHERE guild_id=?").all(guildId).map(r => r.role_id); }
  setEnabled(guildId, enabled) { db.prepare("UPDATE recovery_settings SET enabled=?, updated_at=unixepoch() WHERE guild_id=?").run(enabled ? 1 : 0, guildId); }
  addRole(guildId, roleId) { db.prepare("INSERT OR IGNORE INTO recovery_allowed_roles(guild_id,role_id) VALUES(?,?)").run(guildId, roleId); }
  removeRole(guildId, roleId) { db.prepare("DELETE FROM recovery_allowed_roles WHERE guild_id=? AND role_id=?").run(guildId, roleId); }

  async configure(guild, o) {
    let imagePath = this.getSettings(guild.id)?.image_path || null;
    if (o.image) {
      const response = await fetch(o.image.url);
      if (!response.ok) throw new Error("Impossible de télécharger l’image.");
      const buffer = Buffer.from(await response.arrayBuffer());
      if (buffer.length > 10 * 1024 * 1024) throw new Error("Image trop volumineuse (10 Mo max).");
      const ext = safeExt(o.image.name, o.image.contentType);
      imagePath = path.join(imageDir, `${guild.id}${ext}`);
      for (const e of [".png", ".jpg", ".jpeg", ".gif", ".webp"]) {
        const old = path.join(imageDir, `${guild.id}${e}`); if (old !== imagePath && fs.existsSync(old)) fs.rmSync(old, { force: true });
      }
      fs.writeFileSync(imagePath, buffer);
    }
    db.prepare(`INSERT INTO recovery_settings
      (guild_id,enabled,restore_roles,restore_nickname,dm_enabled,channel_id,role_mode,embed_title,embed_description,embed_color,image_path,updated_at)
      VALUES(?,1,?,?,?,?,?,?,?,?,?,unixepoch())
      ON CONFLICT(guild_id) DO UPDATE SET enabled=1,restore_roles=excluded.restore_roles,restore_nickname=excluded.restore_nickname,
      dm_enabled=excluded.dm_enabled,channel_id=excluded.channel_id,role_mode=excluded.role_mode,embed_title=excluded.embed_title,
      embed_description=excluded.embed_description,embed_color=excluded.embed_color,image_path=excluded.image_path,updated_at=unixepoch()`)
      .run(guild.id, o.restoreRoles ? 1 : 0, o.restoreNickname ? 1 : 0, o.dmEnabled ? 1 : 0, o.channelId || null, o.roleMode, o.title, o.description, o.color, imagePath);
  }

  async handleMemberLeave(member) {
    const s = this.getSettings(member.guild.id); if (!s?.enabled) return;
    const allowed = new Set(this.getRoles(member.guild.id));
    const roleIds = s.restore_roles ? member.roles.cache
      .filter(r => r.id !== member.guild.id && !r.managed && (s.role_mode === "all" || allowed.has(r.id)))
      .map(r => r.id) : [];
    db.prepare(`INSERT INTO recovery_members(guild_id,user_id,roles_json,nickname,saved_at) VALUES(?,?,?,?,unixepoch())
      ON CONFLICT(guild_id,user_id) DO UPDATE SET roles_json=excluded.roles_json,nickname=excluded.nickname,saved_at=unixepoch()`)
      .run(member.guild.id, member.id, JSON.stringify(roleIds), s.restore_nickname ? member.nickname : null);
  }

  async handleMemberJoin(member) {
    const s = this.getSettings(member.guild.id); if (!s?.enabled) return;
    const saved = db.prepare("SELECT * FROM recovery_members WHERE guild_id=? AND user_id=?").get(member.guild.id, member.id); if (!saved) return;
    const me = member.guild.members.me || await member.guild.members.fetchMe().catch(() => null);
    let restored = 0;
    if (s.restore_roles && me?.permissions.has(PermissionFlagsBits.ManageRoles)) {
      let ids = []; try { ids = JSON.parse(saved.roles_json || "[]"); } catch {}
      const valid = ids.map(id => member.guild.roles.cache.get(id)).filter(r => r && !r.managed && r.id !== member.guild.id && r.position < me.roles.highest.position);
      for (const role of valid) { try { await member.roles.add(role, "Récupération automatique après retour"); restored++; } catch {} }
    }
    let nickRestored = false;
    if (s.restore_nickname && saved.nickname && me?.permissions.has(PermissionFlagsBits.ManageNicknames) && member.roles.highest.position < me.roles.highest.position) {
      try { await member.setNickname(saved.nickname, "Récupération automatique après retour"); nickRestored = true; } catch {}
    }
    const embed = new EmbedBuilder().setColor(parseInt(s.embed_color || "EB126B", 16))
      .setTitle(vars(s.embed_title, member, restored, nickRestored)).setDescription(vars(s.embed_description, member, restored, nickRestored)).setTimestamp();
    const payload = { embeds: [embed], allowedMentions: { users: [member.id] } };
    if (s.image_path && fs.existsSync(s.image_path)) { const filename = `recuperation${path.extname(s.image_path) || ".png"}`; payload.files = [new AttachmentBuilder(s.image_path, { name: filename })]; embed.setImage(`attachment://${filename}`); }
    if (s.channel_id) { const ch = member.guild.channels.cache.get(s.channel_id) || await member.guild.channels.fetch(s.channel_id).catch(() => null); if (ch?.isTextBased?.()) await ch.send(payload).catch(() => {}); }
    if (s.dm_enabled) {
      const dmEmbed = EmbedBuilder.from(embed); const dmPayload = { embeds: [dmEmbed] };
      if (s.image_path && fs.existsSync(s.image_path)) { const filename = `recuperation${path.extname(s.image_path) || ".png"}`; dmPayload.files = [new AttachmentBuilder(s.image_path, { name: filename })]; dmEmbed.setImage(`attachment://${filename}`); }
      await member.send(dmPayload).catch(() => {});
    }
  }
}
