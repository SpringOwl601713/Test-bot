import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits
} from "discord.js";
import db from "../database/Database.js";
import { legacySlashCommandNames } from "../legacy-slash-commands.js";

const sleep = ms => new Promise(r => setTimeout(r, ms));

function parseDuration(input) {
  const m = String(input || "").trim().match(/^(\d+)(s|m|h|d)$/i);
  if (!m) return null;
  const n = Number(m[1]);
  const unit = m[2].toLowerCase();
  return n * ({ s: 1000, m: 60000, h: 3600000, d: 86400000 }[unit]);
}

function cleanHex(raw, fallback = "5865F2") {
  const v = String(raw || fallback).replace(/^#/, "");
  return /^[0-9a-fA-F]{6}$/.test(v) ? v.toUpperCase() : fallback;
}

export class LegacyCommandsManager {
  constructor(client) {
    this.client = client;
    this.spam = new Map();
    this.snipes = new Map();
    this.giveawayTimers = new Map();
    this.initDb();
  }

  initDb() {
    db.exec(`
      CREATE TABLE IF NOT EXISTS legacy_settings (
        guild_id TEXT NOT NULL,
        key TEXT NOT NULL,
        value TEXT,
        PRIMARY KEY (guild_id, key)
      );
      CREATE TABLE IF NOT EXISTS legacy_whitelist (
        guild_id TEXT NOT NULL, user_id TEXT NOT NULL,
        PRIMARY KEY (guild_id, user_id)
      );
      CREATE TABLE IF NOT EXISTS legacy_owners (
        guild_id TEXT NOT NULL, user_id TEXT NOT NULL,
        PRIMARY KEY (guild_id, user_id)
      );
      CREATE TABLE IF NOT EXISTS legacy_role_permissions (
        guild_id TEXT NOT NULL, role_id TEXT NOT NULL, command_name TEXT NOT NULL,
        PRIMARY KEY (guild_id, role_id, command_name)
      );
      CREATE TABLE IF NOT EXISTS legacy_command_access (
        guild_id TEXT NOT NULL, command_name TEXT NOT NULL, access TEXT NOT NULL DEFAULT 'admin',
        PRIMARY KEY (guild_id, command_name)
      );
      CREATE TABLE IF NOT EXISTS legacy_sanctions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL, user_id TEXT NOT NULL, moderator_id TEXT NOT NULL,
        type TEXT NOT NULL, reason TEXT, created_at INTEGER NOT NULL DEFAULT (unixepoch())
      );
      CREATE TABLE IF NOT EXISTS legacy_giveaways (
        message_id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, channel_id TEXT NOT NULL,
        host_id TEXT NOT NULL, prize TEXT NOT NULL, winner_count INTEGER NOT NULL,
        ends_at INTEGER NOT NULL, ended INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS legacy_giveaway_entries (
        message_id TEXT NOT NULL, user_id TEXT NOT NULL,
        PRIMARY KEY (message_id, user_id)
      );
    `);
  }

  isLegacy(name) { return legacySlashCommandNames.has(name); }
  getSetting(guildId, key, fallback = null) {
    return db.prepare("SELECT value FROM legacy_settings WHERE guild_id = ? AND key = ?").get(guildId, key)?.value ?? fallback;
  }
  setSetting(guildId, key, value) {
    db.prepare(`INSERT INTO legacy_settings (guild_id,key,value) VALUES (?,?,?)
      ON CONFLICT(guild_id,key) DO UPDATE SET value=excluded.value`).run(guildId, key, String(value));
  }
  delSetting(guildId, key) { db.prepare("DELETE FROM legacy_settings WHERE guild_id=? AND key=?").run(guildId, key); }

  async canUse(interaction) {
    if (interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) return true;
    const gid = interaction.guild.id;
    const uid = interaction.user.id;
    if (db.prepare("SELECT 1 FROM legacy_owners WHERE guild_id=? AND user_id=?").get(gid, uid)) return true;
    if (db.prepare("SELECT 1 FROM legacy_whitelist WHERE guild_id=? AND user_id=?").get(gid, uid)) return true;
    const roleIds = interaction.member?.roles?.cache ? [...interaction.member.roles.cache.keys()] : [];
    for (const rid of roleIds) {
      if (db.prepare("SELECT 1 FROM legacy_role_permissions WHERE guild_id=? AND role_id=? AND command_name=?").get(gid, rid, interaction.commandName)) return true;
    }
    const publicOn = this.getSetting(gid, "public_mode", "off") === "on";
    const access = db.prepare("SELECT access FROM legacy_command_access WHERE guild_id=? AND command_name=?").get(gid, interaction.commandName)?.access;
    if (publicOn && access === "public") return true;
    const inherentlyPublic = new Set(["alladmins","allbans","allbots","roleinfo","rolemembers","serverbanner","serverinfo","userinfo","variable","vc","snipe","sanction"]);
    return inherentlyPublic.has(interaction.commandName);
  }

  async handle(interaction) {
    if (!interaction.isChatInputCommand() || !this.isLegacy(interaction.commandName)) return false;
    if (!(await this.canUse(interaction))) {
      await interaction.reply({ content: "❌ Tu n'as pas la permission d'utiliser cette commande.", ephemeral: true });
      return true;
    }
    try {
      await this.execute(interaction);
    } catch (e) {
      console.error(`❌ Commande legacy /${interaction.commandName}:`, e);
      const payload = { content: `❌ Une erreur est survenue avec /${interaction.commandName}.`, ephemeral: true };
      if (interaction.deferred || interaction.replied) await interaction.followUp(payload).catch(()=>{}); else await interaction.reply(payload).catch(()=>{});
    }
    return true;
  }

  async execute(i) {
    const n = i.commandName;
    const guild = i.guild;
    const me = guild.members.me;
    const member = name => i.options.getMember(name) || (i.options.getUser(name) ? guild.members.fetch(i.options.getUser(name).id).catch(()=>null) : null);
    const reply = content => i.reply({ content, ephemeral: true });

    if (n === "addrole" || n === "delrole") {
      const m = await member("membre"); const r = i.options.getRole("role", true);
      if (!m) return reply("❌ Membre introuvable.");
      if (!me.permissions.has(PermissionFlagsBits.ManageRoles) || me.roles.highest.comparePositionTo(r) <= 0) return reply("❌ Le bot ne peut pas gérer ce rôle.");
      if (n === "addrole") await m.roles.add(r); else await m.roles.remove(r);
      return reply(`✅ Rôle ${r} ${n === "addrole" ? "ajouté à" : "retiré de"} ${m}.`);
    }

    if (n === "alladmins") {
      await guild.members.fetch();
      const list = guild.members.cache.filter(m=>m.permissions.has(PermissionFlagsBits.Administrator)).map(m=>`${m} — \`${m.id}\``);
      return i.reply({ embeds:[new EmbedBuilder().setTitle("Administrateurs").setDescription(list.join("\n").slice(0,4000)||"Aucun.").setColor(0x5865F2)], ephemeral:true });
    }
    if (n === "allbots") {
      await guild.members.fetch();
      const list = guild.members.cache.filter(m=>m.user.bot).map(m=>`${m} — \`${m.id}\``);
      return i.reply({ embeds:[new EmbedBuilder().setTitle("Bots du serveur").setDescription(list.join("\n").slice(0,4000)||"Aucun.").setColor(0x5865F2)], ephemeral:true });
    }
    if (n === "allbans") {
      const bans = await guild.bans.fetch();
      const list = [...bans.values()].map(b=>`• ${b.user.tag} — \`${b.user.id}\``);
      return i.reply({ embeds:[new EmbedBuilder().setTitle("Membres bannis").setDescription(list.join("\n").slice(0,4000)||"Aucun bannissement.").setColor(0xED4245)], ephemeral:true });
    }

    if (["antiban","antibot","antichannel","antieveryone","antirole","antiupdate","antivanity","antiwebhook"].includes(n)) {
      const state = i.options.getString("etat", true);
      this.setSetting(guild.id, n, state);
      const activeNow = new Set(["antibot","antieveryone"]);
      return reply(`✅ **${n}** ${state === "on" ? "activé" : "désactivé"}.${activeNow.has(n) ? "" : "\nℹ️ Le réglage a été importé. Les fichiers fournis ne contenaient pas le module d’événement d’origine pour cette protection, donc aucune action destructive n’est simulée."}`);
    }

    if (n === "antilink") {
      this.setSetting(guild.id, "antilink", i.options.getString("etat", true));
      this.setSetting(guild.id, "antilink_type", i.options.getString("type") || "all");
      return reply("✅ Anti-liens mis à jour.");
    }
    if (n === "antispam") {
      const state=i.options.getString("etat",true); this.setSetting(guild.id,"antispam",state);
      if(state==="on") {
        this.setSetting(guild.id,"antispam_count",i.options.getInteger("messages")||5);
        this.setSetting(guild.id,"antispam_window",i.options.getInteger("secondes")||10);
        this.setSetting(guild.id,"antispam_timeout",i.options.getInteger("timeout_minutes")||5);
      }
      return reply("✅ Anti-spam mis à jour.");
    }

    if (n === "unban") {
      const uid=i.options.getString("user_id",true).trim();
      await guild.bans.remove(uid, `Unban par ${i.user.tag}`);
      return reply(`✅ Utilisateur \`${uid}\` débanni.`);
    }

    if (["ban","kick","warn","mute","unmute","vmute","derank"].includes(n)) {
      const target = await member("membre");
      if (!target) return reply("❌ Membre introuvable.");
      const reason = i.options.getString("raison") || `Action /${n} par ${i.user.tag}`;
      if (target.id === guild.ownerId || target.permissions.has(PermissionFlagsBits.Administrator)) return reply("❌ Action refusée sur le propriétaire ou un administrateur.");
      if (n === "ban") await target.ban({ reason });
      if (n === "kick") await target.kick(reason);
      if (n === "warn") this.addSanction(guild.id,target.id,i.user.id,"warn",reason);
      if (n === "mute") {
        const ms=parseDuration(i.options.getString("duree",true)); if(!ms) return reply("❌ Durée invalide. Ex: `10m`, `1h`, `1d`.");
        await target.timeout(Math.min(ms,28*86400000),reason); this.addSanction(guild.id,target.id,i.user.id,"mute",reason);
      }
      if (n === "unmute") await target.timeout(null,reason);
      if (n === "vmute") {
        if (!target.voice.channel) return reply("❌ Ce membre n'est pas en vocal.");
        await target.voice.setMute(true, reason); this.addSanction(guild.id,target.id,i.user.id,"vmute",reason);
      }
      if (n === "derank") {
        const removable=target.roles.cache.filter(r=>r.id!==guild.id && !r.managed && me.roles.highest.comparePositionTo(r)>0);
        await target.roles.remove(removable, reason); this.addSanction(guild.id,target.id,i.user.id,"derank",reason);
      }
      if (["ban","kick"].includes(n)) this.addSanction(guild.id,target.id,i.user.id,n,reason);
      return reply(`✅ Action **${n}** appliquée à ${target}.`);
    }

    if (n === "clear") {
      const count=i.options.getInteger("nombre",true); const ch=i.channel;
      if(!ch?.bulkDelete) return reply("❌ Ce salon ne permet pas cette action.");
      const d=await ch.bulkDelete(count,true); return reply(`✅ ${d.size} message(s) supprimé(s).`);
    }

    if (["lock","unlock"].includes(n)) {
      const ch=i.options.getChannel("salon")||i.channel;
      await ch.permissionOverwrites.edit(guild.roles.everyone,{SendMessages:n==="unlock"?null:false});
      return reply(`✅ Salon ${n==="lock"?"verrouillé":"déverrouillé"}.`);
    }
    if (n === "renew") {
      const ch=i.options.getChannel("salon")||i.channel;
      if (!ch?.clone) return reply("❌ Salon invalide.");
      const clone=await ch.clone({reason:`Renew par ${i.user.tag}`}); await clone.setPosition(ch.position); await ch.delete(`Renew par ${i.user.tag}`);
      return clone.send(`✅ Salon recréé par ${i.user}.`);
    }

    if (n === "roleinfo") {
      const r=i.options.getRole("role",true); const e=new EmbedBuilder().setTitle(`Rôle • ${r.name}`).setColor(r.color||0x5865F2).addFields({name:"ID",value:r.id},{name:"Membres",value:String(r.members.size)},{name:"Position",value:String(r.position)},{name:"Mentionnable",value:r.mentionable?"Oui":"Non"});
      return i.reply({embeds:[e],ephemeral:true});
    }
    if (n === "rolemembers") {
      const r=i.options.getRole("role",true); const list=[...r.members.values()].map(m=>m.toString());
      return i.reply({embeds:[new EmbedBuilder().setTitle(`Membres • ${r.name}`).setDescription(list.join("\n").slice(0,4000)||"Aucun membre.").setColor(r.color||0x5865F2)],ephemeral:true});
    }
    if (n === "serverinfo") {
      await guild.members.fetch();
      const e=new EmbedBuilder().setTitle(guild.name).setThumbnail(guild.iconURL({size:256})).setColor(0x5865F2).addFields({name:"Membres",value:String(guild.memberCount),inline:true},{name:"Salons",value:String(guild.channels.cache.size),inline:true},{name:"Rôles",value:String(guild.roles.cache.size),inline:true},{name:"Propriétaire",value:`<@${guild.ownerId}>`,inline:true},{name:"Créé",value:`<t:${Math.floor(guild.createdTimestamp/1000)}:F>`});
      return i.reply({embeds:[e],ephemeral:true});
    }
    if (n === "serverbanner") {
      const g=await guild.fetch(); const url=g.bannerURL({size:4096});
      if(!url) return reply("ℹ️ Ce serveur n'a pas de bannière.");
      return i.reply({embeds:[new EmbedBuilder().setTitle(`Bannière • ${guild.name}`).setImage(url).setColor(0x5865F2)],ephemeral:true});
    }
    if (n === "userinfo") {
      const m=(await member("membre"))||i.member; const u=m.user;
      const e=new EmbedBuilder().setTitle(`Utilisateur • ${u.tag}`).setThumbnail(u.displayAvatarURL({size:256})).setColor(m.displayColor||0x5865F2).addFields({name:"ID",value:u.id},{name:"Compte créé",value:`<t:${Math.floor(u.createdTimestamp/1000)}:F>`},{name:"A rejoint",value:m.joinedTimestamp?`<t:${Math.floor(m.joinedTimestamp/1000)}:F>`:"Inconnu"},{name:"Rôles",value:String(Math.max(0,m.roles.cache.size-1))});
      return i.reply({embeds:[e],ephemeral:true});
    }

    if (n === "emoji") {
      const raw=i.options.getString("emoji"); const img=i.options.getAttachment("image"); let name=i.options.getString("nom")||"nexora"; let attachment=null;
      if(raw){const m=raw.match(/^<a?:([\w]+):(\d+)>$/); if(!m)return reply("❌ Emoji custom invalide."); name=i.options.getString("nom")||m[1]; attachment=`https://cdn.discordapp.com/emojis/${m[2]}.${raw.startsWith("<a:")?"gif":"png"}`;}
      else if(img) attachment=img.url; else return reply("❌ Ajoute `emoji` ou `image`.");
      const created=await guild.emojis.create({attachment,name,reason:`Ajout par ${i.user.tag}`}); return reply(`✅ Emoji créé : ${created}`);
    }

    if (n === "warn") return;
    if (["sanction","delsanction","delallsanction"].includes(n)) {
      const m=(await member("membre"))||i.member;
      if(n==="sanction") {
        const rows=db.prepare("SELECT * FROM legacy_sanctions WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 25").all(guild.id,m.id);
        const desc=rows.map((r,idx)=>`**#${idx+1} • ${r.type}** — ${r.reason||"Sans raison"}\n<t:${r.created_at}:R>`).join("\n\n")||"Aucune sanction.";
        return i.reply({embeds:[new EmbedBuilder().setTitle(`Sanctions • ${m.user.tag}`).setDescription(desc).setColor(0xFEE75C)],ephemeral:true});
      }
      if(n==="delallsanction"){db.prepare("DELETE FROM legacy_sanctions WHERE guild_id=? AND user_id=?").run(guild.id,m.id);return reply("✅ Toutes les sanctions enregistrées ont été supprimées.");}
      const num=i.options.getInteger("numero",true); const rows=db.prepare("SELECT id FROM legacy_sanctions WHERE guild_id=? AND user_id=? ORDER BY id DESC").all(guild.id,m.id); if(!rows[num-1])return reply("❌ Numéro invalide."); db.prepare("DELETE FROM legacy_sanctions WHERE id=?").run(rows[num-1].id); return reply("✅ Sanction supprimée.");
    }

    if (["setowner","unowner","whitelist","unwhitelist"].includes(n)) {
      const u=i.options.getUser("membre",true); const table=n.includes("owner")?"legacy_owners":"legacy_whitelist"; const add=!n.startsWith("un");
      if(add) db.prepare(`INSERT OR IGNORE INTO ${table} (guild_id,user_id) VALUES (?,?)`).run(guild.id,u.id); else db.prepare(`DELETE FROM ${table} WHERE guild_id=? AND user_id=?`).run(guild.id,u.id);
      return reply(`✅ ${u} ${add?"ajouté":"retiré"} ${table.includes("owner")?"des owners":"de la whitelist"}.`);
    }
    if(n==="owner") {
      const rows=db.prepare("SELECT user_id FROM legacy_owners WHERE guild_id=?").all(guild.id); return reply(rows.length?rows.map(r=>`<@${r.user_id}>`).join("\n"):"Aucun owner enregistré.");
    }
    if(n==="setpublic") {this.setSetting(guild.id,"public_mode",i.options.getString("etat",true));return reply("✅ Mode public mis à jour.");}
    if(n==="setcommand") {
      const c=i.options.getString("commande",true).replace(/^\//,""); const access=i.options.getString("acces",true); db.prepare(`INSERT INTO legacy_command_access(guild_id,command_name,access) VALUES(?,?,?) ON CONFLICT(guild_id,command_name) DO UPDATE SET access=excluded.access`).run(guild.id,c,access);
      const r=i.options.getRole("role"); if(r)db.prepare("INSERT OR IGNORE INTO legacy_role_permissions(guild_id,role_id,command_name) VALUES(?,?,?)").run(guild.id,r.id,c); return reply("✅ Accès de la commande mis à jour.");
    }
    if(n==="delcommand") {
      const c=i.options.getString("commande",true).replace(/^\//,""); const r=i.options.getRole("role"); if(r)db.prepare("DELETE FROM legacy_role_permissions WHERE guild_id=? AND role_id=? AND command_name=?").run(guild.id,r.id,c); else db.prepare("DELETE FROM legacy_command_access WHERE guild_id=? AND command_name=?").run(guild.id,c); return reply("✅ Règle supprimée.");
    }
    if(n==="setperm"||n==="delperm") {
      const c=i.options.getString("commande",true).replace(/^\//,""); const r=i.options.getRole("role",true); if(n==="setperm")db.prepare("INSERT OR IGNORE INTO legacy_role_permissions(guild_id,role_id,command_name) VALUES(?,?,?)").run(guild.id,r.id,c); else db.prepare("DELETE FROM legacy_role_permissions WHERE guild_id=? AND role_id=? AND command_name=?").run(guild.id,r.id,c); return reply("✅ Permission mise à jour.");
    }
    if(n==="perms") {
      const access=db.prepare("SELECT command_name,access FROM legacy_command_access WHERE guild_id=? ORDER BY command_name").all(guild.id); const rp=db.prepare("SELECT role_id,command_name FROM legacy_role_permissions WHERE guild_id=? ORDER BY command_name").all(guild.id); const lines=[...access.map(x=>`/${x.command_name} → **${x.access}**`),...rp.map(x=>`/${x.command_name} → <@&${x.role_id}>`)]; return i.reply({embeds:[new EmbedBuilder().setTitle("Permissions des commandes importées").setDescription(lines.join("\n").slice(0,4000)||"Aucune règle personnalisée.").setColor(0x5865F2)],ephemeral:true});
    }

    if(n==="setcolor") {const c=cleanHex(i.options.getString("couleur",true));this.setSetting(guild.id,"embed_color",c);return reply(`✅ Couleur définie sur **#${c}**.`);}
    if(n==="setconfess"||n==="setsuggest") {const active=i.options.getBoolean("actif",true); const ch=i.options.getChannel("salon");this.setSetting(guild.id,n,active?"on":"off");if(ch)this.setSetting(guild.id,`${n}_channel`,ch.id);return reply(`✅ ${n} ${active?"activé":"désactivé"}.`);}
    if(n==="soutien") {const action=i.options.getString("action",true);if(action==="clear"){this.delSetting(guild.id,"soutien_role");this.delSetting(guild.id,"soutien_text");return reply("✅ Soutien désactivé.");}const r=i.options.getRole("role");const t=i.options.getString("texte");if(!r||!t)return reply("❌ Pour configurer, indique `role` et `texte`.");this.setSetting(guild.id,"soutien_role",r.id);this.setSetting(guild.id,"soutien_text",t);return reply("✅ Soutien configuré.");}
    if(n==="ghostping") {this.setSetting(guild.id,"ghostping_channels",i.options.getString("salons",true));return reply("✅ Salons de ghostping enregistrés.");}

    if(n==="snipe") {const s=this.snipes.get(i.channelId); if(!s)return reply("ℹ️ Aucun message supprimé mémorisé dans ce salon."); return i.reply({embeds:[new EmbedBuilder().setAuthor({name:s.authorTag,iconURL:s.avatar}).setDescription(s.content||"*(message sans texte)*").setFooter({text:"Dernier message supprimé"}).setTimestamp(s.at).setColor(0x5865F2)],ephemeral:true});}

    if(n==="tempvoc") {const a=i.options.getString("action",true);this.setSetting(guild.id,"tempvoc",a);if(a==="on"){const ch=i.options.getChannel("salon");const cat=i.options.getChannel("categorie");if(!ch||!cat)return reply("❌ Indique le salon vocal déclencheur et la catégorie.");this.setSetting(guild.id,"tempvoc_trigger",ch.id);this.setSetting(guild.id,"tempvoc_category",cat.id);}return reply(`✅ Vocaux temporaires ${a==="on"?"activés":"désactivés"}.`);}
    if(n==="voicemove") {const m=await member("membre");if(!m?.voice.channel)return reply("❌ Le membre n'est pas en vocal.");if(!i.member.voice.channel)return reply("❌ Tu dois être dans le vocal de destination.");await m.voice.setChannel(i.member.voice.channel);return reply("✅ Membre déplacé.");}
    if(n==="vc") {await guild.members.fetch();const connected=guild.members.cache.filter(m=>m.voice.channel).size;const muted=guild.members.cache.filter(m=>m.voice.mute||m.voice.deaf).size;return i.reply({embeds:[new EmbedBuilder().setTitle("Statistiques vocales").addFields({name:"Connectés",value:String(connected),inline:true},{name:"Muets / sourds",value:String(muted),inline:true}).setColor(0x5865F2)],ephemeral:true});}

    if(n==="variable") return reply("Variables disponibles selon les modules Nexora : `{membre}`, `{serveur}`, `{inviteur}`, `{invitations}`, `{membres}`, `{boosts}`, `{niveau}`, `{valeur}`.");

    if(n==="gstart") return this.startGiveaway(i);
    if(n==="gend") return this.endGiveaway(i, i.options.getString("message_id",true), false);
    if(n==="greroll") return this.rerollGiveaway(i, i.options.getString("message_id",true));

    return reply(`ℹ️ La commande **/${n}** a été convertie en slash et intégrée. Le fichier d'origine fourni ne contenait pas tous ses modules dépendants, donc cette partie reste en mode compatibilité.`);
  }

  addSanction(gid,uid,mid,type,reason){db.prepare("INSERT INTO legacy_sanctions(guild_id,user_id,moderator_id,type,reason) VALUES(?,?,?,?,?)").run(gid,uid,mid,type,reason||null);}

  async onMessageCreate(message) {
    if(!message.guild || message.author.bot || message.member?.permissions.has(PermissionFlagsBits.Administrator)) return;
    const gid=message.guild.id;
    if(this.getSetting(gid,"antieveryone","off")==="on" && (message.mentions.everyone || message.content.includes("@everyone") || message.content.includes("@here"))){await message.delete().catch(()=>{});return;}
    if(this.getSetting(gid,"antilink","off")==="on"){
      const type=this.getSetting(gid,"antilink_type","all"); const c=message.content||""; const match=type==="invite"?/(discord\.gg\/|discord(?:app)?\.com\/invite\/)/i.test(c):/https?:\/\//i.test(c);
      if(match){await message.delete().catch(()=>{});await message.member.timeout(60_000,"Anti-link").catch(()=>{});return;}
    }
    if(this.getSetting(gid,"antispam","off")==="on"){
      const key=`${gid}:${message.author.id}`;const now=Date.now();const win=Number(this.getSetting(gid,"antispam_window","10"))*1000;const count=Number(this.getSetting(gid,"antispam_count","5"));const arr=(this.spam.get(key)||[]).filter(t=>now-t<win);arr.push(now);this.spam.set(key,arr);if(arr.length>=count){this.spam.set(key,[]);await message.member.timeout(Number(this.getSetting(gid,"antispam_timeout","5"))*60000,"Anti-spam").catch(()=>{});}
    }
  }
  onMessageDelete(message){if(!message.guild||message.author?.bot)return;this.snipes.set(message.channelId,{authorTag:message.author?.tag||"Inconnu",avatar:message.author?.displayAvatarURL?.()||null,content:message.content,at:new Date()});}
  async onMemberAdd(member){if(this.getSetting(member.guild.id,"antibot","off")==="on"&&member.user.bot){await member.ban({reason:"Anti-bot activé"}).catch(()=>{});}}
  async onVoiceStateUpdate(oldState,newState){
    const g=newState.guild; if(this.getSetting(g.id,"tempvoc","off")!=="on")return; const trigger=this.getSetting(g.id,"tempvoc_trigger"); const cat=this.getSetting(g.id,"tempvoc_category");
    if(newState.channelId===trigger && newState.member){const ch=await g.channels.create({name:`🔊 ${newState.member.displayName}`.slice(0,100),type:ChannelType.GuildVoice,parent:cat,permissionOverwrites:[{id:newState.member.id,allow:[PermissionFlagsBits.ManageChannels]}]});await newState.setChannel(ch).catch(()=>{});}
    if(oldState.channel && oldState.channel.parentId===cat && oldState.channel.id!==trigger && oldState.channel.members.size===0){await oldState.channel.delete("Salon vocal temporaire vide").catch(()=>{});}
  }

  async onButton(interaction){
    if(!interaction.isButton()||!interaction.customId.startsWith("legacy:giveaway:"))return false;
    const id=interaction.customId.split(":")[2]; const g=db.prepare("SELECT * FROM legacy_giveaways WHERE message_id=? AND ended=0").get(id);if(!g){await interaction.reply({content:"❌ Ce giveaway est terminé.",ephemeral:true});return true;}
    const existing=db.prepare("SELECT 1 FROM legacy_giveaway_entries WHERE message_id=? AND user_id=?").get(id,interaction.user.id);
    if(existing){db.prepare("DELETE FROM legacy_giveaway_entries WHERE message_id=? AND user_id=?").run(id,interaction.user.id);await interaction.reply({content:"↩️ Participation retirée.",ephemeral:true});}
    else{db.prepare("INSERT OR IGNORE INTO legacy_giveaway_entries(message_id,user_id) VALUES(?,?)").run(id,interaction.user.id);await interaction.reply({content:"✅ Participation enregistrée !",ephemeral:true});}
    return true;
  }
  async start(){
    const rows=db.prepare("SELECT * FROM legacy_giveaways WHERE ended=0").all();for(const g of rows)this.scheduleGiveaway(g);
  }
  scheduleGiveaway(g){const delay=Math.max(0,g.ends_at-Date.now());if(this.giveawayTimers.has(g.message_id))clearTimeout(this.giveawayTimers.get(g.message_id));const timer=setTimeout(()=>this.finishGiveawayById(g.message_id).catch(console.error),Math.min(delay,2147483647));this.giveawayTimers.set(g.message_id,timer);}
  async startGiveaway(i){const ms=parseDuration(i.options.getString("duree",true));if(!ms)return i.reply({content:"❌ Durée invalide. Ex: `10m`, `2h`, `1d`.",ephemeral:true});const winners=i.options.getInteger("gagnants",true),prize=i.options.getString("prix",true),ch=i.options.getChannel("salon")||i.channel;const ends=Date.now()+ms;const e=new EmbedBuilder().setTitle("🎉 GIVEAWAY").setDescription(`**Prix :** ${prize}\n**Gagnant(s) :** ${winners}\n**Fin :** <t:${Math.floor(ends/1000)}:R>\n**Organisé par :** ${i.user}`).setColor(0xFEE75C);const msg=await ch.send({embeds:[e],components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("legacy:giveaway:pending").setLabel("Participer").setEmoji("🎉").setStyle(ButtonStyle.Primary))]});await msg.edit({components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`legacy:giveaway:${msg.id}`).setLabel("Participer").setEmoji("🎉").setStyle(ButtonStyle.Primary))]});db.prepare("INSERT INTO legacy_giveaways(message_id,guild_id,channel_id,host_id,prize,winner_count,ends_at) VALUES(?,?,?,?,?,?,?)").run(msg.id,i.guild.id,ch.id,i.user.id,prize,winners,ends);this.scheduleGiveaway({message_id:msg.id,ends_at:ends});return i.reply({content:`✅ Giveaway créé : ${msg.url}`,ephemeral:true});}
  async finishGiveawayById(id){const g=db.prepare("SELECT * FROM legacy_giveaways WHERE message_id=? AND ended=0").get(id);if(!g)return;const guild=this.client.guilds.cache.get(g.guild_id);const ch=guild?.channels.cache.get(g.channel_id);const entries=db.prepare("SELECT user_id FROM legacy_giveaway_entries WHERE message_id=?").all(id).map(x=>x.user_id);const shuffled=entries.sort(()=>Math.random()-0.5);const winners=shuffled.slice(0,g.winner_count);db.prepare("UPDATE legacy_giveaways SET ended=1 WHERE message_id=?").run(id);if(ch){const msg=await ch.messages.fetch(id).catch(()=>null);if(msg)await msg.edit({components:[]}).catch(()=>{});await ch.send(winners.length?`🎉 Félicitations ${winners.map(x=>`<@${x}>`).join(", ")} ! Vous gagnez **${g.prize}**.`:`😕 Giveaway terminé : aucune participation pour **${g.prize}**.`).catch(()=>{});}}
  async endGiveaway(i,id){const g=db.prepare("SELECT * FROM legacy_giveaways WHERE message_id=? AND ended=0").get(id);if(!g)return i.reply({content:"❌ Giveaway introuvable ou déjà terminé.",ephemeral:true});await this.finishGiveawayById(id);return i.reply({content:"✅ Giveaway terminé.",ephemeral:true});}
  async rerollGiveaway(i,id){const g=db.prepare("SELECT * FROM legacy_giveaways WHERE message_id=?").get(id);if(!g)return i.reply({content:"❌ Giveaway introuvable.",ephemeral:true});const entries=db.prepare("SELECT user_id FROM legacy_giveaway_entries WHERE message_id=?").all(id);if(!entries.length)return i.reply({content:"❌ Aucun participant.",ephemeral:true});const w=entries[Math.floor(Math.random()*entries.length)].user_id;return i.reply({content:`🎉 Nouveau gagnant : <@${w}> pour **${g.prize}** !`});}
}
