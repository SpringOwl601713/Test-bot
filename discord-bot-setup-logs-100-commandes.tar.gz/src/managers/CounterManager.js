import { ChannelType, PermissionFlagsBits } from "discord.js";
import db from "../database/Database.js";

const DEFAULTS = {
  total: "👥 Tous les membres: {valeur}",
  members: "👤 Membres: {valeur}",
  bots: "🤖 Bots: {valeur}",
  online: "🟢 En ligne: {valeur}",
  offline: "⚫ Hors ligne: {valeur}",
  datetime: "🕐 {valeur}"
};

export class CounterManager {
  constructor(client) { this.client = client; this.timer = null; this.pending = new Map(); }
  getSettings(guildId) { return db.prepare("SELECT * FROM counter_settings WHERE guild_id=?").get(guildId) || null; }
  setEnabled(guildId, enabled) { db.prepare("UPDATE counter_settings SET enabled=?,updated_at=unixepoch() WHERE guild_id=?").run(enabled ? 1 : 0, guildId); }
  async start() {
    for (const guild of this.client.guilds.cache.values()) await this.refresh(guild, true).catch(() => {});
    this.timer = setInterval(() => {
      for (const guild of this.client.guilds.cache.values()) this.refresh(guild).catch(() => {});
    }, 10 * 60 * 1000);
  }
  async configure(guild, opts) {
    let categoryId = opts.categoryId;
    if (!categoryId) {
      const cat = await guild.channels.create({ name: "📊・STATS DU SERVEUR", type: ChannelType.GuildCategory });
      categoryId = cat.id;
    }
    const old = this.getSettings(guild.id);
    db.prepare(`INSERT INTO counter_settings(
      guild_id,enabled,category_id,total_enabled,members_enabled,bots_enabled,online_enabled,offline_enabled,datetime_enabled,
      total_name,members_name,bots_name,online_name,offline_name,datetime_name,updated_at
    ) VALUES(?,1,?,?,?,?,?,?,?,?,?,?,?,?,?,unixepoch())
    ON CONFLICT(guild_id) DO UPDATE SET enabled=1,category_id=excluded.category_id,total_enabled=excluded.total_enabled,
      members_enabled=excluded.members_enabled,bots_enabled=excluded.bots_enabled,online_enabled=excluded.online_enabled,
      offline_enabled=excluded.offline_enabled,datetime_enabled=excluded.datetime_enabled,total_name=excluded.total_name,
      members_name=excluded.members_name,bots_name=excluded.bots_name,online_name=excluded.online_name,offline_name=excluded.offline_name,
      datetime_name=excluded.datetime_name,updated_at=unixepoch()`)
      .run(guild.id, categoryId,
        opts.total ?? old?.total_enabled ?? 1, opts.members ?? old?.members_enabled ?? 1, opts.bots ?? old?.bots_enabled ?? 1,
        opts.online ?? old?.online_enabled ?? 1, opts.offline ?? old?.offline_enabled ?? 1, opts.datetime ?? old?.datetime_enabled ?? 1,
        opts.totalName || old?.total_name || DEFAULTS.total, opts.membersName || old?.members_name || DEFAULTS.members,
        opts.botsName || old?.bots_name || DEFAULTS.bots, opts.onlineName || old?.online_name || DEFAULTS.online,
        opts.offlineName || old?.offline_name || DEFAULTS.offline, opts.datetimeName || old?.datetime_name || DEFAULTS.datetime);
    await this.refresh(guild, true);
    return this.getSettings(guild.id);
  }
  schedule(guild) {
    clearTimeout(this.pending.get(guild.id));
    this.pending.set(guild.id, setTimeout(() => { this.pending.delete(guild.id); this.refresh(guild).catch(() => {}); }, 2 * 60 * 1000));
  }
  async refresh(guild, force=false) {
    const st = this.getSettings(guild.id); if (!st || (!st.enabled && !force)) return;
    const category = guild.channels.cache.get(st.category_id) || await guild.channels.fetch(st.category_id).catch(() => null);
    if (!category || category.type !== ChannelType.GuildCategory) return;
    await guild.members.fetch({ withPresences: true }).catch(() => guild.members.fetch().catch(() => null));
    const all = [...guild.members.cache.values()];
    const total = guild.memberCount;
    const bots = all.filter(m => m.user.bot).length;
    const members = Math.max(0, total - bots);
    const online = all.filter(m => !m.user.bot && m.presence && m.presence.status !== "offline").length;
    const offline = Math.max(0, members - online);
    const date = new Intl.DateTimeFormat("fr-FR", { timeZone:"Europe/Paris", day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit", hour12:false }).format(new Date()).replace(",", " •");
    const items = [
      ["total", st.total_enabled, st.total_name, total], ["members", st.members_enabled, st.members_name, members],
      ["bots", st.bots_enabled, st.bots_name, bots], ["online", st.online_enabled, st.online_name, online],
      ["offline", st.offline_enabled, st.offline_name, offline], ["datetime", st.datetime_enabled, st.datetime_name, date]
    ];
    for (const [key, enabled, pattern, value] of items) {
      let channelId = st[`${key}_channel_id`];
      let channel = channelId ? (guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null)) : null;
      if (!enabled) { if (channel) await channel.delete("Compteur désactivé").catch(() => {}); if (channelId) db.prepare(`UPDATE counter_settings SET ${key}_channel_id=NULL WHERE guild_id=?`).run(guild.id); continue; }
      const name = String(pattern || DEFAULTS[key]).replaceAll("{valeur}", String(value)).slice(0, 100);
      if (!channel) {
        channel = await guild.channels.create({ name, type: ChannelType.GuildVoice, parent: category.id,
          permissionOverwrites: [{ id:guild.roles.everyone.id, deny:[PermissionFlagsBits.Connect], allow:[PermissionFlagsBits.ViewChannel] }] });
        db.prepare(`UPDATE counter_settings SET ${key}_channel_id=? WHERE guild_id=?`).run(channel.id, guild.id);
      } else if (channel.name !== name) await channel.setName(name, "Actualisation des compteurs").catch(() => {});
      if (channel.parentId !== category.id) await channel.setParent(category.id).catch(() => {});
    }
    db.prepare("UPDATE counter_settings SET updated_at=unixepoch() WHERE guild_id=?").run(guild.id);
  }
}
