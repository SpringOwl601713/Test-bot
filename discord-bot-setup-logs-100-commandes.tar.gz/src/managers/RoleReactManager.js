import db from "../database/Database.js";

const getStmt = db.prepare(`
    SELECT guild_id, target_message_id, channel_id, menu_message_id, options_json
    FROM role_react_panels
    WHERE guild_id = ? AND target_message_id = ?
`);

const upsertStmt = db.prepare(`
    INSERT INTO role_react_panels (
        guild_id, target_message_id, channel_id, menu_message_id, options_json, updated_at
    ) VALUES (?, ?, ?, ?, ?, unixepoch())
    ON CONFLICT(guild_id, target_message_id) DO UPDATE SET
        channel_id = excluded.channel_id,
        menu_message_id = excluded.menu_message_id,
        options_json = excluded.options_json,
        updated_at = unixepoch()
`);

function parseOptions(raw) {
    try {
        const parsed = JSON.parse(raw || "[]");
        return Array.isArray(parsed) ? parsed : [];
    } catch {
        return [];
    }
}

export class RoleReactManager {
    static get(guildId, targetMessageId) {
        const row = getStmt.get(guildId, targetMessageId);
        if (!row) return null;
        return {
            guildId: row.guild_id,
            targetMessageId: row.target_message_id,
            channelId: row.channel_id,
            menuMessageId: row.menu_message_id,
            options: parseOptions(row.options_json)
        };
    }

    static save(guildId, targetMessageId, channelId, menuMessageId, options) {
        upsertStmt.run(
            guildId,
            targetMessageId,
            channelId,
            menuMessageId,
            JSON.stringify(options)
        );
        return this.get(guildId, targetMessageId);
    }
}
