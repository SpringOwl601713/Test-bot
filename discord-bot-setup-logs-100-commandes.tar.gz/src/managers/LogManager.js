import {
    AuditLogEvent,
    ChannelType,
    EmbedBuilder,
    Events,
    PermissionFlagsBits
} from "discord.js";
import db from "../database/Database.js";

const CHANNEL_KEYS = {
    moderation: "moderation_channel_id",
    messages: "messages_channel_id",
    members: "members_channel_id",
    voice: "voice_channel_id",
    server: "server_channel_id",
    invites: "invites_channel_id",
    commands: "commands_channel_id"
};

const CHANNEL_NAMES = {
    moderation: "🛡️・moderation",
    messages: "💬・messages",
    members: "👥・membres",
    voice: "🔊・vocal",
    server: "⚙️・serveur",
    invites: "🔗・invitations",
    commands: "⌨️・commandes"
};

function short(value, max = 1000) {
    const text = String(value ?? "").trim() || "Aucun";
    return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function mentionUser(user) {
    return user ? `${user} (${user.tag || user.username || user.id})` : "Inconnu";
}

function channelLabel(channel) {
    if (!channel) return "Inconnu";
    return `${channel} (${channel.name || channel.id})`;
}

export class LogManager {
    constructor(client) {
        this.client = client;
        this.bound = false;
    }

    getSettings(guildId) {
        return db.prepare("SELECT * FROM server_log_settings WHERE guild_id = ?").get(guildId) || null;
    }

    saveSettings(guildId, values) {
        const current = this.getSettings(guildId) || {};
        const data = {
            enabled: values.enabled ?? current.enabled ?? 1,
            category_id: values.category_id ?? current.category_id ?? null,
            moderation_channel_id: values.moderation_channel_id ?? current.moderation_channel_id ?? null,
            messages_channel_id: values.messages_channel_id ?? current.messages_channel_id ?? null,
            members_channel_id: values.members_channel_id ?? current.members_channel_id ?? null,
            voice_channel_id: values.voice_channel_id ?? current.voice_channel_id ?? null,
            server_channel_id: values.server_channel_id ?? current.server_channel_id ?? null,
            invites_channel_id: values.invites_channel_id ?? current.invites_channel_id ?? null,
            commands_channel_id: values.commands_channel_id ?? current.commands_channel_id ?? null,
            viewer_role_id: values.viewer_role_id ?? current.viewer_role_id ?? null
        };
        db.prepare(`
            INSERT INTO server_log_settings (
                guild_id, enabled, category_id, moderation_channel_id, messages_channel_id,
                members_channel_id, voice_channel_id, server_channel_id, invites_channel_id,
                commands_channel_id, viewer_role_id, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, unixepoch())
            ON CONFLICT(guild_id) DO UPDATE SET
                enabled=excluded.enabled,
                category_id=excluded.category_id,
                moderation_channel_id=excluded.moderation_channel_id,
                messages_channel_id=excluded.messages_channel_id,
                members_channel_id=excluded.members_channel_id,
                voice_channel_id=excluded.voice_channel_id,
                server_channel_id=excluded.server_channel_id,
                invites_channel_id=excluded.invites_channel_id,
                commands_channel_id=excluded.commands_channel_id,
                viewer_role_id=excluded.viewer_role_id,
                updated_at=unixepoch()
        `).run(
            guildId, data.enabled ? 1 : 0, data.category_id, data.moderation_channel_id,
            data.messages_channel_id, data.members_channel_id, data.voice_channel_id,
            data.server_channel_id, data.invites_channel_id, data.commands_channel_id,
            data.viewer_role_id
        );
        return this.getSettings(guildId);
    }

    async setup(guild, viewerRole = null) {
        const me = guild.members.me || await guild.members.fetchMe();
        if (!me.permissions.has(PermissionFlagsBits.ManageChannels)) {
            throw new Error("MISSING_MANAGE_CHANNELS");
        }

        const current = this.getSettings(guild.id);
        const savedViewerRole = !viewerRole && current?.viewer_role_id ? guild.roles.cache.get(current.viewer_role_id) : null;
        const effectiveViewerRole = viewerRole || savedViewerRole || null;
        let category = current?.category_id ? guild.channels.cache.get(current.category_id) : null;
        const overwrites = [
            { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
            {
                id: me.id,
                allow: [
                    PermissionFlagsBits.ViewChannel,
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.EmbedLinks,
                    PermissionFlagsBits.ReadMessageHistory,
                    PermissionFlagsBits.ManageMessages
                ]
            }
        ];
        if (effectiveViewerRole) {
            overwrites.push({
                id: effectiveViewerRole.id,
                allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory]
            });
        }

        if (!category || category.type !== ChannelType.GuildCategory) {
            category = await guild.channels.create({
                name: "📜・LOGS SERVEUR",
                type: ChannelType.GuildCategory,
                permissionOverwrites: overwrites,
                reason: "Configuration automatique des logs via /setup-logs"
            });
        } else {
            await category.permissionOverwrites.set(overwrites, "Mise à jour des permissions /setup-logs").catch(() => {});
        }

        const ids = {};
        for (const [kind, dbKey] of Object.entries(CHANNEL_KEYS)) {
            let channel = current?.[dbKey] ? guild.channels.cache.get(current[dbKey]) : null;
            if (!channel || channel.type !== ChannelType.GuildText) {
                channel = await guild.channels.create({
                    name: CHANNEL_NAMES[kind],
                    type: ChannelType.GuildText,
                    parent: category.id,
                    permissionOverwrites: overwrites,
                    reason: `Salon de logs ${kind} via /setup-logs`
                });
            } else {
                if (channel.parentId !== category.id) await channel.setParent(category.id, { lockPermissions: false }).catch(() => {});
                await channel.permissionOverwrites.set(overwrites, "Mise à jour des permissions /setup-logs").catch(() => {});
            }
            ids[dbKey] = channel.id;
        }

        return this.saveSettings(guild.id, {
            enabled: 1,
            category_id: category.id,
            viewer_role_id: effectiveViewerRole?.id || null,
            ...ids
        });
    }

    setEnabled(guildId, enabled) {
        if (!this.getSettings(guildId)) return null;
        return this.saveSettings(guildId, { enabled: enabled ? 1 : 0 });
    }

    isLogChannel(guildId, channelId) {
        const s = this.getSettings(guildId);
        if (!s || !channelId) return false;
        return Object.values(CHANNEL_KEYS).some(key => s[key] === channelId);
    }

    async send(guild, kind, { title, description, fields = [], color = 0x5865F2, thumbnail = null } = {}) {
        if (!guild) return;
        const s = this.getSettings(guild.id);
        if (!s || !s.enabled) return;
        const key = CHANNEL_KEYS[kind] || CHANNEL_KEYS.server;
        const channel = guild.channels.cache.get(s[key]);
        if (!channel?.isTextBased?.()) return;

        const embed = new EmbedBuilder()
            .setColor(color)
            .setTitle(short(title || "Log serveur", 256))
            .setDescription(description ? short(description, 4000) : null)
            .setTimestamp();
        if (thumbnail) embed.setThumbnail(thumbnail);
        if (fields.length) embed.addFields(fields.slice(0, 25).map(f => ({ name: short(f.name, 256), value: short(f.value, 1024), inline: Boolean(f.inline) })));
        await channel.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => {});
    }

    async findAudit(guild, type, targetId) {
        if (!guild?.members?.me?.permissions?.has(PermissionFlagsBits.ViewAuditLog)) return null;
        try {
            const logs = await guild.fetchAuditLogs({ type, limit: 6 });
            const now = Date.now();
            return logs.entries.find(entry => {
                const targetMatches = !targetId || entry.target?.id === targetId || entry.targetId === targetId;
                return targetMatches && now - entry.createdTimestamp < 10000;
            }) || null;
        } catch {
            return null;
        }
    }

    async logAuditAction(guild, kind, type, targetId, title, extraFields = [], color = 0xED4245) {
        const audit = await this.findAudit(guild, type, targetId);
        const fields = [...extraFields];
        if (audit?.executor) fields.push({ name: "Auteur", value: mentionUser(audit.executor) });
        if (audit?.reason) fields.push({ name: "Raison", value: audit.reason });
        return this.send(guild, kind, { title, fields, color });
    }

    start() {
        if (this.bound) return;
        this.bound = true;
        const c = this.client;

        c.on(Events.MessageDelete, async message => {
            const guild = message.guild;
            if (!guild || this.isLogChannel(guild.id, message.channelId)) return;
            await this.send(guild, "messages", {
                title: "🗑️ Message supprimé",
                color: 0xED4245,
                fields: [
                    { name: "Auteur", value: message.author ? mentionUser(message.author) : "Inconnu" },
                    { name: "Salon", value: channelLabel(message.channel) },
                    { name: "Contenu", value: short(message.content || "Contenu indisponible", 1024) },
                    { name: "ID du message", value: message.id || "Inconnu" }
                ]
            });
        });

        c.on(Events.MessageBulkDelete, async messages => {
            const first = messages.first();
            if (!first?.guild || this.isLogChannel(first.guild.id, first.channelId)) return;
            await this.send(first.guild, "messages", {
                title: "🧹 Suppression massive de messages",
                color: 0xED4245,
                fields: [
                    { name: "Salon", value: channelLabel(first.channel) },
                    { name: "Nombre", value: String(messages.size) }
                ]
            });
        });

        c.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
            const guild = newMessage.guild || oldMessage.guild;
            if (!guild || newMessage.author?.bot || this.isLogChannel(guild.id, newMessage.channelId)) return;
            const before = oldMessage.content;
            const after = newMessage.content;
            if (before === after || (!before && !after)) return;
            await this.send(guild, "messages", {
                title: "✏️ Message modifié",
                color: 0xFEE75C,
                fields: [
                    { name: "Auteur", value: newMessage.author ? mentionUser(newMessage.author) : "Inconnu" },
                    { name: "Salon", value: channelLabel(newMessage.channel) },
                    { name: "Avant", value: short(before || "Indisponible", 1024) },
                    { name: "Après", value: short(after || "Indisponible", 1024) },
                    { name: "Lien", value: newMessage.url || "Indisponible" }
                ]
            });
        });

        c.on(Events.GuildMemberAdd, member => this.send(member.guild, "members", {
            title: "📥 Membre arrivé",
            color: 0x57F287,
            thumbnail: member.user.displayAvatarURL(),
            fields: [
                { name: "Membre", value: mentionUser(member.user) },
                { name: "Compte créé", value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>` },
                { name: "ID", value: member.id }
            ]
        }));

        c.on(Events.GuildMemberRemove, async member => {
            const audit = await this.findAudit(member.guild, AuditLogEvent.MemberKick, member.id);
            const kicked = Boolean(audit);
            await this.send(member.guild, kicked ? "moderation" : "members", {
                title: kicked ? "👢 Membre expulsé" : "📤 Membre parti",
                color: kicked ? 0xED4245 : 0xFEE75C,
                thumbnail: member.user.displayAvatarURL(),
                fields: [
                    { name: "Membre", value: mentionUser(member.user) },
                    ...(audit?.executor ? [{ name: "Auteur", value: mentionUser(audit.executor) }] : []),
                    ...(audit?.reason ? [{ name: "Raison", value: audit.reason }] : []),
                    { name: "ID", value: member.id }
                ]
            });
        });

        c.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
            const fields = [];
            if (oldMember.nickname !== newMember.nickname) fields.push({ name: "Pseudo", value: `${oldMember.nickname || oldMember.user.username} → ${newMember.nickname || newMember.user.username}` });
            const added = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id) && r.id !== newMember.guild.id);
            const removed = oldMember.roles.cache.filter(r => !newMember.roles.cache.has(r.id) && r.id !== newMember.guild.id);
            if (added.size) fields.push({ name: "Rôle(s) ajouté(s)", value: added.map(r => `${r}`).join(", ") });
            if (removed.size) fields.push({ name: "Rôle(s) retiré(s)", value: removed.map(r => `${r}`).join(", ") });
            const oldTimeout = oldMember.communicationDisabledUntilTimestamp || 0;
            const newTimeout = newMember.communicationDisabledUntilTimestamp || 0;
            if (oldTimeout !== newTimeout) fields.push({ name: "Timeout", value: newTimeout > Date.now() ? `Jusqu'à <t:${Math.floor(newTimeout / 1000)}:F>` : "Retiré" });
            if (!fields.length) return;
            const audit = await this.findAudit(newMember.guild, AuditLogEvent.MemberUpdate, newMember.id);
            if (audit?.executor) fields.push({ name: "Auteur", value: mentionUser(audit.executor) });
            await this.send(newMember.guild, "members", { title: "👤 Membre modifié", fields, color: 0x5865F2, thumbnail: newMember.user.displayAvatarURL() });
        });

        c.on(Events.GuildBanAdd, ban => this.logAuditAction(ban.guild, "moderation", AuditLogEvent.MemberBanAdd, ban.user.id, "🔨 Membre banni", [
            { name: "Membre", value: mentionUser(ban.user) },
            ...(ban.reason ? [{ name: "Raison Discord", value: ban.reason }] : [])
        ]));
        c.on(Events.GuildBanRemove, ban => this.logAuditAction(ban.guild, "moderation", AuditLogEvent.MemberBanRemove, ban.user.id, "♻️ Membre débanni", [
            { name: "Membre", value: mentionUser(ban.user) }
        ], 0x57F287));

        c.on(Events.ChannelCreate, channel => this.logAuditAction(channel.guild, "server", AuditLogEvent.ChannelCreate, channel.id, "➕ Salon créé", [
            { name: "Salon", value: channelLabel(channel) },
            { name: "Type", value: String(channel.type) }
        ], 0x57F287));
        c.on(Events.ChannelDelete, channel => this.logAuditAction(channel.guild, "server", AuditLogEvent.ChannelDelete, channel.id, "➖ Salon supprimé", [
            { name: "Salon", value: `#${channel.name || channel.id}` }
        ]));
        c.on(Events.ChannelUpdate, async (oldChannel, newChannel) => {
            if (!newChannel.guild || oldChannel.name === newChannel.name && oldChannel.parentId === newChannel.parentId && oldChannel.topic === newChannel.topic) return;
            await this.logAuditAction(newChannel.guild, "server", AuditLogEvent.ChannelUpdate, newChannel.id, "🛠️ Salon modifié", [
                { name: "Salon", value: channelLabel(newChannel) },
                { name: "Ancien nom", value: oldChannel.name || "Aucun" },
                { name: "Nouveau nom", value: newChannel.name || "Aucun" }
            ], 0xFEE75C);
        });

        c.on(Events.GuildRoleCreate, role => this.logAuditAction(role.guild, "server", AuditLogEvent.RoleCreate, role.id, "➕ Rôle créé", [{ name: "Rôle", value: `${role} (${role.name})` }], 0x57F287));
        c.on(Events.GuildRoleDelete, role => this.logAuditAction(role.guild, "server", AuditLogEvent.RoleDelete, role.id, "➖ Rôle supprimé", [{ name: "Rôle", value: role.name }]));
        c.on(Events.GuildRoleUpdate, async (oldRole, newRole) => {
            if (oldRole.name === newRole.name && oldRole.color === newRole.color && oldRole.permissions.bitfield === newRole.permissions.bitfield) return;
            await this.logAuditAction(newRole.guild, "server", AuditLogEvent.RoleUpdate, newRole.id, "🛠️ Rôle modifié", [
                { name: "Rôle", value: `${newRole} (${newRole.name})` },
                { name: "Ancien nom", value: oldRole.name },
                { name: "Nouveau nom", value: newRole.name }
            ], 0xFEE75C);
        });

        c.on(Events.GuildEmojiCreate, emoji => this.logAuditAction(emoji.guild, "server", AuditLogEvent.EmojiCreate, emoji.id, "😀 Emoji créé", [{ name: "Emoji", value: `${emoji} ${emoji.name}` }], 0x57F287));
        c.on(Events.GuildEmojiDelete, emoji => this.logAuditAction(emoji.guild, "server", AuditLogEvent.EmojiDelete, emoji.id, "🗑️ Emoji supprimé", [{ name: "Emoji", value: emoji.name || emoji.id }]));
        c.on(Events.GuildEmojiUpdate, (oldEmoji, newEmoji) => this.logAuditAction(newEmoji.guild, "server", AuditLogEvent.EmojiUpdate, newEmoji.id, "✏️ Emoji modifié", [
            { name: "Avant", value: oldEmoji.name || "Inconnu" }, { name: "Après", value: newEmoji.name || "Inconnu" }
        ], 0xFEE75C));

        c.on(Events.GuildStickerCreate, sticker => this.send(sticker.guild, "server", { title: "🏷️ Sticker créé", color: 0x57F287, fields: [{ name: "Sticker", value: sticker.name }] }));
        c.on(Events.GuildStickerDelete, sticker => this.send(sticker.guild, "server", { title: "🏷️ Sticker supprimé", color: 0xED4245, fields: [{ name: "Sticker", value: sticker.name }] }));
        c.on(Events.GuildStickerUpdate, (oldSticker, newSticker) => this.send(newSticker.guild, "server", { title: "🏷️ Sticker modifié", color: 0xFEE75C, fields: [{ name: "Avant", value: oldSticker.name }, { name: "Après", value: newSticker.name }] }));

        c.on(Events.InviteCreate, invite => this.send(invite.guild, "invites", {
            title: "🔗 Invitation créée",
            color: 0x57F287,
            fields: [
                { name: "Code", value: invite.code },
                { name: "Créateur", value: invite.inviter ? mentionUser(invite.inviter) : "Inconnu" },
                { name: "Salon", value: channelLabel(invite.channel) },
                { name: "Utilisations max", value: invite.maxUses ? String(invite.maxUses) : "Illimitées" }
            ]
        }));
        c.on(Events.InviteDelete, invite => this.send(invite.guild, "invites", {
            title: "🗑️ Invitation supprimée",
            color: 0xED4245,
            fields: [{ name: "Code", value: invite.code }, { name: "Salon", value: channelLabel(invite.channel) }]
        }));

        c.on(Events.VoiceStateUpdate, async (oldState, newState) => {
            const member = newState.member || oldState.member;
            const guild = newState.guild || oldState.guild;
            if (!guild || !member) return;
            const fields = [{ name: "Membre", value: `${member} (${member.user.tag})` }];
            let title = null;
            if (!oldState.channelId && newState.channelId) {
                title = "🔊 Connexion vocale";
                fields.push({ name: "Salon", value: channelLabel(newState.channel) });
            } else if (oldState.channelId && !newState.channelId) {
                title = "🔇 Déconnexion vocale";
                fields.push({ name: "Salon", value: channelLabel(oldState.channel) });
            } else if (oldState.channelId !== newState.channelId) {
                title = "🔁 Déplacement vocal";
                fields.push({ name: "Avant", value: channelLabel(oldState.channel) }, { name: "Après", value: channelLabel(newState.channel) });
            } else {
                const changes = [];
                if (oldState.serverMute !== newState.serverMute) changes.push(`Mute serveur: ${newState.serverMute ? "oui" : "non"}`);
                if (oldState.serverDeaf !== newState.serverDeaf) changes.push(`Sourdine serveur: ${newState.serverDeaf ? "oui" : "non"}`);
                if (oldState.streaming !== newState.streaming) changes.push(`Stream: ${newState.streaming ? "démarré" : "arrêté"}`);
                if (oldState.selfVideo !== newState.selfVideo) changes.push(`Caméra: ${newState.selfVideo ? "activée" : "désactivée"}`);
                if (!changes.length) return;
                title = "🎙️ État vocal modifié";
                fields.push({ name: "Changements", value: changes.join("\n") });
            }
            await this.send(guild, "voice", { title, fields, color: 0x5865F2 });
        });

        c.on(Events.ThreadCreate, thread => this.send(thread.guild, "server", { title: "🧵 Fil créé", color: 0x57F287, fields: [{ name: "Fil", value: channelLabel(thread) }, { name: "Parent", value: channelLabel(thread.parent) }] }));
        c.on(Events.ThreadDelete, thread => this.send(thread.guild, "server", { title: "🧵 Fil supprimé", color: 0xED4245, fields: [{ name: "Fil", value: thread.name }] }));
        c.on(Events.ThreadUpdate, (oldThread, newThread) => {
            if (oldThread.name === newThread.name && oldThread.archived === newThread.archived && oldThread.locked === newThread.locked) return;
            return this.send(newThread.guild, "server", { title: "🧵 Fil modifié", color: 0xFEE75C, fields: [{ name: "Fil", value: channelLabel(newThread) }] });
        });

        c.on(Events.GuildUpdate, async (oldGuild, newGuild) => {
            const changes = [];
            if (oldGuild.name !== newGuild.name) changes.push({ name: "Nom", value: `${oldGuild.name} → ${newGuild.name}` });
            if (oldGuild.icon !== newGuild.icon) changes.push({ name: "Icône", value: "Modifiée" });
            if (oldGuild.banner !== newGuild.banner) changes.push({ name: "Bannière", value: "Modifiée" });
            if (oldGuild.verificationLevel !== newGuild.verificationLevel) changes.push({ name: "Niveau de vérification", value: `${oldGuild.verificationLevel} → ${newGuild.verificationLevel}` });
            if (!changes.length) return;
            const audit = await this.findAudit(newGuild, AuditLogEvent.GuildUpdate, newGuild.id);
            if (audit?.executor) changes.push({ name: "Auteur", value: mentionUser(audit.executor) });
            await this.send(newGuild, "server", { title: "⚙️ Serveur modifié", color: 0xFEE75C, fields: changes });
        });

        c.on(Events.WebhooksUpdate, channel => this.send(channel.guild, "server", {
            title: "🪝 Webhooks modifiés",
            color: 0xFEE75C,
            fields: [{ name: "Salon", value: channelLabel(channel) }]
        }));

        c.on(Events.GuildScheduledEventCreate, event => this.send(event.guild, "server", { title: "📅 Événement créé", color: 0x57F287, fields: [{ name: "Événement", value: event.name }, { name: "ID", value: event.id }] }));
        c.on(Events.GuildScheduledEventDelete, event => this.send(event.guild, "server", { title: "📅 Événement supprimé", color: 0xED4245, fields: [{ name: "Événement", value: event.name }] }));
        c.on(Events.GuildScheduledEventUpdate, (oldEvent, newEvent) => this.send(newEvent.guild, "server", { title: "📅 Événement modifié", color: 0xFEE75C, fields: [{ name: "Événement", value: newEvent.name }] }));

        c.on(Events.InteractionCreate, interaction => {
            if (!interaction.guild || !interaction.isChatInputCommand?.() || interaction.commandName === "setup-logs") return;
            return this.send(interaction.guild, "commands", {
                title: "⌨️ Commande slash utilisée",
                color: 0x5865F2,
                fields: [
                    { name: "Utilisateur", value: mentionUser(interaction.user) },
                    { name: "Commande", value: `/${interaction.commandName}` },
                    { name: "Salon", value: interaction.channel ? channelLabel(interaction.channel) : "Inconnu" }
                ]
            });
        });
    }

    async sendTest(guild) {
        await this.send(guild, "server", {
            title: "✅ Test des logs réussi",
            color: 0x57F287,
            description: "Le système de logs est correctement configuré et peut envoyer des messages dans les salons dédiés."
        });
    }
}
