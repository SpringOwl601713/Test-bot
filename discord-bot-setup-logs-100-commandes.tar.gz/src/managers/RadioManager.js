import {
    AudioPlayerStatus,
    NoSubscriberBehavior,
    VoiceConnectionStatus,
    createAudioPlayer,
    createAudioResource,
    entersState,
    getVoiceConnection,
    joinVoiceChannel
} from "@discordjs/voice";
import { ChannelType, PermissionFlagsBits } from "discord.js";

// Flux radio directs. Ils sont séparés du système musique : aucune recherche YouTube
// ni discord-player n'est utilisée.
export const RADIO_STATIONS = {
    nrj: {
        name: "NRJ",
        url: "https://cdn.nrjaudio.fm/audio1/fr/30001/mp3_128.mp3?origine=nexora"
    },
    skyrock: {
        name: "Skyrock",
        url: "https://icecast.skyrock.net/s/natio_mp3_128k"
    },
    funradio: {
        name: "Fun Radio",
        url: "http://icecast.funradio.fr/fun-1-44-128"
    },
    virginradio: {
        name: "Virgin Radio",
        url: "https://virginrocklive.ice.infomaniak.ch/virgin-radio-rock-live.mp3"
    },
    autoroute1077: {
        name: "107.7 Radio d'autoroute (Sanef)",
        url: "https://sanef.ice.infomaniak.ch/sanef1077-nord.mp3"
    }
};

export class RadioManager {
    constructor() {
        this.players = new Map();
    }

    stop(guildId) {
        const player = this.players.get(guildId);
        if (player) {
            try { player.stop(true); } catch {}
            this.players.delete(guildId);
        }
    }

    async play(interaction, key) {
        const station = RADIO_STATIONS[key];
        if (!station) throw new Error("Station inconnue");

        const member = interaction.member;
        const channel = member?.voice?.channel;
        if (!channel || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)) {
            return interaction.reply({ content: "❌ Tu dois d’abord rejoindre un salon vocal.", ephemeral: true });
        }

        const me = interaction.guild.members.me;
        const permissions = channel.permissionsFor(me);
        if (!permissions?.has(PermissionFlagsBits.ViewChannel) || !permissions?.has(PermissionFlagsBits.Connect)) {
            return interaction.reply({ content: "❌ Je n’ai pas la permission de voir ou rejoindre ton salon vocal.", ephemeral: true });
        }
        if (channel.type === ChannelType.GuildVoice && !permissions.has(PermissionFlagsBits.Speak)) {
            return interaction.reply({ content: "❌ Je n’ai pas la permission **Parler** dans ton salon vocal.", ephemeral: true });
        }

        await interaction.deferReply();

        let connection = getVoiceConnection(interaction.guild.id);
        if (connection && connection.joinConfig.channelId !== channel.id) {
            connection.destroy();
            connection = null;
        }
        if (!connection) {
            connection = joinVoiceChannel({
                channelId: channel.id,
                guildId: interaction.guild.id,
                adapterCreator: interaction.guild.voiceAdapterCreator,
                selfDeaf: true,
                selfMute: false
            });
        }

        await entersState(connection, VoiceConnectionStatus.Ready, 20_000);
        this.stop(interaction.guild.id);

        const player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Pause } });
        player.on("error", async error => {
            console.error(`❌ [RADIO/${station.name}]`, error);
            this.stop(interaction.guild.id);
        });
        player.on(AudioPlayerStatus.Idle, () => this.stop(interaction.guild.id));

        const resource = createAudioResource(station.url);
        connection.subscribe(player);
        player.play(resource);
        this.players.set(interaction.guild.id, player);

        try {
            await entersState(player, AudioPlayerStatus.Playing, 20_000);
            return interaction.editReply(`📻 **${station.name}** est maintenant diffusée dans ${channel}.`);
        } catch (error) {
            console.error(`❌ [RADIO/${station.name}/START]`, error);
            this.stop(interaction.guild.id);
            return interaction.editReply("❌ Impossible de démarrer cette radio pour le moment. Le flux peut être temporairement indisponible.");
        }
    }
}
