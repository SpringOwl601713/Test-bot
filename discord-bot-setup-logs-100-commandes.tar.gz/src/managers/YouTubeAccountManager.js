import db from "../database/Database.js";

const listStatement = db.prepare(`SELECT channel_name AS channelName, youtube_channel_id AS youtubeChannelId, notify_channel_id AS notifyChannelId, ping_role_id AS pingRoleId, embed_title AS embedTitle, embed_description AS embedDescription, embed_color AS embedColor, image_url AS imageUrl, COALESCE(enabled,1) AS enabled FROM youtube_accounts WHERE guild_id = ? ORDER BY channel_name COLLATE NOCASE ASC`);
const getStatement = db.prepare(`SELECT channel_name AS channelName, youtube_channel_id AS youtubeChannelId, notify_channel_id AS notifyChannelId, ping_role_id AS pingRoleId, embed_title AS embedTitle, embed_description AS embedDescription, embed_color AS embedColor, image_url AS imageUrl, COALESCE(enabled,1) AS enabled FROM youtube_accounts WHERE guild_id = ? AND channel_name = ?`);
const upsertStatement = db.prepare(`INSERT INTO youtube_accounts (guild_id,channel_name,youtube_channel_id,notify_channel_id,ping_role_id,embed_title,embed_description,embed_color,image_url,enabled,updated_at) VALUES (?,?,?,?,?,?,?,?,?,1,unixepoch()) ON CONFLICT(guild_id,channel_name) DO UPDATE SET youtube_channel_id=excluded.youtube_channel_id,notify_channel_id=excluded.notify_channel_id,ping_role_id=excluded.ping_role_id,embed_title=excluded.embed_title,embed_description=excluded.embed_description,embed_color=excluded.embed_color,image_url=excluded.image_url,enabled=1,updated_at=unixepoch()`);
const removeStatement = db.prepare(`DELETE FROM youtube_accounts WHERE guild_id=? AND channel_name=?`);

export class YouTubeAccountManager {
 static list(guildId){ return listStatement.all(guildId).map(r=>({...r,enabled:Boolean(r.enabled)})); }
 static get(guildId,name){ const r=getStatement.get(guildId,name); return r?{...r,enabled:Boolean(r.enabled)}:null; }
 static upsert(guildId,a){ upsertStatement.run(guildId,a.channelName,a.youtubeChannelId,a.notifyChannelId,a.pingRoleId||null,a.embedTitle||null,a.embedDescription||null,a.embedColor||"FF0000",a.imageUrl||null); return this.get(guildId,a.channelName); }
 static remove(guildId,name){ return Number(removeStatement.run(guildId,name).changes)===1; }
}
