import fs from "node:fs";
import path from "node:path";
import { AttachmentBuilder, EmbedBuilder } from "discord.js";
import db from "../database/Database.js";

const imageDir = path.resolve("./data/boost-images");
fs.mkdirSync(imageDir, { recursive: true });

function replaceVariables(template, member) {
    const guild = member.guild;
    return String(template || "")
        .replaceAll("{membre}", `<@${member.id}>`)
        .replaceAll("{serveur}", guild.name)
        .replaceAll("{boosts}", String(guild.premiumSubscriptionCount || 0))
        .replaceAll("{niveau}", String(guild.premiumTier || 0));
}

function safeExt(name = "image.png", contentType = "") {
    const ext = path.extname(name).toLowerCase();
    if ([".png", ".jpg", ".jpeg", ".gif", ".webp"].includes(ext)) return ext;
    if (contentType === "image/jpeg") return ".jpg";
    if (contentType === "image/gif") return ".gif";
    if (contentType === "image/webp") return ".webp";
    return ".png";
}

export class BoostManager {
    constructor(client) { this.client = client; }

    getSettings(guildId) {
        return db.prepare("SELECT * FROM boost_settings WHERE guild_id = ?").get(guildId) || null;
    }

    async configure(guild, { channelId, title, description, color, image }) {
        let imagePath = this.getSettings(guild.id)?.image_path || null;
        if (image) {
            const response = await fetch(image.url);
            if (!response.ok) throw new Error("Impossible de télécharger l’image envoyée.");
            const buffer = Buffer.from(await response.arrayBuffer());
            if (buffer.length > 10 * 1024 * 1024) throw new Error("L’image est trop volumineuse (10 Mo max).");
            const ext = safeExt(image.name, image.contentType);
            imagePath = path.join(imageDir, `${guild.id}${ext}`);
            for (const oldExt of [".png", ".jpg", ".jpeg", ".gif", ".webp"]) {
                const old = path.join(imageDir, `${guild.id}${oldExt}`);
                if (old !== imagePath && fs.existsSync(old)) fs.rmSync(old, { force: true });
            }
            fs.writeFileSync(imagePath, buffer);
        }
        db.prepare(`
            INSERT INTO boost_settings (guild_id, enabled, channel_id, embed_title, embed_description, embed_color, image_path, updated_at)
            VALUES (?, 1, ?, ?, ?, ?, ?, unixepoch())
            ON CONFLICT(guild_id) DO UPDATE SET enabled=1, channel_id=excluded.channel_id,
              embed_title=excluded.embed_title, embed_description=excluded.embed_description,
              embed_color=excluded.embed_color, image_path=excluded.image_path, updated_at=unixepoch()
        `).run(guild.id, channelId, title, description, color, imagePath);
        return this.getSettings(guild.id);
    }

    setEnabled(guildId, enabled) {
        db.prepare("UPDATE boost_settings SET enabled = ?, updated_at = unixepoch() WHERE guild_id = ?").run(enabled ? 1 : 0, guildId);
    }

    async handleMemberUpdate(oldMember, newMember) {
        // premiumSince passe de null à une date lorsqu'un membre commence à booster.
        if (oldMember.premiumSince || !newMember.premiumSince) return;
        const settings = this.getSettings(newMember.guild.id);
        if (!settings?.enabled) return;
        const channel = newMember.guild.channels.cache.get(settings.channel_id) || await newMember.guild.channels.fetch(settings.channel_id).catch(() => null);
        if (!channel?.isTextBased?.()) return;

        const embed = new EmbedBuilder()
            .setColor(parseInt(settings.embed_color || "F47FFF", 16))
            .setTitle(replaceVariables(settings.embed_title, newMember))
            .setDescription(replaceVariables(settings.embed_description, newMember))
            .setTimestamp();
        const payload = { embeds: [embed], allowedMentions: { users: [newMember.id] } };
        if (settings.image_path && fs.existsSync(settings.image_path)) {
            const filename = `boost${path.extname(settings.image_path) || ".png"}`;
            payload.files = [new AttachmentBuilder(settings.image_path, { name: filename })];
            embed.setImage(`attachment://${filename}`);
        }
        await channel.send(payload);
    }
}
