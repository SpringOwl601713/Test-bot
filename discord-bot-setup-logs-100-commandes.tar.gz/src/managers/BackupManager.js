import fs from "node:fs";
import path from "node:path";
import { ChannelType, PermissionFlagsBits } from "discord.js";

const ROOT = path.resolve("data", "backups");
const sleep = ms => new Promise(r => setTimeout(r, ms));

function safeName(s) { return String(s || "backup").replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 40); }
function serializeOverwrites(channel) {
  return channel.permissionOverwrites?.cache?.map(o => ({ id:o.id, type:o.type, allow:o.allow.bitfield.toString(), deny:o.deny.bitfield.toString() })) || [];
}

export class BackupManager {
  constructor(client) { this.client = client; fs.mkdirSync(ROOT, { recursive:true }); }
  guildDir(gid) { const d=path.join(ROOT,gid); fs.mkdirSync(d,{recursive:true}); return d; }
  file(gid,id) { return path.join(this.guildDir(gid), `${safeName(id)}.json`); }
  list(gid) {
    return fs.readdirSync(this.guildDir(gid)).filter(x=>x.endsWith(".json")).map(x=>{
      try { const b=JSON.parse(fs.readFileSync(path.join(this.guildDir(gid),x),"utf8")); return {id:b.id,name:b.name,createdAt:b.createdAt,counts:b.counts}; } catch { return null; }
    }).filter(Boolean).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
  }
  get(gid,id) { const f=this.file(gid,id); if(!fs.existsSync(f)) return null; return JSON.parse(fs.readFileSync(f,"utf8")); }
  delete(gid,id) { const f=this.file(gid,id); if(!fs.existsSync(f)) return false; fs.unlinkSync(f); return true; }

  async fetchMessages(channel, limit=1000) {
    if (!channel?.isTextBased?.() || !channel.messages?.fetch) return [];
    const out=[]; let before;
    while(out.length < limit) {
      const batch=await channel.messages.fetch({limit:Math.min(100,limit-out.length), ...(before?{before}:{})}).catch(()=>null);
      if(!batch?.size) break;
      for(const m of batch.values()) out.push({
        id:m.id, content:m.content || "", createdTimestamp:m.createdTimestamp,
        author:{id:m.author?.id, username:m.author?.username, displayName:m.member?.displayName || m.author?.globalName || m.author?.username, avatarURL:m.author?.displayAvatarURL?.({size:128}) || null, bot:!!m.author?.bot},
        pinned:!!m.pinned,
        attachments:[...m.attachments.values()].map(a=>({name:a.name,url:a.url,contentType:a.contentType,size:a.size})),
        embeds:m.embeds.map(e=>e.toJSON()).slice(0,10)
      });
      before=batch.last()?.id; if(batch.size<100) break;
    }
    return out.sort((a,b)=>a.createdTimestamp-b.createdTimestamp);
  }

  async create(guild, {name, includeMessages=true, messageLimit=1000}={}) {
    await guild.roles.fetch(); await guild.channels.fetch();
    const roles=[...guild.roles.cache.values()].filter(r=>r.id!==guild.id).sort((a,b)=>a.rawPosition-b.rawPosition).map(r=>({id:r.id,name:r.name,color:r.color,hoist:r.hoist,position:r.rawPosition,permissions:r.permissions.bitfield.toString(),mentionable:r.mentionable,managed:r.managed}));
    const channels=[...guild.channels.cache.values()].sort((a,b)=>a.rawPosition-b.rawPosition).map(c=>({id:c.id,name:c.name,type:c.type,parentId:c.parentId,position:c.rawPosition,topic:c.topic??null,nsfw:c.nsfw??false,rateLimitPerUser:c.rateLimitPerUser??0,bitrate:c.bitrate??null,userLimit:c.userLimit??null,permissionOverwrites:serializeOverwrites(c)}));
    const messages={};
    if(includeMessages) for(const c of guild.channels.cache.values()) if(c.isTextBased?.() && !c.isThread?.()) messages[c.id]=await this.fetchMessages(c,messageLimit);
    const members=[]; await guild.members.fetch().catch(()=>null);
    for(const m of guild.members.cache.values()) members.push({id:m.id,bot:m.user.bot,nickname:m.nickname,roles:[...m.roles.cache.keys()].filter(id=>id!==guild.id)});
    const bans=[]; if(guild.members.me?.permissions.has(PermissionFlagsBits.BanMembers)) { const bs=await guild.bans.fetch().catch(()=>null); if(bs) for(const b of bs.values()) bans.push({id:b.user.id,username:b.user.username,reason:b.reason||null}); }
    const integrations=[]; if(guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) { const ints=await guild.fetchIntegrations().catch(()=>null); if(ints) for(const i of ints.values()) integrations.push({id:i.id,name:i.name,type:i.type,enabled:i.enabled,account:i.account?.name||null}); }
    const id=`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
    const data={version:1,id,name:name||`Backup ${new Date().toLocaleString("fr-FR")}`,guildId:guild.id,guildName:guild.name,createdAt:new Date().toISOString(),settings:{name:guild.name,verificationLevel:guild.verificationLevel,explicitContentFilter:guild.explicitContentFilter,defaultMessageNotifications:guild.defaultMessageNotifications,afkTimeout:guild.afkTimeout,preferredLocale:guild.preferredLocale,description:guild.description||null},roles,channels,members,bans,integrations,messages,counts:{roles:roles.length,channels:channels.length,members:members.length,bans:bans.length,integrations:integrations.length,messages:Object.values(messages).reduce((n,a)=>n+a.length,0)}};
    fs.writeFileSync(this.file(guild.id,id),JSON.stringify(data,null,2)); return data;
  }

  async load(guild, backup, opts={}) {
    const loadRoles=opts.roles!==false, loadChannels=opts.channels!==false, loadSettings=opts.settings!==false, loadMembers=!!opts.members, loadBans=!!opts.bans, loadMessages=!!opts.messages;
    const roleMap=new Map([[guild.id,guild.id]]), channelMap=new Map();
    if(loadRoles){
      const existing=[...guild.roles.cache.values()].filter(r=>r.id!==guild.id && !r.managed && r.editable);
      for(const r of existing) await r.delete("Restauration backup Nexora").catch(()=>{});
      for(const r of backup.roles.filter(x=>!x.managed).sort((a,b)=>a.position-b.position)) {
        const nr=await guild.roles.create({name:r.name,color:r.color,hoist:r.hoist,permissions:BigInt(r.permissions),mentionable:r.mentionable,reason:"Restauration backup Nexora"}).catch(()=>null); if(nr) roleMap.set(r.id,nr.id);
      }
    } else for(const r of backup.roles){ const same=guild.roles.cache.find(x=>x.name===r.name); if(same) roleMap.set(r.id,same.id); }
    if(loadChannels){
      for(const c of [...guild.channels.cache.values()].filter(c=>c.deletable)) await c.delete("Restauration backup Nexora").catch(()=>{});
      const cats=backup.channels.filter(c=>c.type===ChannelType.GuildCategory).sort((a,b)=>a.position-b.position);
      const rest=backup.channels.filter(c=>c.type!==ChannelType.GuildCategory).sort((a,b)=>a.position-b.position);
      for(const c of [...cats,...rest]) {
        const overwrites=(c.permissionOverwrites||[]).map(o=>({id:roleMap.get(o.id)||o.id,type:o.type,allow:BigInt(o.allow),deny:BigInt(o.deny)})).filter(o=>o.id===guild.id||guild.roles.cache.has(o.id)||guild.members.cache.has(o.id));
        const nc=await guild.channels.create({name:c.name,type:c.type,parent:c.parentId?channelMap.get(c.parentId):null,position:c.position,topic:c.topic??undefined,nsfw:c.nsfw??undefined,rateLimitPerUser:c.rateLimitPerUser??undefined,bitrate:c.bitrate??undefined,userLimit:c.userLimit??undefined,permissionOverwrites:overwrites,reason:"Restauration backup Nexora"}).catch(()=>null); if(nc) channelMap.set(c.id,nc.id);
      }
    } else for(const c of backup.channels){ const same=guild.channels.cache.find(x=>x.name===c.name&&x.type===c.type); if(same) channelMap.set(c.id,same.id); }
    if(loadSettings) await guild.edit({name:backup.settings.name,verificationLevel:backup.settings.verificationLevel,explicitContentFilter:backup.settings.explicitContentFilter,defaultMessageNotifications:backup.settings.defaultMessageNotifications,afkTimeout:backup.settings.afkTimeout,preferredLocale:backup.settings.preferredLocale,description:backup.settings.description}).catch(()=>{});
    if(loadMembers){ await guild.members.fetch().catch(()=>null); for(const m of backup.members.filter(x=>!x.bot)){ const gm=guild.members.cache.get(m.id); if(!gm) continue; const ids=m.roles.map(id=>roleMap.get(id)).filter(id=>id&&guild.roles.cache.get(id)?.editable); if(ids.length) await gm.roles.add(ids,"Restauration backup Nexora").catch(()=>{}); if(m.nickname && gm.manageable) await gm.setNickname(m.nickname,"Restauration backup Nexora").catch(()=>{}); } }
    if(loadBans && guild.members.me?.permissions.has(PermissionFlagsBits.BanMembers)) for(const b of backup.bans) await guild.members.ban(b.id,{reason:b.reason||"Restauration backup Nexora"}).catch(()=>{});
    let restoredMessages=0;
    if(loadMessages){ for(const [oldId,msgs] of Object.entries(backup.messages||{})){ const ch=guild.channels.cache.get(channelMap.get(oldId)); if(!ch?.isTextBased?.()) continue; for(const m of msgs){ let content=m.content||""; const files=(m.attachments||[]).map(a=>a.url); const stamp=`<t:${Math.floor(m.createdTimestamp/1000)}:f>`; const header=`**${m.author?.displayName||m.author?.username||"Utilisateur"}** • ${stamp}`; let payload={content:`${header}\n${content}`.slice(0,2000),allowedMentions:{parse:[]}}; if(files.length) payload.content=(payload.content+"\n"+files.join("\n")).slice(0,2000); const sent=await ch.send(payload).catch(()=>null); if(sent){restoredMessages++; if(m.pinned) await sent.pin().catch(()=>{});} await sleep(250); } } }
    return {roleMap,channelMap,restoredMessages};
  }
}
