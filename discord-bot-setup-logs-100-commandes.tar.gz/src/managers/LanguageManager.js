import db from "../database/Database.js";

const LANGUAGES = [
  ["af","Afrikaans"],["sq","Shqip (Albanais)"],["am","አማርኛ (Amharique)"],["ar","العربية"],["hy","Հայերեն (Arménien)"],["as","অসমীয়া (Assamais)"],["ay","Aymara"],["az","Azərbaycanca"],["bm","Bambara"],["eu","Euskara"],["be","Беларуская"],["bn","বাংলা"],["bho","भोजपुरी"],["bs","Bosanski"],["bg","Български"],["ca","Català"],["ceb","Cebuano"],["zh-CN","中文 (简体)"],["zh-TW","中文 (繁體)"],["co","Corsu"],["hr","Hrvatski"],["cs","Čeština"],["da","Dansk"],["dv","ދިވެހި"],["doi","डोगरी"],["nl","Nederlands"],["en","English"],["eo","Esperanto"],["et","Eesti"],["ee","Eʋegbe"],["fil","Filipino"],["fi","Suomi"],["fr","Français"],["fy","Frysk"],["gl","Galego"],["ka","ქართული"],["de","Deutsch"],["el","Ελληνικά"],["gn","Guaraní"],["gu","ગુજરાતી"],["ht","Kreyòl ayisyen"],["ha","Hausa"],["haw","ʻŌlelo Hawaiʻi"],["he","עברית"],["hi","हिन्दी"],["hmn","Hmong"],["hu","Magyar"],["is","Íslenska"],["ig","Igbo"],["ilo","Ilocano"],["id","Bahasa Indonesia"],["ga","Gaeilge"],["it","Italiano"],["ja","日本語"],["jv","Basa Jawa"],["kn","ಕನ್ನಡ"],["kk","Қазақша"],["km","ខ្មែរ"],["rw","Kinyarwanda"],["gom","कोंकणी"],["ko","한국어"],["kri","Krio"],["ku","Kurdî"],["ckb","کوردی (سۆرانی)"],["ky","Кыргызча"],["lo","ລາວ"],["la","Latina"],["lv","Latviešu"],["ln","Lingála"],["lt","Lietuvių"],["lg","Luganda"],["lb","Lëtzebuergesch"],["mk","Македонски"],["mai","मैथिली"],["mg","Malagasy"],["ms","Bahasa Melayu"],["ml","മലയാളം"],["mt","Malti"],["mi","Māori"],["mr","मराठी"],["mni-Mtei","ꯃꯤꯇꯩꯂꯣꯟ"],["lus","Mizo"],["mn","Монгол"],["my","မြန်မာ"],["ne","नेपाली"],["no","Norsk"],["ny","Chichewa"],["or","ଓଡ଼ିଆ"],["om","Oromoo"],["ps","پښتو"],["fa","فارسی"],["pl","Polski"],["pt","Português"],["pa","ਪੰਜਾਬੀ"],["qu","Quechua"],["ro","Română"],["ru","Русский"],["sm","Gagana Sāmoa"],["sa","संस्कृतम्"],["gd","Gàidhlig"],["nso","Sepedi"],["sr","Српски"],["st","Sesotho"],["sn","Shona"],["sd","سنڌي"],["si","සිංහල"],["sk","Slovenčina"],["sl","Slovenščina"],["so","Soomaali"],["es","Español"],["su","Basa Sunda"],["sw","Kiswahili"],["sv","Svenska"],["tl","Tagalog"],["tg","Тоҷикӣ"],["ta","தமிழ்"],["tt","Татарча"],["te","తెలుగు"],["th","ไทย"],["ti","ትግርኛ"],["ts","Tsonga"],["tr","Türkçe"],["tk","Türkmençe"],["ak","Twi"],["uk","Українська"],["ur","اردو"],["ug","ئۇيغۇرچە"],["uz","Oʻzbekcha"],["vi","Tiếng Việt"],["cy","Cymraeg"],["xh","isiXhosa"],["yi","ייִדיש"],["yo","Yorùbá"],["zu","isiZulu"]
];

const languageMap = new Map(LANGUAGES);
const cache = new Map();
const translationCache = new Map();

function normalizeCode(code) {
  if (!code) return "fr";
  const raw = String(code).trim();
  if (languageMap.has(raw)) return raw;
  const found = LANGUAGES.find(([c,n]) => c.toLowerCase() === raw.toLowerCase() || n.toLowerCase() === raw.toLowerCase());
  return found?.[0] || "fr";
}

function protect(text) {
  const tokens = [];
  const pattern = /(<@!?\d+>|<@&\d+>|<#\d+>|https?:\/\/\S+|`{1,3}[\s\S]*?`{1,3}|\{[a-zA-Z0-9_]+\})/g;
  const value = text.replace(pattern, m => {
    const key = `__SERENITY_TOKEN_${tokens.length}__`;
    tokens.push(m);
    return key;
  });
  return { value, tokens };
}

function restore(text, tokens) {
  return tokens.reduce((out, token, i) => out.replaceAll(`__SERENITY_TOKEN_${i}__`, token), text);
}

async function translateText(text, target) {
  if (!text || target === "fr" || typeof text !== "string") return text;
  if (/^\s*$/.test(text)) return text;
  const key = `${target}\u0000${text}`;
  if (translationCache.has(key)) return translationCache.get(key);
  const { value, tokens } = protect(text);
  try {
    const url = new URL("https://translate.googleapis.com/translate_a/single");
    url.searchParams.set("client", "gtx");
    url.searchParams.set("sl", "auto");
    url.searchParams.set("tl", target);
    url.searchParams.set("dt", "t");
    url.searchParams.set("q", value);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4500);
    const response = await fetch(url, { signal: controller.signal, headers: { "User-Agent": "Mozilla/5.0 SerenityDiscordBot/1.0" } });
    clearTimeout(timeout);
    if (!response.ok) return text;
    const data = await response.json();
    const translated = Array.isArray(data?.[0]) ? data[0].map(part => part?.[0] || "").join("") : text;
    const result = restore(translated || text, tokens);
    translationCache.set(key, result);
    if (translationCache.size > 5000) translationCache.delete(translationCache.keys().next().value);
    return result;
  } catch {
    return text;
  }
}

const TRANSLATABLE_KEYS = new Set(["content","title","description","label","placeholder","name","value","text"]);
const NEVER_TRANSLATE_KEYS = new Set(["custom_id","customId","url","icon_url","iconURL","proxy_url","attachment","filename","emoji"]);

async function translateNode(node, target, parentKey = "") {
  if (node == null || target === "fr") return node;
  if (typeof node === "string") {
    if (!TRANSLATABLE_KEYS.has(parentKey)) return node;
    // N'altère pas les valeurs techniques de menus/boutons.
    if (parentKey === "value" && (/^[a-z0-9_:\-.]{1,100}$/i.test(node) || /^\d+$/.test(node))) return node;
    return translateText(node, target);
  }
  if (Array.isArray(node)) return Promise.all(node.map(v => translateNode(v, target, parentKey)));
  if (typeof node?.toJSON === "function") return translateNode(node.toJSON(), target, parentKey);
  if (typeof node !== "object") return node;
  const out = {};
  for (const [key, value] of Object.entries(node)) {
    if (NEVER_TRANSLATE_KEYS.has(key) || key === "files" || key === "file" || key === "allowedMentions") out[key] = value;
    else out[key] = await translateNode(value, target, key);
  }
  return out;
}

export class LanguageManager {
  constructor() {
    db.exec(`CREATE TABLE IF NOT EXISTS language_settings (guild_id TEXT PRIMARY KEY, language_code TEXT NOT NULL DEFAULT 'fr', updated_at INTEGER NOT NULL DEFAULT (unixepoch()));`);
  }

  list() { return LANGUAGES.map(([code,name]) => ({ code, name })); }
  name(code) { return languageMap.get(normalizeCode(code)) || "Français"; }
  localizedName(code, locale = "fr") {
    try {
      const normalized = normalizeCode(code).split("-")[0];
      return new Intl.DisplayNames([locale], { type: "language" }).of(normalized) || this.name(code);
    } catch { return this.name(code); }
  }
  label(code) {
    const native = this.name(code);
    const french = this.localizedName(code, "fr");
    return native.toLowerCase() === french.toLowerCase() ? native : `${native} (${french})`;
  }
  get(guildId) {
    if (!guildId) return "fr";
    if (cache.has(guildId)) return cache.get(guildId);
    const row = db.prepare("SELECT language_code FROM language_settings WHERE guild_id = ?").get(guildId);
    const code = normalizeCode(row?.language_code || "fr");
    cache.set(guildId, code);
    return code;
  }
  set(guildId, code) {
    const normalized = normalizeCode(code);
    if (!languageMap.has(normalized)) throw new Error("LANGUAGE_NOT_FOUND");
    db.prepare(`INSERT INTO language_settings (guild_id, language_code, updated_at) VALUES (?, ?, unixepoch()) ON CONFLICT(guild_id) DO UPDATE SET language_code = excluded.language_code, updated_at = unixepoch()`).run(guildId, normalized);
    cache.set(guildId, normalized);
    return normalized;
  }
  reset(guildId) {
    db.prepare("DELETE FROM language_settings WHERE guild_id = ?").run(guildId);
    cache.set(guildId, "fr");
  }
  search(query) {
    const q = String(query || "").trim().toLowerCase();
    return LANGUAGES.filter(([code,name]) => {
      if (!q) return true;
      const fr = this.localizedName(code, "fr").toLowerCase();
      const en = this.localizedName(code, "en").toLowerCase();
      return code.toLowerCase().includes(q) || name.toLowerCase().includes(q) || fr.includes(q) || en.includes(q);
    }).slice(0,25);
  }
  async translatePayload(payload, guildId) {
    const target = this.get(guildId);
    if (typeof payload === "string") return translateText(payload, target);
    return translateNode(payload, target);
  }
  installInteractionTranslation(interaction) {
    if (!interaction?.guildId || interaction.__serenityLanguageInstalled) return;
    interaction.__serenityLanguageInstalled = true;
    const guildId = interaction.guildId;
    for (const method of ["reply","editReply","followUp","update","showModal"]) {
      if (typeof interaction[method] !== "function") continue;
      const original = interaction[method].bind(interaction);
      interaction[method] = async payload => original(await this.translatePayload(payload, guildId));
    }
  }
}

export const languageManager = new LanguageManager();
