import db from "../database/Database.js";

const listStatement = db.prepare(`
    SELECT
        login,
        twitch_user_id AS twitchUserId,
        notify_channel_id AS notifyChannelId,
        ping_role_id AS pingRoleId,
        embed_title AS embedTitle,
        embed_description AS embedDescription,
        embed_color AS embedColor,
        image_url AS imageUrl,
        COALESCE(enabled, 1) AS enabled
    FROM twitch_accounts
    WHERE guild_id = ?
    ORDER BY login COLLATE NOCASE ASC
`);

const getStatement = db.prepare(`
    SELECT
        login,
        twitch_user_id AS twitchUserId,
        notify_channel_id AS notifyChannelId,
        ping_role_id AS pingRoleId,
        embed_title AS embedTitle,
        embed_description AS embedDescription,
        embed_color AS embedColor,
        image_url AS imageUrl,
        COALESCE(enabled, 1) AS enabled
    FROM twitch_accounts
    WHERE guild_id = ? AND login = ?
`);

const upsertStatement = db.prepare(`
    INSERT INTO twitch_accounts (
        guild_id, login, twitch_user_id, notify_channel_id, ping_role_id,
        embed_title, embed_description, embed_color, image_url, enabled, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, unixepoch())
    ON CONFLICT(guild_id, login) DO UPDATE SET
        twitch_user_id = excluded.twitch_user_id,
        notify_channel_id = excluded.notify_channel_id,
        ping_role_id = excluded.ping_role_id,
        embed_title = excluded.embed_title,
        embed_description = excluded.embed_description,
        embed_color = excluded.embed_color,
        image_url = excluded.image_url,
        enabled = 1,
        updated_at = unixepoch()
`);

const removeStatement = db.prepare(`
    DELETE FROM twitch_accounts
    WHERE guild_id = ? AND login = ?
`);

export class TwitchAccountManager {
    static list(guildId) {
        return listStatement.all(guildId).map(row => ({
            ...row,
            enabled: Boolean(row.enabled)
        }));
    }

    static get(guildId, login) {
        const row = getStatement.get(guildId, login);
        return row ? { ...row, enabled: Boolean(row.enabled) } : null;
    }

    static upsert(guildId, account) {
        upsertStatement.run(
            guildId,
            account.login,
            account.twitchUserId || null,
            account.notifyChannelId,
            account.pingRoleId || null,
            account.embedTitle || null,
            account.embedDescription || null,
            account.embedColor || "9146FF",
            account.imageUrl || null
        );
        return this.get(guildId, account.login);
    }

    static remove(guildId, login) {
        const result = removeStatement.run(guildId, login);
        return Number(result.changes) === 1;
    }
}
