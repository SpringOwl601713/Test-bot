import {
    EmbedBuilder
} from "discord.js";
import { TikTokLiveConnection, UserOfflineError } from "tiktok-live-connector";
import { ConfigManager } from "./ConfigManager.js";
import { TikTokAccountManager } from "./TikTokAccountManager.js";

export class LiveManager {
    constructor(client, intervalMs) {
        this.client = client;
        this.intervalMs = intervalMs;
        this.cache = new Map();
        this.running = false;
        this.timer = null;

        // Anti-spam : TikTok peut répondre temporairement "offline" ou échouer.
        // On confirme donc un changement d'état sur plusieurs scans avant d'agir.
        this.requiredConfirmations = 2;
        this.notificationCooldownMs = 10 * 60 * 1000;
    }

    cacheKey(guildId, username) {
        return `${guildId}:${username}`;
    }

    getCachedState(key) {
        if (!this.cache.has(key)) {
            this.cache.set(key, {
                stableLive: undefined,
                candidateLive: undefined,
                confirmations: 0,
                lastNotificationAt: 0
            });
        }

        return this.cache.get(key);
    }

    async getLiveState(username) {
        const connection = new TikTokLiveConnection(username, {
            processInitialData: false,
            enableExtendedGiftInfo: false,
            fetchRoomInfoOnConnect: false,
            requestPollingIntervalMs: 2_000
        });

        try {
            // V3 : on ne considère plus qu'un simple connect() signifie « en live ».
            // 1) fetchIsLive() fait la détection légère multi-source.
            // 2) Si elle dit LIVE, on confirme avec les infos de la room.
            const isLive = await connection.fetchIsLive();

            if (isLive === false) {
                return false;
            }

            let roomInfo;
            try {
                roomInfo = await connection.fetchRoomInfo();
            } catch (roomError) {
                console.warn(
                    `⚠️ @${username} semble LIVE, mais la room n'a pas pu être confirmée :`,
                    roomError?.message || roomError
                );
                return null;
            }

            // Dans tiktok-live-connector, status=4 correspond à une room terminée/offline.
            // Pour éviter les anciennes/stale rooms, la V3 exige le statut LIVE explicite (2).
            const roomStatus =
                roomInfo?.data?.status ??
                roomInfo?.status ??
                roomInfo?.data?.liveRoom?.status ??
                roomInfo?.liveRoom?.status;

            if (Number(roomStatus) === 2) {
                return true;
            }

            if (Number(roomStatus) === 4) {
                return false;
            }

            // Statut inconnu : surtout ne pas inventer un changement d'état.
            console.warn(
                `⚠️ Statut TikTok non reconnu pour @${username}:`,
                roomStatus
            );
            return null;
        } catch (error) {
            if (error instanceof UserOfflineError || error?.name === "UserOfflineError") {
                return false;
            }

            console.warn(
                `⚠️ Impossible de vérifier @${username}, état conservé :`,
                error?.message || error
            );
            return null;
        } finally {
            try {
                connection.disconnect();
            } catch {}
        }
    }

    async handleNewAccount(guildId, username) {
        // V4 : lorsqu'un compte vient d'être ajouté, on le vérifie immédiatement.
        // S'il est déjà LIVE, la notification part tout de suite puis le cache
        // est initialisé pour empêcher le scan automatique de la renvoyer.
        const live = await this.getLiveState(username);
        const key = this.cacheKey(guildId, username);
        const state = this.getCachedState(key);

        if (live === true) {
            await this.sendNotification(guildId, username);
            state.stableLive = true;
            state.candidateLive = undefined;
            state.confirmations = 0;
            state.lastNotificationAt = Date.now();
            return "live_notified";
        }

        if (live === false) {
            state.stableLive = false;
            state.candidateLive = undefined;
            state.confirmations = 0;
            return "offline";
        }

        // État indéterminé : on n'envoie rien et on laisse le scanner reprendre
        // normalement sans inventer un état LIVE/OFFLINE.
        return "unknown";
    }

    async sendNotification(guildId, username) {
        const settings = ConfigManager.get(guildId);
        const account = TikTokAccountManager.get(guildId, username);

        if (account && !account.enabled) {
            return;
        }

        // Un réglage défini sur le compte est prioritaire. Sinon, on conserve
        // exactement le comportement historique avec le salon/rôle global.
        const notifyChannelId = account?.notifyChannelId || settings.notifyChannelId;
        const pingRoleId = account?.pingRoleId || settings.pingRoleId;

        if (!notifyChannelId) {
            console.warn(`⚠️ Aucun salon configuré pour @${username} (${guildId}).`);
            return;
        }

        const channel = await this.client.channels.fetch(
            notifyChannelId
        ).catch(() => null);

        if (!channel?.isTextBased() || !("send" in channel)) {
            console.error(
                `❌ Salon TikTok invalide pour @${username} sur le serveur ${guildId}.`
            );
            return;
        }

        const liveUrl = `https://www.tiktok.com/@${username}/live`;
        const ping = pingRoleId
            ? `<@&${pingRoleId}> `
            : "";

        const embed = new EmbedBuilder()
            .setColor(0xff0050)
            .setTitle(`🔴 @${username} est en LIVE !`)
            .setURL(liveUrl)
            .setDescription(
                `La chaîne **@${username}** vient de lancer un live TikTok.\n\n` +
                `▶️ [Regarder le live maintenant](${liveUrl})`
            )
            .setFooter({
                text: "👑🔥 Nexora Légend Agency 🌐⚡"
            })
            .setTimestamp();

        // Photo personnalisée propre à ce compte TikTok.
        // Elle apparaît directement dans l'embed de notification LIVE.
        if (account?.imageUrl) {
            embed.setImage(account.imageUrl);
        }

        await channel.send({
            content:
                `${ping}🔴 **@${username} vient de lancer un LIVE TikTok !**`,
            embeds: [embed],
            allowedMentions: pingRoleId
                ? { roles: [pingRoleId] }
                : { parse: [] }
        });
    }

    async processState(guildId, username, live, notify) {
        // null = erreur TikTok/réseau : on ne change aucun état.
        if (live === null) return;

        const key = this.cacheKey(guildId, username);
        const state = this.getCachedState(key);

        // Au démarrage, on mémorise simplement l'état sans notifier.
        if (state.stableLive === undefined) {
            state.stableLive = live;
            state.candidateLive = undefined;
            state.confirmations = 0;
            return;
        }

        // Même état que l'état stable : annule tout faux changement transitoire.
        if (live === state.stableLive) {
            state.candidateLive = undefined;
            state.confirmations = 0;
            return;
        }

        // Nouveau candidat : il doit être vu plusieurs fois de suite.
        if (state.candidateLive !== live) {
            state.candidateLive = live;
            state.confirmations = 1;
            return;
        }

        state.confirmations += 1;

        if (state.confirmations < this.requiredConfirmations) {
            return;
        }

        const previousStable = state.stableLive;
        state.stableLive = live;
        state.candidateLive = undefined;
        state.confirmations = 0;

        if (!notify || !live || previousStable !== false) {
            return;
        }

        const now = Date.now();
        if (now - state.lastNotificationAt < this.notificationCooldownMs) {
            console.log(`🛡️ Notification anti-spam ignorée pour @${username}.`);
            return;
        }

        await this.sendNotification(guildId, username);
        state.lastNotificationAt = now;
    }

    async scan(notify = true) {
        if (this.running) return;
        this.running = true;

        try {
            for (const guild of this.client.guilds.cache.values()) {
                const usernames = TikTokAccountManager.list(guild.id);

                for (const username of usernames) {
                    const live = await this.getLiveState(username);
                    await this.processState(guild.id, username, live, notify);

                    await new Promise(resolve => setTimeout(resolve, 1_500));
                }
            }
        } finally {
            this.running = false;
        }
    }

    async start() {
        await this.scan(false);

        this.timer = setInterval(() => {
            this.scan(true).catch(console.error);
        }, this.intervalMs);
    }
}
