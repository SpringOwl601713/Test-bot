import { EmbedBuilder } from "discord.js";
import { KickAccountManager } from "./KickAccountManager.js";

function normalizeSlug(value) {
    return String(value || "")
        .trim()
        .replace(/^https?:\/\/(www\.)?kick\.com\//i, "")
        .replace(/^@/, "")
        .split(/[/?#]/)[0]
        .toLowerCase();
}

function fillTemplate(template, data) {
    return String(template || "")
        .replaceAll("{name}", data.name)
        .replaceAll("{slug}", data.slug)
        .replaceAll("{url}", data.url)
        .replaceAll("{title}", data.title || "")
        .replaceAll("{category}", data.category || "")
        .replaceAll("{viewers}", String(data.viewers ?? 0));
}

function parseColor(value) {
    const normalized = String(value || "53FC18").trim().replace(/^#/, "");
    if (!/^[0-9a-f]{6}$/i.test(normalized)) return 0x53fc18;
    return Number.parseInt(normalized, 16);
}

export class KickManager {
    constructor(client, { clientId = "", clientSecret = "", intervalMs = 60_000 } = {}) {
        this.client = client;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.intervalMs = Math.max(intervalMs, 30_000);
        this.token = null;
        this.tokenExpiresAt = 0;
        this.cache = new Map();
        this.timer = null;
        this.running = false;
    }

    get officialApiConfigured() {
        return Boolean(this.clientId && this.clientSecret);
    }

    cacheKey(guildId, slug) {
        return `${guildId}:${slug}`;
    }

    async getAppToken(force = false) {
        if (!this.officialApiConfigured) return null;
        if (!force && this.token && Date.now() < this.tokenExpiresAt - 60_000) return this.token;

        const body = new URLSearchParams({
            grant_type: "client_credentials",
            client_id: this.clientId,
            client_secret: this.clientSecret
        });

        const response = await fetch("https://id.kick.com/oauth/token", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body
        });

        if (!response.ok) throw new Error(`OAuth Kick ${response.status}: ${await response.text()}`);
        const data = await response.json();
        this.token = data.access_token;
        this.tokenExpiresAt = Date.now() + Number(data.expires_in || 3600) * 1000;
        return this.token;
    }

    async getChannelOfficial(slug, retry = true) {
        const token = await this.getAppToken();
        const response = await fetch(`https://api.kick.com/public/v1/channels?slug=${encodeURIComponent(slug)}`, {
            headers: {
                Accept: "application/json",
                Authorization: `Bearer ${token}`
            }
        });

        if (response.status === 401 && retry) {
            await this.getAppToken(true);
            return this.getChannelOfficial(slug, false);
        }
        if (!response.ok) throw new Error(`Kick Public API ${response.status}: ${await response.text()}`);

        const payload = await response.json();
        const item = payload.data?.[0];
        if (!item) return null;

        return {
            slug: item.slug || slug,
            user: { username: item.slug || slug, profile_pic: null },
            livestream: item.stream ? {
                is_live: Boolean(item.stream.is_live),
                session_title: item.stream_title || "",
                viewer_count: item.stream.viewer_count || 0,
                start_time: item.stream.start_time || null,
                thumbnail: { url: item.stream.thumbnail || null },
                category: item.category || null
            } : null
        };
    }

    async getChannelLegacy(slug) {
        const response = await fetch(`https://kick.com/api/v2/channels/${encodeURIComponent(slug)}`, {
            headers: {
                Accept: "application/json",
                "User-Agent": "Mozilla/5.0 (compatible; DiscordBot/1.0)"
            }
        });

        if (response.status === 404) return null;
        if (!response.ok) throw new Error(`Kick API ${response.status}: ${await response.text()}`);
        return response.json();
    }

    async getChannel(slug) {
        const clean = normalizeSlug(slug);
        if (!clean) return null;

        if (this.officialApiConfigured) {
            return this.getChannelOfficial(clean);
        }

        return this.getChannelLegacy(clean);
    }

    async configureAccount(guildId, options) {
        const slug = normalizeSlug(options.slug);
        if (!/^[a-z0-9_-]{2,50}$/i.test(slug)) {
            throw new Error("Nom Kick invalide.");
        }

        const channelData = await this.getChannel(slug);
        if (!channelData) {
            throw new Error(`Le compte Kick @${slug} est introuvable.`);
        }

        const saved = KickAccountManager.upsert(guildId, {
            ...options,
            slug
        });

        const live = Boolean(channelData.livestream?.is_live ?? channelData.livestream);
        this.cache.set(this.cacheKey(guildId, slug), live);

        if (live) {
            await this.sendNotification(guildId, saved, channelData);
        }

        return { account: saved, channel: channelData, isLive: live };
    }

    async sendNotification(guildId, account, channelData) {
        const channel = await this.client.channels.fetch(account.notifyChannelId).catch(() => null);
        if (!channel?.isTextBased() || !("send" in channel)) return;

        const livestream = channelData.livestream || {};
        const displayName = channelData.user?.username || channelData.slug || account.slug;
        const liveUrl = `https://kick.com/${account.slug}`;
        const category = livestream.categories?.[0]?.name || livestream.category?.name || livestream.category?.slug || "";
        const thumbnail = livestream.thumbnail?.url || livestream.thumbnail?.src || channelData.offline_banner_image?.src || null;
        const avatar = channelData.user?.profile_pic || channelData.user?.profile_pic_url || null;

        const data = {
            name: displayName,
            slug: account.slug,
            url: liveUrl,
            title: livestream.session_title || livestream.title || "",
            category,
            viewers: livestream.viewer_count || 0
        };

        const titleTemplate = account.embedTitle || "🟢 {name} est en LIVE sur Kick !";
        const descTemplate = account.embedDescription ||
            "**{name}** vient de lancer un stream.\n\n🎮 **{category}**\n📝 {title}\n👥 {viewers} spectateur(s)\n\n▶️ [Regarder le live]({url})";

        const embed = new EmbedBuilder()
            .setColor(parseColor(account.embedColor))
            .setTitle(fillTemplate(titleTemplate, data).slice(0, 256))
            .setURL(liveUrl)
            .setDescription(fillTemplate(descTemplate, data).slice(0, 4096))
            .setFooter({ text: "👑🔥 Nexora Légend Agency • Kick" })
            .setTimestamp(new Date(livestream.created_at || livestream.start_time || Date.now()));

        if (avatar) embed.setThumbnail(avatar);
        if (account.imageUrl) embed.setImage(account.imageUrl);
        else if (thumbnail) embed.setImage(`${thumbnail}${thumbnail.includes("?") ? "&" : "?"}t=${Date.now()}`);

        const ping = account.pingRoleId ? `<@&${account.pingRoleId}> ` : "";
        await channel.send({
            content: `${ping}🟢 **${displayName} vient de lancer un LIVE Kick !**`,
            embeds: [embed],
            allowedMentions: account.pingRoleId ? { roles: [account.pingRoleId] } : { parse: [] }
        });
    }

    async scan(notify = true) {
        if (this.running) return;
        this.running = true;

        try {
            for (const guild of this.client.guilds.cache.values()) {
                for (const account of KickAccountManager.list(guild.id)) {
                    if (!account.enabled) continue;

                    try {
                        const channelData = await this.getChannel(account.slug);
                        if (!channelData) continue;

                        const live = Boolean(channelData.livestream?.is_live ?? channelData.livestream);
                        const key = this.cacheKey(guild.id, account.slug);

                        if (!this.cache.has(key)) {
                            this.cache.set(key, live);
                            continue;
                        }

                        const previous = this.cache.get(key);
                        this.cache.set(key, live);

                        if (notify && live && previous === false) {
                            await this.sendNotification(guild.id, account, channelData);
                        }
                    } catch (error) {
                        console.warn(`⚠️ Kick @${account.slug}:`, error?.message || error);
                    }
                }
            }
        } finally {
            this.running = false;
        }
    }

    async start() {
        await this.scan(false);
        this.timer = setInterval(() => this.scan(true).catch(console.error), this.intervalMs);
        console.log(`✅ Surveillance Kick active toutes les ${this.intervalMs / 1000}s.`);
    }
}
