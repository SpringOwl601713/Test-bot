import fs from "node:fs";
import path from "node:path";
import {
    AttachmentBuilder,
    EmbedBuilder,
    PermissionFlagsBits
} from "discord.js";
import db from "../database/Database.js";

const imageDir = path.resolve("./data/invitelogger-images");
fs.mkdirSync(imageDir, { recursive: true });

function replaceVariables(template, values) {
    return String(template || "")
        .replaceAll("{membre}", values.membre)
        .replaceAll("{serveur}", values.serveur)
        .replaceAll("{inviteur}", values.inviteur)
        .replaceAll("{invitations}", String(values.invitations))
        .replaceAll("{membres}", String(values.membres));
}

function safeExt(name = "image.png", contentType = "") {
    const byName = path.extname(name).toLowerCase();
    if ([".png", ".jpg", ".jpeg", ".gif", ".webp"].includes(byName)) return byName;
    if (contentType === "image/jpeg") return ".jpg";
    if (contentType === "image/gif") return ".gif";
    if (contentType === "image/webp") return ".webp";
    return ".png";
}

export class InviteLoggerManager {
    constructor(client) {
        this.client = client;
        this.inviteCache = new Map();
    }

    async start() {
        for (const guild of this.client.guilds.cache.values()) {
            await this.refreshInvites(guild).catch(() => {});
        }
    }

    getSettings(guildId) {
        return db.prepare("SELECT * FROM invite_logger_settings WHERE guild_id = ?").get(guildId) || null;
    }

    async configure(guild, { channelId, welcomeMessage, leaveMessage, image }) {
        let imagePath = this.getSettings(guild.id)?.image_path || null;

        if (image) {
            const response = await fetch(image.url);
            if (!response.ok) throw new Error("Impossible de télécharger l’image envoyée.");
            const buffer = Buffer.from(await response.arrayBuffer());
            if (buffer.length > 10 * 1024 * 1024) throw new Error("L’image est trop volumineuse (10 Mo max).");
            const ext = safeExt(image.name, image.contentType);
            imagePath = path.join(imageDir, `${guild.id}${ext}`);

            for (const otherExt of [".png", ".jpg", ".jpeg", ".gif", ".webp"]) {
                const old = path.join(imageDir, `${guild.id}${otherExt}`);
                if (old !== imagePath && fs.existsSync(old)) fs.rmSync(old, { force: true });
            }
            fs.writeFileSync(imagePath, buffer);
        }

        db.prepare(`
            INSERT INTO invite_logger_settings
                (guild_id, enabled, channel_id, welcome_message, leave_message, image_path, updated_at)
            VALUES (?, 1, ?, ?, ?, ?, unixepoch())
            ON CONFLICT(guild_id) DO UPDATE SET
                enabled = 1,
                channel_id = excluded.channel_id,
                welcome_message = excluded.welcome_message,
                leave_message = excluded.leave_message,
                image_path = excluded.image_path,
                updated_at = unixepoch()
        `).run(guild.id, channelId, welcomeMessage, leaveMessage, imagePath);

        await this.refreshInvites(guild).catch(() => {});
        return this.getSettings(guild.id);
    }

    disable(guildId) {
        db.prepare("UPDATE invite_logger_settings SET enabled = 0, updated_at = unixepoch() WHERE guild_id = ?").run(guildId);
    }

    async refreshInvites(guild) {
        const me = guild.members.me;
        if (!me?.permissions.has(PermissionFlagsBits.ManageGuild)) return;
        const invites = await guild.invites.fetch();
        this.inviteCache.set(
            guild.id,
            new Map(invites.map(invite => [invite.code, invite.uses || 0]))
        );
    }

    async handleInviteChange(guild) {
        await this.refreshInvites(guild).catch(() => {});
    }

    async detectUsedInvite(guild) {
        const me = guild.members.me;
        if (!me?.permissions.has(PermissionFlagsBits.ManageGuild)) return null;

        const previous = this.inviteCache.get(guild.id) || new Map();
        const current = await guild.invites.fetch();
        let used = null;

        for (const invite of current.values()) {
            const before = previous.get(invite.code) || 0;
            const now = invite.uses || 0;
            if (now > before) {
                used = invite;
                break;
            }
        }

        this.inviteCache.set(guild.id, new Map(current.map(invite => [invite.code, invite.uses || 0])));
        return used;
    }

    async sendConfiguredMessage(guild, settings, description, title, color = 0x57f287) {
        const channel = guild.channels.cache.get(settings.channel_id) || await guild.channels.fetch(settings.channel_id).catch(() => null);
        if (!channel?.isTextBased?.()) return;

        const embed = new EmbedBuilder()
            .setColor(color)
            .setTitle(title)
            .setDescription(description)
            .setTimestamp();

        const payload = { embeds: [embed], allowedMentions: { parse: ["users", "roles"] } };

        if (settings.image_path && fs.existsSync(settings.image_path)) {
            const filename = `invitelogger${path.extname(settings.image_path) || ".png"}`;
            payload.files = [new AttachmentBuilder(settings.image_path, { name: filename })];
            embed.setImage(`attachment://${filename}`);
        }

        await channel.send(payload);
    }

    async handleMemberJoin(member) {
        const settings = this.getSettings(member.guild.id);
        if (!settings?.enabled) return;

        let usedInvite = null;
        try {
            usedInvite = await this.detectUsedInvite(member.guild);
        } catch (error) {
            console.warn("⚠️ InviteLogger: impossible d’identifier l’invitation utilisée :", error?.message || error);
        }

        const inviter = usedInvite?.inviter || null;
        const inviterMention = inviter ? `<@${inviter.id}>` : "Invitation inconnue";
        const inviterUses = usedInvite?.uses || 0;

        db.prepare(`
            INSERT INTO member_invite_history (guild_id, member_id, inviter_id, invite_code, invite_uses, joined_at)
            VALUES (?, ?, ?, ?, ?, unixepoch())
            ON CONFLICT(guild_id, member_id) DO UPDATE SET
                inviter_id = excluded.inviter_id,
                invite_code = excluded.invite_code,
                invite_uses = excluded.invite_uses,
                joined_at = unixepoch()
        `).run(member.guild.id, member.id, inviter?.id || null, usedInvite?.code || null, inviterUses);

        const description = replaceVariables(settings.welcome_message, {
            membre: `<@${member.id}>`,
            serveur: member.guild.name,
            inviteur: inviterMention,
            invitations: inviterUses,
            membres: member.guild.memberCount
        });

        await this.sendConfiguredMessage(member.guild, settings, description, "👋 Nouveau membre", 0x57f287);
    }

    async handleMemberLeave(member) {
        const settings = this.getSettings(member.guild.id);
        if (!settings?.enabled) return;

        const history = db.prepare(
            "SELECT * FROM member_invite_history WHERE guild_id = ? AND member_id = ?"
        ).get(member.guild.id, member.id);

        const inviterMention = history?.inviter_id ? `<@${history.inviter_id}>` : "Invitation inconnue";
        const inviteUses = history?.invite_uses || 0;

        const description = replaceVariables(settings.leave_message, {
            membre: `<@${member.id}>`,
            serveur: member.guild.name,
            inviteur: inviterMention,
            invitations: inviteUses,
            membres: member.guild.memberCount
        });

        await this.sendConfiguredMessage(member.guild, settings, description, "👋 Départ d’un membre", 0xed4245);
        db.prepare("DELETE FROM member_invite_history WHERE guild_id = ? AND member_id = ?").run(member.guild.id, member.id);
    }
}
