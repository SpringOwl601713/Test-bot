import {
    ActionRowBuilder,
    AttachmentBuilder,
    ActivityType,
    ButtonBuilder,
    ButtonStyle,
    ChannelSelectMenuBuilder,
    ChannelType,
    EmbedBuilder,
    ModalBuilder,
    PermissionFlagsBits,
    RoleSelectMenuBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    TextInputBuilder,
    TextInputStyle
} from "discord.js";
import { fileURLToPath } from "node:url";
import { getVoiceConnection, joinVoiceChannel } from "@discordjs/voice";
import { RadioManager } from "../managers/RadioManager.js";
import {
    createSetupButtons,
    createSetupEmbed
} from "../commands/setupTikTokPanel.js";
import { ConfigManager } from "../managers/ConfigManager.js";
import { TikTokAccountManager } from "../managers/TikTokAccountManager.js";
import { RoleReactManager } from "../managers/RoleReactManager.js";
import { YouTubeAccountManager } from "../managers/YouTubeAccountManager.js";
import { TwitchAccountManager } from "../managers/TwitchAccountManager.js";
import { KickAccountManager } from "../managers/KickAccountManager.js";
import { languageManager } from "../managers/LanguageManager.js";
import {
    cleanUsername,
    isValidUsername,
    parseUsernames
} from "../utils/usernames.js";

const pendingDmall = new Map();
const pendingSay = new Map();
const radioManager = new RadioManager();

function makeDmallToken() {
    return Math.random().toString(36).slice(2, 10);
}

function makeSayToken() {
    return Math.random().toString(36).slice(2, 10);
}

function isImageAttachment(attachment) {
    return Boolean(
        attachment &&
        (attachment.contentType?.startsWith("image/") ||
            /\.(png|jpe?g|gif|webp)$/i.test(attachment.name || ""))
    );
}

function canManage(interaction) {
    return interaction.memberPermissions?.has(
        PermissionFlagsBits.ManageGuild
    );
}

async function deny(interaction) {
    return interaction.reply({
        content: "❌ Tu dois avoir la permission **Gérer le serveur**.",
        ephemeral: true
    });
}

function parseMenuEmoji(raw) {
    if (!raw) return null;
    const value = raw.trim();
    const custom = value.match(/^<a?:([^:]+):(\d+)>$/);
    if (custom) return { name: custom[1], id: custom[2], animated: value.startsWith("<a:") };
    return { name: value };
}

function buildRoleReactComponents(targetMessageId, options) {
    const select = new StringSelectMenuBuilder()
        .setCustomId(`rolereact:menu:${targetMessageId}`)
        .setPlaceholder("Sélectionnez une catégorie...")
        .setMinValues(1)
        .setMaxValues(1);

    for (const item of options.slice(0, 25)) {
        const option = new StringSelectMenuOptionBuilder()
            .setLabel(item.label)
            .setValue(item.roleId);

        if (item.description) option.setDescription(item.description);
        if (item.emoji) {
            const parsed = parseMenuEmoji(item.emoji);
            if (parsed) option.setEmoji(parsed);
        }
        select.addOptions(option);
    }

    return [new ActionRowBuilder().addComponents(select)];
}


const HELP_CATEGORIES = {
    accueil: { emoji: "🏠", label: "Accueil", description: "Retour à la page principale" },
    generales: { emoji: "⚙️", label: "Commandes Générales", description: "Commandes de base du bot" },
    utilitaire: { emoji: "🔧", label: "Utilitaire", description: "Informations et statistiques" },
    gestion: { emoji: "🤖", label: "Gestion du Bot", description: "Configuration et administration" },
    moderation: { emoji: "👮", label: "Modération", description: "Commandes de gestion du serveur" },
    protection: { emoji: "🛡️", label: "Protection", description: "Antiraid, antispam et sécurité" },
    logs: { emoji: "📋", label: "Logs & récupération", description: "Invitations, récupération et suivi" },
    giveaways: { emoji: "🎉", label: "Giveaways", description: "Concours et tirages" },
    tickets: { emoji: "🎫", label: "Tickets & rôles", description: "Tickets, règles et rôles" },
    lives: { emoji: "📱", label: "Lives & réseaux", description: "TikTok, Twitch et YouTube" },
    sauvegarde: { emoji: "☁️", label: "Sauvegarde", description: "Sauvegarde et restauration du serveur" },
    vocal: { emoji: "🔊", label: "Vocal", description: "Connexion et déconnexion du bot en vocal" },
    radio: { emoji: "📻", label: "Radio", description: "Radios en direct dans ton salon vocal" }
};

const HELP_GROUPS = {
    giveaways: new Set(["giveaway","giveaway-end","reroll","gstart","gend","greroll"]),
    tickets: new Set(["setupticket","règle","rolereact","effectif","addrole","delrole","roleinfo","rolemembers"]),
    lives: new Set(["setuptiktok","testtiktok","testnotification","lives","twitch","kicklive","youtube"]),
    logs: new Set(["setup-logs","invitelogger","invites","stats-invite","recuperation","setup-boost","config-counter","snipe","ghostping"]),
    sauvegarde: new Set(["backup"]),
    vocal: new Set(["join", "leave"]),
    radio: new Set(["nrj", "skyrock", "funradio", "virginradio", "autoroute1077"]),
    protection: new Set(["security","anti-piratage","antiban","antibot","antichannel","antieveryone","antilink","antirole","antispam","antiupdate","antivanity","antiwebhook","whitelist","unwhitelist"]),
    moderation: new Set(["change","ban","kick","mute","unmute","warn","clear","clearall","lock","unlock","renew","derank","sanction","delsanction","delallsanction","vmute","voicemove"]),
    gestion: new Set(["language","autorank","activity","say","dmall","setcommand","delcommand","setperm","delperm","setpublic","setowner","unowner","owner","perms","setcolor","setconfess","setsuggest","soutien","tempvoc"]),
    utilitaire: new Set(["ping","serverinfo","serverbanner","userinfo","alladmins","allbans","allbots","vc","variable","emoji"])
};

function helpCategoryFor(name) {
    for (const [key, names] of Object.entries(HELP_GROUPS)) if (names.has(name)) return key;
    return "generales";
}

function helpMenu(category = "accueil") {
    const select = new StringSelectMenuBuilder()
        .setCustomId("help:category")
        .setPlaceholder("Choisissez une catégorie")
        .addOptions(Object.entries(HELP_CATEGORIES).map(([value, c]) =>
            new StringSelectMenuOptionBuilder().setLabel(c.label).setDescription(c.description).setEmoji(c.emoji).setValue(value).setDefault(value === category)
        ));
    return new ActionRowBuilder().addComponents(select);
}

function helpEmbed(client, category = "accueil") {
    const commands = [...client.application.commands.cache.values()].sort((a,b) => a.name.localeCompare(b.name, "fr"));
    const base = new EmbedBuilder().setColor(0xD4AF37).setImage("attachment://help-banner.jpeg");
    if (category === "accueil") {
        const categoryLines = Object.entries(HELP_CATEGORIES).filter(([k]) => k !== "accueil").map(([, c]) => `${c.emoji} **${c.label}** — ${c.description}`);
        return base
            .setTitle("📚 Menu d’Aide")
            .setDescription(`Bienvenue dans le menu d’aide de **${client.user.username}** !\n\nLe bot possède actuellement **${commands.length} commandes slash**. Utilise le menu déroulant pour les parcourir par catégorie.\n\n**📋 Catégories disponibles**\n${categoryLines.join("\n")}`)
            .setFooter({ text: `${client.user.username} • Menu /help`, iconURL: client.user.displayAvatarURL() });
    }
    const meta = HELP_CATEGORIES[category] || HELP_CATEGORIES.generales;
    const selected = commands.filter(c => helpCategoryFor(c.name) === category);
    let lines;
    let displayedCount = selected.length;

    // /backup est une seule commande Slash Discord contenant 5 sous-commandes.
    // Dans l'aide, on affiche chaque sous-commande séparément pour que la
    // catégorie Sauvegarde soit plus claire, sans modifier la commande réelle.
    if (category === "sauvegarde") {
        const backup = selected.find(c => c.name === "backup");
        const subcommands = backup?.options?.filter(o => o.type === 1) || [];
        lines = subcommands.map(s => `**/backup ${s.name}** — ${s.description || "Commande de sauvegarde"}`);
        displayedCount = subcommands.length;
    } else {
        lines = selected.map(c => `**/${c.name}** — ${c.description || "Commande du bot"}`);
    }

    let description = lines.join("\n");
    if (!description) description = "Aucune commande dans cette catégorie.";
    if (description.length > 3900) description = description.slice(0, 3890) + "\n…";
    return base
        .setTitle(`${meta.emoji} ${meta.label}`)
        .setDescription(`${meta.description}\n\n${description}\n\n**${displayedCount} commande(s)** dans cette catégorie.`)
        .setFooter({ text: `${client.user.username} • /help`, iconURL: client.user.displayAvatarURL() });
}

async function sendHelp(interaction, category = "accueil", update = false) {
    // Discord exige un accusé de réception d'une interaction en quelques secondes.
    // On diffère donc immédiatement la réponse avant de construire le menu /help.
    if (update) {
        if (!interaction.deferred && !interaction.replied) await interaction.deferUpdate();
    } else {
        if (!interaction.deferred && !interaction.replied) await interaction.deferReply();
    }

    // discord.js v14 attend ici un chemin de fichier, un Buffer ou un stream.
    // Un objet URL(file://...) provoque ReqResourceType sur certaines versions.
    const bannerPath = fileURLToPath(new URL("../../assets/help-banner.jpeg", import.meta.url));
    const banner = new AttachmentBuilder(bannerPath, { name: "help-banner.jpeg" });
    const payload = {
        embeds: [helpEmbed(interaction.client, category)],
        components: [helpMenu(category)],
        files: [banner],
        allowedMentions: { parse: [] }
    };

    return interaction.editReply(payload);
}

export async function handleInteraction(interaction, liveManager, securityManager, twitchManager, kickManager, youtubeManager, antiPiracyManager, inviteLoggerManager, inviteStatsManager, boostManager, effectifManager, ticketManager, counterManager, legacyCommandsManager, giveawayManager, recoveryManager, backupManager, logManager) {
    if (!interaction.guild) return;

    // Traduit automatiquement les réponses des commandes selon la langue du serveur.
    // /language reste volontairement non traduit pendant le changement pour garantir une confirmation lisible.
    if (!(interaction.isChatInputCommand?.() && interaction.commandName === "language") && !interaction.isAutocomplete?.()) {
        languageManager.installInteractionTranslation(interaction);
    }

    if (interaction.isAutocomplete?.() && interaction.commandName === "language") {
        const focused = interaction.options.getFocused();
        const choices = languageManager.search(focused).map(([code]) => ({ name: `${languageManager.label(code)} — ${code}`.slice(0,100), value: code }));
        return interaction.respond(choices);
    }

    if (interaction.isChatInputCommand?.() && interaction.commandName === "language") {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
            return interaction.reply({ content: "❌ Tu dois avoir la permission **Gérer le serveur**.", ephemeral: true });
        }
        const action = interaction.options.getString("action", true);
        if (action === "current") {
            const code = languageManager.get(interaction.guildId);
            return interaction.reply({ content: `🌐 Langue actuelle : **${languageManager.name(code)}** (\`${code}\`).`, ephemeral: true });
        }
        if (action === "reset") {
            languageManager.reset(interaction.guildId);
            return interaction.reply({ content: "✅ Langue réinitialisée : **Français**.", ephemeral: true });
        }
        const requested = interaction.options.getString("langue");
        if (!requested) return interaction.reply({ content: "❌ Choisis une langue dans le champ **langue**.", ephemeral: true });
        const found = languageManager.search(requested).find(([code]) => code.toLowerCase() === requested.toLowerCase());
        if (!found) return interaction.reply({ content: "❌ Langue inconnue. Commence à taper son nom dans le champ **langue**.", ephemeral: true });
        const code = languageManager.set(interaction.guildId, found[0]);
        const confirmation = { content: `✅ Langue du bot définie sur **${languageManager.name(code)}** (\`${code}\`). Les réponses des commandes seront désormais traduites automatiquement.`, ephemeral: true };
        // La confirmation elle-même est envoyée dans la nouvelle langue.
        return interaction.reply(await languageManager.translatePayload(confirmation, interaction.guildId));
    }

    // Le système Autorank possède son propre gestionnaire d'interactions.
    // On évite ici qu'un second handler réponde aux mêmes boutons/modals.
    const isAutorankInteraction =
        (interaction.isChatInputCommand() && interaction.commandName === "autorank") ||
        ((interaction.isButton() || interaction.isModalSubmit()) && interaction.customId?.startsWith("autorank:"));
    if (isAutorankInteraction) return;

    if (interaction.isChatInputCommand() && interaction.commandName === "setup-logs") {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return deny(interaction);
        const action = interaction.options.getString("action", true);
        const viewerRole = interaction.options.getRole("role");
        const settings = logManager?.getSettings(interaction.guildId);

        if (action === "status") {
            if (!settings) return interaction.reply({ content: "ℹ️ Les logs automatiques ne sont pas encore configurés. Utilise `/setup-logs action:Installer / réparer les logs`.", ephemeral: true });
            const state = settings.enabled ? "✅ Activés" : "⛔ Désactivés";
            const channels = [
                settings.moderation_channel_id, settings.messages_channel_id, settings.members_channel_id,
                settings.voice_channel_id, settings.server_channel_id, settings.invites_channel_id, settings.commands_channel_id
            ].filter(Boolean).map(id => `<#${id}>`).join(" • ");
            return interaction.reply({ content: `📜 **Logs serveur — ${state}**\nCatégorie : ${settings.category_id ? `<#${settings.category_id}>` : "Inconnue"}\nSalons : ${channels || "Aucun"}\nRôle staff : ${settings.viewer_role_id ? `<@&${settings.viewer_role_id}>` : "Administrateurs uniquement"}`, ephemeral: true, allowedMentions: { parse: [] } });
        }

        if (action === "disable" || action === "enable") {
            if (!settings) return interaction.reply({ content: "❌ Configure d’abord les logs avec l’action **Installer / réparer les logs**.", ephemeral: true });
            logManager.setEnabled(interaction.guildId, action === "enable");
            return interaction.reply({ content: action === "enable" ? "✅ Les logs automatiques sont réactivés." : "⛔ Les logs automatiques sont désactivés. Les salons restent en place.", ephemeral: true });
        }

        if (action === "test") {
            if (!settings?.enabled) return interaction.reply({ content: "❌ Les logs doivent être configurés et activés avant le test.", ephemeral: true });
            await interaction.deferReply({ ephemeral: true });
            await logManager.sendTest(interaction.guild);
            return interaction.editReply("✅ Test envoyé dans le salon **⚙️・serveur**.");
        }

        await interaction.deferReply({ ephemeral: true });
        try {
            const result = await logManager.setup(interaction.guild, viewerRole);
            return interaction.editReply({
                content: `✅ **Logs automatiques configurés.**\n\nCatégorie : <#${result.category_id}>\n🛡️ Modération : <#${result.moderation_channel_id}>\n💬 Messages : <#${result.messages_channel_id}>\n👥 Membres : <#${result.members_channel_id}>\n🔊 Vocal : <#${result.voice_channel_id}>\n⚙️ Serveur : <#${result.server_channel_id}>\n🔗 Invitations : <#${result.invites_channel_id}>\n⌨️ Commandes : <#${result.commands_channel_id}>\n\nLe bot commence à enregistrer automatiquement les événements Discord reçus.`,
                allowedMentions: { parse: [] }
            });
        } catch (error) {
            console.error("Erreur /setup-logs :", error);
            const msg = error?.message === "MISSING_MANAGE_CHANNELS"
                ? "❌ Le bot a besoin de la permission **Gérer les salons** pour créer les salons de logs."
                : "❌ Impossible de configurer les logs. Vérifie les permissions du bot puis réessaie.";
            return interaction.editReply(msg);
        }
    }

    if (interaction.isChatInputCommand() && interaction.commandName === "help") return sendHelp(interaction, "accueil");
    if (interaction.isStringSelectMenu() && interaction.customId === "help:category") return sendHelp(interaction, interaction.values[0], true);

    // /change — conversion fidèle de l’ancienne commande !change.
    if (interaction.isChatInputCommand() && interaction.commandName === "change") {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageNicknames)) {
            return interaction.reply({ content: "❌ Tu n'as pas la permission de gérer les pseudos.", ephemeral: true });
        }

        const user = interaction.options.getUser("membre", true);
        const nickname = interaction.options.getString("pseudo", true).trim();
        if (!nickname || nickname.length > 32) {
            return interaction.reply({ content: "❌ Le pseudo doit contenir entre 1 et 32 caractères.", ephemeral: true });
        }

        try {
            const member = await interaction.guild.members.fetch(user.id);
            const executor = await interaction.guild.members.fetch(interaction.user.id);
            const botMember = interaction.guild.members.me ?? await interaction.guild.members.fetchMe();

            if (member.id === interaction.guild.ownerId) {
                return interaction.reply({ content: "❌ Impossible de modifier le propriétaire du serveur.", ephemeral: true });
            }
            if (member.roles.highest.position >= botMember.roles.highest.position) {
                return interaction.reply({ content: "❌ Le rôle du bot n'est pas assez haut.", ephemeral: true });
            }
            if (member.roles.highest.position >= executor.roles.highest.position && interaction.user.id !== interaction.guild.ownerId && member.id !== interaction.user.id) {
                return interaction.reply({ content: "❌ Tu ne peux pas modifier ce membre.", ephemeral: true });
            }

            await member.setNickname(nickname, `Pseudo modifié par ${interaction.user.tag}`);
            return interaction.reply({ content: `✅ Le pseudo de ${member} est maintenant **${nickname}**.` });
        } catch (error) {
            console.error("Erreur /change :", error);
            return interaction.reply({ content: "❌ Impossible de modifier le pseudo.", ephemeral: true });
        }
    }

    if (legacyCommandsManager) {
        if (interaction.isButton() && await legacyCommandsManager.onButton(interaction)) return;
        if (interaction.isChatInputCommand() && legacyCommandsManager.isLegacy(interaction.commandName)) {
            await legacyCommandsManager.handle(interaction);
            return;
        }
    }

    const isPublicRoleReact =
        interaction.isStringSelectMenu() &&
        interaction.customId.startsWith("rolereact:menu:");
    const isPublicVerify =
        interaction.isButton() &&
        interaction.customId.startsWith("regle:verify:");
    const isPublicInvitesView =
        interaction.isChatInputCommand() &&
        interaction.commandName === "invites" &&
        interaction.options.getString("action") === "view";
    const isPublicInviteStats =
        interaction.isChatInputCommand() &&
        interaction.commandName === "stats-invite";
    const isPublicTicketOpen =
        interaction.isStringSelectMenu() &&
        interaction.customId.startsWith("ticket:open:");
    const isPublicPing = interaction.isChatInputCommand() && interaction.commandName === "ping";
    const isChangeCommand = interaction.isChatInputCommand() && interaction.commandName === "change";
    const isPublicHelp = interaction.isChatInputCommand() && interaction.commandName === "help";
    const isPublicHelpMenu = interaction.isStringSelectMenu() && interaction.customId === "help:category";
    const isPublicGiveawayJoin = interaction.isButton() && interaction.customId.startsWith("giveaway:join:");
    const isPublicTicketClose =
        interaction.isButton() &&
        interaction.customId.startsWith("ticket:close:");

    if (
        !isPublicRoleReact &&
        !isPublicVerify &&
        !isPublicInvitesView &&
        !isPublicInviteStats &&
        !isPublicTicketOpen &&
        !isPublicTicketClose &&
        !isPublicGiveawayJoin &&
        !isChangeCommand &&
        !isPublicPing &&
        !isPublicHelp &&
        !isPublicHelpMenu &&
        (
            interaction.isChatInputCommand() ||
            interaction.isButton() ||
            interaction.isChannelSelectMenu() ||
            interaction.isRoleSelectMenu() ||
            interaction.isStringSelectMenu() ||
            interaction.isModalSubmit()
        ) &&
        !canManage(interaction)
    ) {
        return deny(interaction);
    }

    if (interaction.isChatInputCommand() && interaction.commandName === "backup") {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) return interaction.reply({ content:"❌ `/backup` est réservée aux administrateurs.", ephemeral:true });
        const sub=interaction.options.getSubcommand();
        if(sub === "list") { const items=backupManager.list(interaction.guild.id); return interaction.reply({content:items.length?`💾 **Backups (${items.length})**\n${items.slice(0,20).map(b=>`• \`${b.id}\` — **${b.name}** — ${new Date(b.createdAt).toLocaleString("fr-FR")}`).join("\n")}`:"ℹ️ Aucun backup enregistré.",ephemeral:true}); }
        if(sub === "info") { const b=backupManager.get(interaction.guild.id,interaction.options.getString("id",true)); if(!b)return interaction.reply({content:"❌ Backup introuvable.",ephemeral:true}); const c=b.counts||{}; return interaction.reply({content:`💾 **${b.name}**\nID : \`${b.id}\`\nCréé : ${new Date(b.createdAt).toLocaleString("fr-FR")}\n🏷️ Rôles : **${c.roles||0}**\n📁 Salons/catégories : **${c.channels||0}**\n👥 Membres : **${c.members||0}**\n🔨 Bans : **${c.bans||0}**\n🔌 Intégrations enregistrées : **${c.integrations||0}**\n💬 Messages : **${c.messages||0}**`,ephemeral:true}); }
        if(sub === "delete") { const ok=backupManager.delete(interaction.guild.id,interaction.options.getString("id",true)); return interaction.reply({content:ok?"🗑️ Backup supprimé.":"❌ Backup introuvable.",ephemeral:true}); }
        if(sub === "create") { await interaction.deferReply({ephemeral:true}); try { const b=await backupManager.create(interaction.guild,{name:interaction.options.getString("nom"),includeMessages:interaction.options.getBoolean("messages")!==false,messageLimit:interaction.options.getInteger("limite_messages")||1000}); return interaction.editReply(`✅ Backup créé.\nID : \`${b.id}\`\n🏷️ ${b.counts.roles} rôles • 📁 ${b.counts.channels} salons • 👥 ${b.counts.members} membres • 💬 ${b.counts.messages} messages`); } catch(e){console.error("❌ /backup create",e); return interaction.editReply(`❌ Échec du backup : ${e?.message||e}`);} }
        if(sub === "load") {
            if(interaction.options.getString("confirmation",true)!=="CONFIRMER") return interaction.reply({content:"⚠️ Restauration annulée. Pour éviter une suppression accidentelle, écris exactement **CONFIRMER** dans l’option `confirmation`.",ephemeral:true});
            const b=backupManager.get(interaction.guild.id,interaction.options.getString("id",true)); if(!b)return interaction.reply({content:"❌ Backup introuvable.",ephemeral:true});
            await interaction.deferReply({ephemeral:true}); try { const val=(n,d)=>{const v=interaction.options.getBoolean(n);return v===null?d:v}; await interaction.editReply("⏳ Restauration en cours… Ne redémarre pas le bot."); const r=await backupManager.load(interaction.guild,b,{roles:val("roles",true),channels:val("salons",true),settings:val("parametres",true),members:val("membres",false),bans:val("bans",false),messages:val("messages",false)}); return interaction.editReply(`✅ Restauration terminée. ${r.restoredMessages} message(s) republié(s).\nℹ️ Les bots/intégrations externes ne peuvent pas être réinstallés automatiquement par Discord.`); } catch(e){console.error("❌ /backup load",e); return interaction.editReply(`❌ Échec de la restauration : ${e?.message||e}`);}
        }
    }


    if (interaction.isChatInputCommand() && interaction.commandName === "recuperation") {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) return interaction.reply({ content: "❌ `/recuperation` est réservée aux administrateurs.", ephemeral: true });
        const action = interaction.options.getString("action", true);
        const current = recoveryManager.getSettings(interaction.guild.id);
        if (action === "status") {
            const roles = recoveryManager.getRoles(interaction.guild.id);
            if (!current) return interaction.reply({ content: "ℹ️ La récupération automatique n’est pas encore configurée.", ephemeral: true });
            return interaction.reply({ content: `💾 **Récupération automatique** — ${current.enabled ? "✅ Activée" : "⛔ Désactivée"}\nRôles : ${current.restore_roles ? "✅" : "❌"} (${current.role_mode === "all" ? "tous les rôles compatibles" : `${roles.length} rôle(s) sélectionné(s)`})\nPseudo : ${current.restore_nickname ? "✅" : "❌"}\nDM : ${current.dm_enabled ? "✅" : "❌"}\nSalon : ${current.channel_id ? `<#${current.channel_id}>` : "Aucun"}\nImage : ${current.image_path ? "✅" : "Aucune"}`, ephemeral: true, allowedMentions: { parse: [] } });
        }
        if (action === "disable" || action === "enable") {
            if (!current) return interaction.reply({ content: "❌ Configure d’abord `/recuperation action:Configurer / modifier`.", ephemeral: true });
            recoveryManager.setEnabled(interaction.guild.id, action === "enable");
            return interaction.reply({ content: action === "enable" ? "✅ Récupération automatique activée." : "⛔ Récupération automatique désactivée.", ephemeral: true });
        }
        if (action === "add_role" || action === "remove_role") {
            if (!current) return interaction.reply({ content: "❌ Configure d’abord `/recuperation`.", ephemeral: true });
            const role = interaction.options.getRole("role");
            if (!role || role.id === interaction.guild.id || role.managed) return interaction.reply({ content: "❌ Sélectionne un rôle Discord attribuable valide.", ephemeral: true });
            if (action === "add_role") recoveryManager.addRole(interaction.guild.id, role.id); else recoveryManager.removeRole(interaction.guild.id, role.id);
            return interaction.reply({ content: `${action === "add_role" ? "✅ Rôle ajouté" : "🗑️ Rôle retiré"} : <@&${role.id}>`, ephemeral: true, allowedMentions: { parse: [] } });
        }
        const channel = interaction.options.getChannel("salon");
        const image = interaction.options.getAttachment("image");
        if (image && !isImageAttachment(image)) return interaction.reply({ content: "❌ L’image doit être PNG, JPG, GIF ou WEBP.", ephemeral: true });
        const color = (interaction.options.getString("couleur") || current?.embed_color || "EB126B").replace(/^#/, "");
        if (!/^[0-9a-f]{6}$/i.test(color)) return interaction.reply({ content: "❌ Couleur HEX invalide.", ephemeral: true });
        const bool = (name, fallback) => { const v = interaction.options.getBoolean(name); return v === null ? fallback : v; };
        await interaction.deferReply({ ephemeral: true });
        try {
            await recoveryManager.configure(interaction.guild, {
                channelId: channel?.id || current?.channel_id || null,
                restoreRoles: bool("roles", current ? !!current.restore_roles : true),
                restoreNickname: bool("pseudo", current ? !!current.restore_nickname : true),
                dmEnabled: bool("dm", current ? !!current.dm_enabled : true),
                roleMode: interaction.options.getString("mode_roles") || current?.role_mode || "selected",
                title: interaction.options.getString("titre") || current?.embed_title || "💾 Récupération terminée",
                description: interaction.options.getString("description") || current?.embed_description || "Bienvenue {membre} !\nTes anciens rôles et/ou ton pseudo ont été récupérés.\n**Rôles restaurés :** {roles}\n**Pseudo restauré :** {pseudo}",
                color, image
            });
            return interaction.editReply("✅ **Récupération automatique configurée et activée.**\nVariables disponibles : `{membre}`, `{serveur}`, `{roles}`, `{pseudo}`.\nLe bot sauvegardera les données au départ du membre et les restaurera automatiquement à son retour. Les rôles gérés par Discord ou placés au-dessus du bot sont ignorés.");
        } catch (e) { return interaction.editReply(`❌ Impossible de configurer la récupération : ${e?.message || e}`); }
    }

    if (isPublicGiveawayJoin) return giveawayManager.join(interaction);

    if (interaction.isChatInputCommand() && interaction.commandName === "giveaway") return giveawayManager.create(interaction);
    if (interaction.isChatInputCommand() && interaction.commandName === "giveaway-end") return giveawayManager.end(interaction);
    if (interaction.isChatInputCommand() && interaction.commandName === "reroll") return giveawayManager.reroll(interaction);

    if (interaction.isChatInputCommand() && interaction.commandName === "clearall") {
        if (!interaction.channel?.isTextBased()) return interaction.reply({ content: "❌ Cette commande doit être utilisée dans un salon textuel.", ephemeral: true });
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`clearall:confirm:${interaction.user.id}`).setLabel("Confirmer la suppression").setEmoji("🗑️").setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId(`clearall:cancel:${interaction.user.id}`).setLabel("Annuler").setStyle(ButtonStyle.Secondary)
        );
        return interaction.reply({ content: "⚠️ **Confirmation requise** — supprimer tous les messages de ce salon ? Cette action est irréversible.", components: [row], ephemeral: true });
    }

    if (interaction.isButton() && interaction.customId.startsWith("clearall:")) {
        const [, action, ownerId] = interaction.customId.split(":");
        if (interaction.user.id !== ownerId) return interaction.reply({ content: "❌ Seule la personne ayant lancé `/clearall` peut confirmer.", ephemeral: true });
        if (action === "cancel") return interaction.update({ content: "✅ Suppression annulée.", components: [] });
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages)) return interaction.update({ content: "❌ Tu n’as plus la permission **Gérer les messages**.", components: [] });
        await interaction.update({ content: "🗑️ Suppression des messages en cours…", components: [] });
        const channel = interaction.channel;
        let deleted = 0;
        try {
            while (true) {
                const messages = await channel.messages.fetch({ limit: 100 });
                if (!messages.size) break;
                const now = Date.now();
                const recent = messages.filter(m => now - m.createdTimestamp < 14 * 24 * 60 * 60 * 1000);
                const old = messages.filter(m => now - m.createdTimestamp >= 14 * 24 * 60 * 60 * 1000);
                if (recent.size) {
                    const result = await channel.bulkDelete(recent, true);
                    deleted += result.size;
                }
                for (const message of old.values()) {
                    try { await message.delete(); deleted++; } catch {}
                }
                if (messages.size < 100) break;
            }
            try { await interaction.editReply({ content: `✅ **${deleted} message(s)** supprimé(s) du salon.`, components: [] }); } catch {}
        } catch (error) {
            console.error("[clearall]", error);
            try { await interaction.editReply({ content: `❌ Suppression interrompue après **${deleted} message(s)**. Vérifie que le bot possède **Gérer les messages** et **Lire l’historique des messages**.`, components: [] }); } catch {}
        }
        return;
    }

    if (isPublicTicketOpen) {
        return ticketManager.handleOpen(interaction);
    }

    if (isPublicTicketClose) {
        return ticketManager.handleClose(interaction);
    }

    if (isPublicPing) {
        const started = Date.now();
        await interaction.deferReply();

        const responseLatency = Date.now() - started;
        const websocketLatency = Math.max(0, Math.round(interaction.client.ws.ping));
        const guilds = interaction.client.guilds.cache.size;
        const visibleMembers = interaction.client.guilds.cache.reduce((sum, guild) => sum + (guild.memberCount || 0), 0);
        const uptimeSeconds = Math.floor(process.uptime());
        const days = Math.floor(uptimeSeconds / 86400);
        const hours = Math.floor((uptimeSeconds % 86400) / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        const seconds = uptimeSeconds % 60;
        const uptime = [days ? `${days} jour${days > 1 ? "s" : ""}` : null, hours ? `${hours} heure${hours > 1 ? "s" : ""}` : null, minutes ? `${minutes} minute${minutes > 1 ? "s" : ""}` : null, `${seconds} seconde${seconds > 1 ? "s" : ""}`].filter(Boolean).join(", ");
        const memoryMb = Math.round(process.memoryUsage().rss / 1024 / 1024);
        const image = interaction.options.getAttachment("image");
        const discordVersion = interaction.client.constructor?.version || "14.x";

        const embed = new EmbedBuilder()
            .setTitle(`🤖 Informations sur ${interaction.client.user.username}`)
            .setDescription([
                `**Identifiant :** \`${interaction.client.user.id}\``,
                `**Serveurs :** ${guilds}`,
                `**Membres visibles :** ${visibleMembers}`,
                `**Latence commande :** ${responseLatency} ms`,
                `**Latence Discord :** ${websocketLatency} ms`,
                `**Node.js :** ${process.version}`,
                `**Discord.js :** ${discordVersion}`,
                `**RAM utilisée :** ${memoryMb} Mo`,
                `**Temps en ligne :** ${uptime}`
            ].join("\n"))
            .setColor(0x5865F2)
            .setTimestamp();

        if (image && isImageAttachment(image)) embed.setImage(image.url);
        if (interaction.client.user.displayAvatarURL) embed.setThumbnail(interaction.client.user.displayAvatarURL());

        return interaction.editReply({ embeds: [embed], allowedMentions: { parse: [] } });
    }

    if (interaction.isChatInputCommand()) {
        if (interaction.commandName === "setuptiktok") {
            return interaction.reply({
                embeds: [createSetupEmbed(interaction.guild.id)],
                components: createSetupButtons(),
                ephemeral: true,
                allowedMentions: { parse: [] }
            });
        }

        if (interaction.commandName === "lives") {
            const accounts = TikTokAccountManager.list(
                interaction.guild.id
            );

            if (accounts.length === 0) {
                return interaction.reply({
                    content: "📭 Aucun compte TikTok surveillé.",
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });

            const liveAccounts = [];
            const unknownAccounts = [];

            for (const username of accounts) {
                try {
                    const state = await liveManager.getLiveState(username);

                    if (state === true) {
                        liveAccounts.push(username);
                    } else if (state === null) {
                        unknownAccounts.push(username);
                    }
                } catch (error) {
                    console.error(
                        `❌ Impossible de vérifier @${username} avec /lives :`,
                        error
                    );
                    unknownAccounts.push(username);
                }

                await new Promise(resolve => setTimeout(resolve, 750));
            }

            const embeds = [];

            if (liveAccounts.length === 0) {
                embeds.push(
                    new EmbedBuilder()
                        .setColor(0x8b5cf6)
                        .setTitle("🟣 Lives TikTok en cours")
                        .setDescription(
                            "⚫ **Aucun des comptes surveillés n'est actuellement en live.**"
                        )
                        .setFooter({
                            text: `${accounts.length} compte${accounts.length > 1 ? "s" : ""} vérifié${accounts.length > 1 ? "s" : ""}`
                        })
                        .setTimestamp()
                );
            } else {
                const pageSize = 20;

                for (let i = 0; i < liveAccounts.length; i += pageSize) {
                    const page = liveAccounts.slice(i, i + pageSize);
                    const pageNumber = Math.floor(i / pageSize) + 1;
                    const totalPages = Math.ceil(liveAccounts.length / pageSize);

                    embeds.push(
                        new EmbedBuilder()
                            .setColor(0x8b5cf6)
                            .setTitle(
                                totalPages > 1
                                    ? `🟣 Lives TikTok en cours — ${pageNumber}/${totalPages}`
                                    : "🟣 Lives TikTok en cours"
                            )
                            .setDescription(
                                page
                                    .map(
                                        username =>
                                            `🔴 **[@${username}](https://www.tiktok.com/@${username}/live)** — [Regarder le live](https://www.tiktok.com/@${username}/live)`
                                    )
                                    .join("\n\n")
                            )
                            .setFooter({
                                text: `${liveAccounts.length} live${liveAccounts.length > 1 ? "s" : ""} actif${liveAccounts.length > 1 ? "s" : ""} sur ${accounts.length} compte${accounts.length > 1 ? "s" : ""} surveillé${accounts.length > 1 ? "s" : ""}`
                            })
                            .setTimestamp()
                    );
                }
            }

            const visibleEmbeds = embeds.slice(0, 10);

            let note = "";
            if (unknownAccounts.length) {
                note =
                    `\n🟠 ${unknownAccounts.length} compte${unknownAccounts.length > 1 ? "s" : ""} n'${unknownAccounts.length > 1 ? "ont" : "a"} pas pu être vérifié${unknownAccounts.length > 1 ? "s" : ""} par TikTok.`;
            }

            if (embeds.length > 10) {
                note +=
                    `\n⚠️ La liste dépasse la limite Discord : ${liveAccounts.length - 200} live(s) supplémentaire(s) ne sont pas affichés.`;
            }

            const refreshButton = new ButtonBuilder()
                .setCustomId("tiktok:lives")
                .setLabel("Actualiser les lives")
                .setEmoji("🔄")
                .setStyle(ButtonStyle.Primary);

            return interaction.editReply({
                content: note || undefined,
                embeds: visibleEmbeds,
                components: [
                    new ActionRowBuilder().addComponents(refreshButton)
                ],
                allowedMentions: { parse: [] }
            });
        }

        if (["nrj", "skyrock", "funradio", "virginradio", "autoroute1077"].includes(interaction.commandName)) {
            try {
                return await radioManager.play(interaction, interaction.commandName);
            } catch (error) {
                console.error(`❌ /${interaction.commandName}`, error);
                if (interaction.deferred || interaction.replied) {
                    return interaction.editReply("❌ Impossible de lancer cette radio pour le moment.");
                }
                return interaction.reply({ content: "❌ Impossible de lancer cette radio pour le moment.", ephemeral: true });
            }
        }

        if (interaction.commandName === "join") {
            if (!interaction.guild) return interaction.reply({ content: "❌ Cette commande doit être utilisée dans un serveur.", ephemeral: true });
            const channel = interaction.options.getChannel("salon", true);
            if (![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)) {
                return interaction.reply({ content: "❌ Choisis un salon vocal valide.", ephemeral: true });
            }
            const me = interaction.guild.members.me;
            const permissions = channel.permissionsFor(me);
            if (!permissions?.has(PermissionFlagsBits.ViewChannel) || !permissions?.has(PermissionFlagsBits.Connect)) {
                return interaction.reply({ content: "❌ Je n’ai pas la permission de voir ou rejoindre ce salon vocal.", ephemeral: true });
            }
            if (channel.type === ChannelType.GuildVoice && !permissions.has(PermissionFlagsBits.Speak)) {
                return interaction.reply({ content: "❌ Je peux rejoindre ce salon, mais je n’ai pas la permission **Parler**.", ephemeral: true });
            }
            try {
                const oldConnection = getVoiceConnection(interaction.guild.id);
                if (oldConnection) oldConnection.destroy();
                joinVoiceChannel({
                    channelId: channel.id,
                    guildId: interaction.guild.id,
                    adapterCreator: interaction.guild.voiceAdapterCreator,
                    selfDeaf: true,
                    selfMute: false
                });
                return interaction.reply({ content: `🔊 J’ai rejoint ${channel}.` });
            } catch (error) {
                console.error("❌ /join", error);
                return interaction.reply({ content: `❌ Impossible de rejoindre ce salon vocal : ${error?.message || error}`, ephemeral: true });
            }
        }

        if (interaction.commandName === "leave") {
            if (!interaction.guild) return interaction.reply({ content: "❌ Cette commande doit être utilisée dans un serveur.", ephemeral: true });
            const connection = getVoiceConnection(interaction.guild.id);
            radioManager.stop(interaction.guild.id);
            if (!connection) return interaction.reply({ content: "ℹ️ Je ne suis actuellement dans aucun salon vocal.", ephemeral: true });
            connection.destroy();
            return interaction.reply({ content: "👋 J’ai quitté le salon vocal." });
        }

        if (interaction.commandName === "activity") {
            const activityType = interaction.options.getString("type", true);
            const activityText = interaction.options.getString("texte")?.trim();
            const streamUrl = interaction.options.getString("url")?.trim();

            if (activityType === "stop") {
                interaction.client.user.setActivity(null);

                return interaction.reply({
                    content: "✅ L’activité du bot a été désactivée.",
                    ephemeral: true
                });
            }

            const text = activityText || "Nexora Legend";

            if (activityType === "stream") {
                if (!streamUrl) {
                    return interaction.reply({
                        content:
                            "❌ Pour **Stream**, ajoute aussi l’option `url` avec un lien Twitch ou YouTube valide. Discord exige ce lien pour afficher correctement l’activité de streaming (violette).",
                        ephemeral: true
                    });
                }

                let parsedUrl;
                try {
                    parsedUrl = new URL(streamUrl);
                } catch {
                    return interaction.reply({
                        content: "❌ Le lien de stream n’est pas valide.",
                        ephemeral: true
                    });
                }

                const hostname = parsedUrl.hostname.toLowerCase().replace(/^www\./, "");
                const validStreamHost =
                    hostname === "twitch.tv" ||
                    hostname.endsWith(".twitch.tv") ||
                    hostname === "youtube.com" ||
                    hostname.endsWith(".youtube.com") ||
                    hostname === "youtu.be";

                if (!validStreamHost) {
                    return interaction.reply({
                        content:
                            "❌ Discord accepte uniquement une URL **Twitch ou YouTube** pour une activité Stream.",
                        ephemeral: true
                    });
                }

                interaction.client.user.setActivity(text, {
                    type: ActivityType.Streaming,
                    url: streamUrl
                });

                return interaction.reply({
                    content: `✅ Activité changée en **Stream** : ${text}`,
                    ephemeral: true
                });
            }

            const typeMap = {
                listen: ActivityType.Listening,
                play: ActivityType.Playing,
                watch: ActivityType.Watching,
                compet: ActivityType.Competing
            };

            if (activityType === "custom") {
                interaction.client.user.setPresence({
                    activities: [
                        {
                            name: "Custom Status",
                            state: text,
                            type: ActivityType.Custom
                        }
                    ]
                });
            } else {
                interaction.client.user.setActivity(text, {
                    type: typeMap[activityType]
                });
            }

            const labels = {
                listen: "Listen",
                play: "Play",
                watch: "Watch",
                compet: "Compet",
                custom: "Custom"
            };

            return interaction.reply({
                content: `✅ Activité changée en **${labels[activityType]}** : ${text}`,
                ephemeral: true
            });
        }

        if (interaction.commandName === "règle") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: "❌ La commande `/règle` est réservée aux administrateurs.", ephemeral: true });
            }

            const title = interaction.options.getString("titre", true).trim();
            const description = interaction.options.getString("description", true).trim();
            const role = interaction.options.getRole("role", true);
            const channel = interaction.options.getChannel("salon", true);
            const banner = interaction.options.getAttachment("banniere");
            const colorRaw = (interaction.options.getString("couleur") || "57F287").replace(/^#/, "");

            if (!channel?.isTextBased?.()) {
                return interaction.reply({ content: "❌ Choisis un salon texte valide.", ephemeral: true });
            }
            if (role.id === interaction.guild.id || role.managed) {
                return interaction.reply({ content: "❌ Choisis un rôle attribuable par le bot.", ephemeral: true });
            }
            const me = interaction.guild.members.me;
            if (!me?.permissions.has(PermissionFlagsBits.ManageRoles) || me.roles.highest.comparePositionTo(role) <= 0) {
                return interaction.reply({ content: "❌ Le bot doit avoir **Gérer les rôles** et son rôle doit être placé au-dessus du rôle sélectionné.", ephemeral: true });
            }
            if (banner && !isImageAttachment(banner)) {
                return interaction.reply({ content: "❌ La bannière doit être une image PNG, JPG, GIF ou WEBP.", ephemeral: true });
            }
            if (!/^[0-9a-fA-F]{6}$/.test(colorRaw)) {
                return interaction.reply({ content: "❌ Couleur invalide. Exemple : `57F287`.", ephemeral: true });
            }

            await interaction.deferReply({ ephemeral: true });

            const embed = new EmbedBuilder()
                .setColor(parseInt(colorRaw, 16))
                .setTitle(title)
                .setDescription(description);

            const payload = {
                embeds: [embed],
                components: [new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`regle:verify:${role.id}`)
                        .setLabel("Se vérifier")
                        .setEmoji("✅")
                        .setStyle(ButtonStyle.Success)
                )],
                allowedMentions: { parse: [] }
            };

            if (banner) {
                const safeName = `reglement-${Date.now()}-${(banner.name || "banniere.png").replace(/[^a-zA-Z0-9._-]/g, "_")}`;
                payload.files = [{ attachment: banner.url, name: safeName }];
                embed.setImage(`attachment://${safeName}`);
            }

            try {
                const sent = await channel.send(payload);
                return interaction.editReply({
                    content: `✅ Règlement publié dans <#${channel.id}>. Le bouton vert **✅ Se vérifier** attribuera <@&${role.id}>.\n🔗 https://discord.com/channels/${interaction.guild.id}/${channel.id}/${sent.id}`,
                    allowedMentions: { parse: [] }
                });
            } catch (error) {
                console.error("❌ Erreur /règle :", error);
                return interaction.editReply({ content: "❌ Impossible de publier le règlement. Vérifie les permissions du bot dans le salon." });
            }
        }

        if (interaction.commandName === "say") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({
                    content: "❌ La commande `/say` est réservée aux administrateurs.",
                    ephemeral: true
                });
            }

            const message = interaction.options.getString("message", true).trim();
            const channel = interaction.options.getChannel("salon") || interaction.channel;
            const image = interaction.options.getAttachment("image");
            const file1 = interaction.options.getAttachment("fichier1");
            const file2 = interaction.options.getAttachment("fichier2");
            const file3 = interaction.options.getAttachment("fichier3");

            if (!message) {
                return interaction.reply({
                    content: "❌ Le message ne peut pas être vide.",
                    ephemeral: true
                });
            }

            if (!channel?.isTextBased?.()) {
                return interaction.reply({
                    content: "❌ Choisis un salon texte valide.",
                    ephemeral: true
                });
            }

            if (image && !isImageAttachment(image)) {
                return interaction.reply({
                    content: "❌ L’option `image` doit contenir une image (PNG, JPG, GIF ou WEBP).",
                    ephemeral: true
                });
            }

            const attachments = [image, file1, file2, file3]
                .filter(Boolean)
                .map(file => ({
                    url: file.url,
                    name: file.name || "fichier",
                    contentType: file.contentType || null,
                    size: file.size || null
                }));

            const token = makeSayToken();
            pendingSay.set(token, {
                guildId: interaction.guild.id,
                userId: interaction.user.id,
                channelId: channel.id,
                message,
                attachments,
                createdAt: Date.now()
            });

            setTimeout(() => pendingSay.delete(token), 10 * 60 * 1000).unref?.();

            const preview = new EmbedBuilder()
                .setColor(0x8b5cf6)
                .setTitle("🗣️ Aperçu de /say")
                .setDescription(message)
                .addFields(
                    { name: "📍 Salon", value: `<#${channel.id}>`, inline: true },
                    { name: "📎 Fichiers", value: attachments.length ? attachments.map(a => `• ${a.name}`).join("\n") : "Aucun", inline: false }
                )
                .setFooter({ text: "Le message final sera envoyé par le bot." });

            if (image?.url) preview.setImage(image.url);

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`say:confirm:${token}`)
                    .setLabel("Envoyer")
                    .setEmoji("📨")
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId(`say:cancel:${token}`)
                    .setLabel("Annuler")
                    .setStyle(ButtonStyle.Secondary)
            );

            return interaction.reply({
                embeds: [preview],
                components: [row],
                ephemeral: true,
                allowedMentions: { parse: [] }
            });
        }

        if (interaction.commandName === "dmall") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({
                    content: "❌ La commande `/dmall` est réservée aux administrateurs.",
                    ephemeral: true
                });
            }

            const role = interaction.options.getRole("role", true);
            const text = interaction.options.getString("texte", true).trim();
            const image = interaction.options.getAttachment("image");

            if (role.id === interaction.guild.id) {
                return interaction.reply({
                    content: "❌ Choisis un rôle précis. Le rôle `@everyone` n’est pas accepté pour `/dmall`.",
                    ephemeral: true
                });
            }

            if (!text) {
                return interaction.reply({
                    content: "❌ Le texte du message ne peut pas être vide.",
                    ephemeral: true
                });
            }

            if (image && !isImageAttachment(image)) {
                return interaction.reply({
                    content: "❌ Le fichier ajouté doit être une image (PNG, JPG, GIF ou WEBP).",
                    ephemeral: true
                });
            }

            const token = makeDmallToken();
            pendingDmall.set(token, {
                guildId: interaction.guild.id,
                userId: interaction.user.id,
                roleId: role.id,
                roleName: role.name,
                text,
                imageUrl: image?.url || null,
                imageName: image?.name || null,
                createdAt: Date.now()
            });

            // Nettoyage automatique de la confirmation après 10 minutes.
            setTimeout(() => pendingDmall.delete(token), 10 * 60 * 1000).unref?.();

            const preview = new EmbedBuilder()
                .setColor(0x8b5cf6)
                .setTitle("📨 Aperçu du DMALL")
                .setDescription(text)
                .addFields({
                    name: "🎯 Rôle ciblé",
                    value: `<@&${role.id}>`,
                    inline: false
                })
                .setFooter({ text: `Le DM sera envoyé uniquement aux membres du rôle ${role.name}.` });

            if (image?.url) preview.setImage(image.url);

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`dmall:confirm:${token}`)
                    .setLabel("Envoyer au rôle")
                    .setEmoji("📨")
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId(`dmall:cancel:${token}`)
                    .setLabel("Annuler")
                    .setStyle(ButtonStyle.Secondary)
            );

            return interaction.reply({
                embeds: [preview],
                components: [row],
                ephemeral: true,
                allowedMentions: { parse: [] }
            });
        }

        if (interaction.commandName === "rolereact") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageRoles)) {
                return interaction.reply({
                    content: "❌ La commande `/rolereact` nécessite la permission **Gérer les rôles**.",
                    ephemeral: true
                });
            }

            const messageId = interaction.options.getString("message_id", true).trim();
            const role = interaction.options.getRole("role", true);
            const label = interaction.options.getString("nom", true).trim();
            const description = interaction.options.getString("description")?.trim() || null;
            const emoji = interaction.options.getString("emoji")?.trim() || null;
            const channel = interaction.options.getChannel("salon") || interaction.channel;

            if (!/^\d{15,25}$/.test(messageId)) {
                return interaction.reply({ content: "❌ L’ID du message n’est pas valide.", ephemeral: true });
            }
            if (!channel?.isTextBased?.()) {
                return interaction.reply({ content: "❌ Choisis un salon texte valide.", ephemeral: true });
            }
            if (role.id === interaction.guild.id) {
                return interaction.reply({ content: "❌ Le rôle `@everyone` ne peut pas être utilisé.", ephemeral: true });
            }
            if (role.managed || !role.editable) {
                return interaction.reply({
                    content: "❌ Je ne peux pas attribuer ce rôle. Place mon rôle au-dessus de celui-ci dans la hiérarchie Discord.",
                    ephemeral: true
                });
            }

            let targetMessage;
            try {
                targetMessage = await channel.messages.fetch(messageId);
            } catch {
                return interaction.reply({
                    content: "❌ Message introuvable dans ce salon. Vérifie l’ID et le salon sélectionné.",
                    ephemeral: true
                });
            }

            const current = RoleReactManager.get(interaction.guild.id, messageId);
            const options = current?.options ? [...current.options] : [];
            const existingIndex = options.findIndex(item => item.roleId === role.id);
            const item = { roleId: role.id, label, description, emoji };

            if (existingIndex >= 0) options[existingIndex] = item;
            else options.push(item);

            if (options.length > 25) {
                return interaction.reply({
                    content: "❌ Discord limite un menu à **25 options**. Ce menu est déjà complet.",
                    ephemeral: true
                });
            }

            let menuMessage = null;
            if (current?.menuMessageId) {
                try {
                    menuMessage = await channel.messages.fetch(current.menuMessageId);
                } catch {
                    menuMessage = null;
                }
            }

            const components = buildRoleReactComponents(messageId, options);

            try {
                if (menuMessage) {
                    await menuMessage.edit({
                        content: "**Sélectionnez une catégorie...**",
                        components,
                        allowedMentions: { parse: [] }
                    });
                } else {
                    menuMessage = await targetMessage.reply({
                        content: "**Sélectionnez une catégorie...**",
                        components,
                        allowedMentions: { parse: [] }
                    });
                }
            } catch (error) {
                console.error("❌ /rolereact : impossible de créer/modifier le menu :", error);
                return interaction.reply({
                    content: "❌ Impossible d’ajouter le menu. Vérifie que le bot peut **voir le salon, envoyer des messages et lire l’historique**.",
                    ephemeral: true
                });
            }

            RoleReactManager.save(
                interaction.guild.id,
                messageId,
                channel.id,
                menuMessage.id,
                options
            );

            return interaction.reply({
                content:
                    `✅ Rôle <@&${role.id}> ${existingIndex >= 0 ? "mis à jour" : "ajouté"} dans le menu lié au message **${messageId}**.\n` +
                    `Le membre choisit l’option **${label}** pour ajouter ou retirer le rôle.`,
                ephemeral: true,
                allowedMentions: { parse: [] }
            });
        }

        if (interaction.commandName === "twitch") {
            const action = interaction.options.getString("action", true);

            if (action === "list") {
                const accounts = TwitchAccountManager.list(interaction.guild.id);
                if (!accounts.length) {
                    return interaction.reply({
                        content: "📭 Aucun compte Twitch configuré sur ce serveur.",
                        ephemeral: true
                    });
                }

                const lines = accounts.map(account => {
                    const role = account.pingRoleId ? `<@&${account.pingRoleId}>` : "Aucun rôle";
                    return `🟣 **${account.login}** → <#${account.notifyChannelId}> • ${role}`;
                });

                return interaction.reply({
                    content: `**Comptes Twitch surveillés :**\n${lines.join("\n")}`,
                    ephemeral: true,
                    allowedMentions: { parse: [] }
                });
            }

            const rawName = interaction.options.getString("nom")?.trim();
            if (!rawName) {
                return interaction.reply({
                    content: "❌ Ajoute l'option `nom` avec le pseudo Twitch.",
                    ephemeral: true
                });
            }

            const login = rawName
                .replace(/^https?:\/\/(www\.)?twitch\.tv\//i, "")
                .replace(/^@/, "")
                .split(/[/?#]/)[0]
                .toLowerCase();

            if (action === "remove") {
                const removed = TwitchAccountManager.remove(interaction.guild.id, login);
                return interaction.reply({
                    content: removed
                        ? `✅ **${login}** n'est plus surveillé sur Twitch.`
                        : `❌ **${login}** n'était pas configuré.`,
                    ephemeral: true
                });
            }

            if (!twitchManager?.configured) {
                return interaction.reply({
                    content:
                        "❌ Twitch n'est pas encore relié au bot. Ajoute `TWITCH_CLIENT_ID` et `TWITCH_CLIENT_SECRET` dans le fichier `.env`, puis redémarre le bot.",
                    ephemeral: true
                });
            }

            const channel = interaction.options.getChannel("salon");
            if (!channel) {
                return interaction.reply({
                    content: "❌ Pour configurer un compte Twitch, sélectionne aussi l'option `salon`.",
                    ephemeral: true
                });
            }

            const role = interaction.options.getRole("role");
            const title = interaction.options.getString("titre")?.trim();
            const description = interaction.options.getString("description")?.trim();
            const color = interaction.options.getString("couleur")?.trim() || "9146FF";
            const image = interaction.options.getAttachment("image");

            if (!/^#?[0-9a-f]{6}$/i.test(color)) {
                return interaction.reply({
                    content: "❌ `couleur` doit être une couleur HEX sur 6 caractères, par exemple `9146FF`.",
                    ephemeral: true
                });
            }

            if (image && !isImageAttachment(image)) {
                return interaction.reply({
                    content: "❌ Le fichier `image` doit être une image PNG, JPG, GIF ou WEBP.",
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });

            try {
                const result = await twitchManager.configureAccount(interaction.guild.id, {
                    login,
                    notifyChannelId: channel.id,
                    pingRoleId: role?.id || null,
                    embedTitle: title || null,
                    embedDescription: description || null,
                    embedColor: color.replace(/^#/, ""),
                    imageUrl: image?.url || null
                });

                const status = result.isLive
                    ? "\n🔴 Le compte est déjà en LIVE : la notification vient d'être envoyée."
                    : "\n⚫ Le compte est actuellement hors ligne. La prochaine mise en LIVE sera notifiée automatiquement.";

                return interaction.editReply({
                    content:
                        `✅ Twitch configuré pour **${result.user.display_name}**.\n` +
                        `📢 Salon : <#${channel.id}>\n` +
                        `🔔 Rôle : ${role ? `<@&${role.id}>` : "Aucun"}\n` +
                        `🎨 Couleur : #${color.replace(/^#/, "").toUpperCase()}${status}`,
                    allowedMentions: { parse: [] }
                });
            } catch (error) {
                return interaction.editReply({
                    content: `❌ Impossible de configurer Twitch : ${error?.message || error}`
                });
            }
        }

        if (interaction.commandName === "kicklive") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({
                    content: "❌ La commande `/kicklive` est réservée aux administrateurs.",
                    ephemeral: true
                });
            }

            const action = interaction.options.getString("action", true);

            if (action === "list") {
                const accounts = KickAccountManager.list(interaction.guild.id);
                if (!accounts.length) {
                    return interaction.reply({
                        content: "📭 Aucun compte Kick configuré sur ce serveur.",
                        ephemeral: true
                    });
                }

                const lines = accounts.map(account => {
                    const role = account.pingRoleId ? `<@&${account.pingRoleId}>` : "Aucun rôle";
                    return `🟢 **${account.slug}** → <#${account.notifyChannelId}> • ${role}`;
                });

                return interaction.reply({
                    content: `**Comptes Kick surveillés :**\n${lines.join("\n")}`,
                    ephemeral: true,
                    allowedMentions: { parse: [] }
                });
            }

            const rawName = interaction.options.getString("nom")?.trim();
            if (!rawName) {
                return interaction.reply({
                    content: "❌ Ajoute l'option `nom` avec le pseudo ou le lien Kick.",
                    ephemeral: true
                });
            }

            const slug = rawName
                .replace(/^https?:\/\/(www\.)?kick\.com\//i, "")
                .replace(/^@/, "")
                .split(/[/?#]/)[0]
                .toLowerCase();

            if (action === "remove") {
                const removed = KickAccountManager.remove(interaction.guild.id, slug);
                return interaction.reply({
                    content: removed
                        ? `✅ **${slug}** n'est plus surveillé sur Kick.`
                        : `❌ **${slug}** n'était pas configuré.`,
                    ephemeral: true
                });
            }

            const channel = interaction.options.getChannel("salon");
            if (!channel) {
                return interaction.reply({
                    content: "❌ Pour configurer un compte Kick, sélectionne aussi l'option `salon`.",
                    ephemeral: true
                });
            }

            const role = interaction.options.getRole("role");
            const title = interaction.options.getString("titre")?.trim();
            const description = interaction.options.getString("description")?.trim();
            const color = interaction.options.getString("couleur")?.trim() || "53FC18";
            const image = interaction.options.getAttachment("image");

            if (!/^#?[0-9a-f]{6}$/i.test(color)) {
                return interaction.reply({
                    content: "❌ `couleur` doit être une couleur HEX sur 6 caractères, par exemple `53FC18`.",
                    ephemeral: true
                });
            }

            if (image && !isImageAttachment(image)) {
                return interaction.reply({
                    content: "❌ Le fichier `image` doit être une image PNG, JPG, GIF ou WEBP.",
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });

            try {
                const result = await kickManager.configureAccount(interaction.guild.id, {
                    slug,
                    notifyChannelId: channel.id,
                    pingRoleId: role?.id || null,
                    embedTitle: title || null,
                    embedDescription: description || null,
                    embedColor: color.replace(/^#/, ""),
                    imageUrl: image?.url || null
                });

                const displayName = result.channel.user?.username || result.channel.slug || slug;
                const status = result.isLive
                    ? "\n🔴 Le compte est déjà en LIVE : la notification vient d'être envoyée."
                    : "\n⚫ Le compte est actuellement hors ligne. La prochaine mise en LIVE sera notifiée automatiquement.";

                return interaction.editReply({
                    content:
                        `✅ Kick configuré pour **${displayName}**.\n` +
                        `📢 Salon : <#${channel.id}>\n` +
                        `🔔 Rôle : ${role ? `<@&${role.id}>` : "Aucun"}\n` +
                        `🎨 Couleur : #${color.replace(/^#/, "").toUpperCase()}${status}`,
                    allowedMentions: { parse: [] }
                });
            } catch (error) {
                return interaction.editReply({
                    content: `❌ Impossible de configurer Kick : ${error?.message || error}`
                });
            }
        }

        if (interaction.commandName === "youtube") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({
                    content: "❌ La commande `/youtube` est réservée aux administrateurs.",
                    ephemeral: true
                });
            }

            const action = interaction.options.getString("action", true);
            if (action === "list") {
                const accounts = YouTubeAccountManager.list(interaction.guild.id);
                return interaction.reply({ content: accounts.length ? `**Chaînes YouTube surveillées :**\n${accounts.map(a => `🔴 **${a.channelName}** → <#${a.notifyChannelId}> • ${a.pingRoleId ? `<@&${a.pingRoleId}>` : "Aucun rôle"}`).join("\n")}` : "📭 Aucune chaîne YouTube configurée sur ce serveur.", ephemeral: true, allowedMentions: { parse: [] } });
            }
            const rawName = interaction.options.getString("nom")?.trim();
            if (!rawName) return interaction.reply({ content: "❌ Ajoute l'option `nom` avec le nom, @handle ou lien de la chaîne YouTube.", ephemeral: true });
            if (action === "remove") {
                const accounts = YouTubeAccountManager.list(interaction.guild.id);
                const match = accounts.find(a => a.channelName.toLowerCase() === rawName.replace(/^@/, "").toLowerCase());
                const removed = match ? YouTubeAccountManager.remove(interaction.guild.id, match.channelName) : false;
                return interaction.reply({ content: removed ? `✅ **${match.channelName}** n'est plus surveillée sur YouTube.` : "❌ Cette chaîne n'était pas configurée.", ephemeral: true });
            }
            if (!youtubeManager?.configured) return interaction.reply({ content: "❌ YouTube n'est pas encore relié au bot. Ajoute `YOUTUBE_API_KEY` dans `.env`, puis redémarre.", ephemeral: true });
            const channel = interaction.options.getChannel("salon");
            if (!channel) return interaction.reply({ content: "❌ Sélectionne aussi l'option `salon`.", ephemeral: true });
            const role=interaction.options.getRole("role"), title=interaction.options.getString("titre")?.trim(), description=interaction.options.getString("description")?.trim(), color=interaction.options.getString("couleur")?.trim()||"FF0000", image=interaction.options.getAttachment("image");
            if (!/^#?[0-9a-f]{6}$/i.test(color)) return interaction.reply({content:"❌ `couleur` doit être une couleur HEX, ex : `FF0000`.",ephemeral:true});
            if (image && !isImageAttachment(image)) return interaction.reply({content:"❌ `image` doit être une image PNG, JPG, GIF ou WEBP.",ephemeral:true});
            await interaction.deferReply({ephemeral:true});
            try { const r=await youtubeManager.configureAccount(interaction.guild.id,{channelName:rawName,notifyChannelId:channel.id,pingRoleId:role?.id||null,embedTitle:title||null,embedDescription:description||null,embedColor:color.replace(/^#/,""),imageUrl:image?.url||null}); return interaction.editReply({content:`✅ YouTube configuré pour **${r.channel.name}**.\n📢 Salon : <#${channel.id}>\n🔔 Rôle : ${role?`<@&${role.id}>`:"Aucun"}\n🎨 Couleur : #${color.replace(/^#/,"").toUpperCase()}\n${r.isLive?"🔴 La chaîne est déjà en LIVE : notification envoyée.":"⚫ La chaîne est hors ligne. Le prochain LIVE sera notifié automatiquement."}`,allowedMentions:{parse:[]}}); } catch(e){return interaction.editReply({content:`❌ Impossible de configurer YouTube : ${e?.message||e}`});}
        }

        if (interaction.commandName === "invitelogger") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: "❌ La commande `/invitelogger` est réservée aux administrateurs.", ephemeral: true });
            }

            const action = interaction.options.getString("action", true);
            const current = inviteLoggerManager.getSettings(interaction.guild.id);

            if (action === "status") {
                if (!current) {
                    return interaction.reply({ content: "ℹ️ InviteLogger n’est pas encore configuré sur ce serveur.", ephemeral: true });
                }
                return interaction.reply({
                    content: `📨 **InviteLogger**\nÉtat : ${current.enabled ? "✅ Activé" : "⛔ Désactivé"}\nSalon : <#${current.channel_id}>\nImage : ${current.image_path ? "✅ configurée" : "Aucune"}\n\n**Variables disponibles :** \`{membre}\`, \`{serveur}\`, \`{inviteur}\`, \`{invitations}\`, \`{membres}\``,
                    ephemeral: true,
                    allowedMentions: { parse: [] }
                });
            }

            if (action === "disable") {
                if (!current) return interaction.reply({ content: "ℹ️ InviteLogger n’est pas configuré.", ephemeral: true });
                inviteLoggerManager.disable(interaction.guild.id);
                return interaction.reply({ content: "⛔ InviteLogger est maintenant désactivé. La configuration reste enregistrée.", ephemeral: true });
            }

            const channel = interaction.options.getChannel("salon");
            const welcomeMessage = interaction.options.getString("message_arrivee")?.trim();
            const leaveMessage = interaction.options.getString("message_depart")?.trim();
            const image = interaction.options.getAttachment("image");

            if (!channel?.isTextBased?.()) {
                return interaction.reply({ content: "❌ Pour **Configurer / modifier**, choisis le `salon`.", ephemeral: true });
            }
            if (!welcomeMessage || !leaveMessage) {
                return interaction.reply({
                    content: "❌ Renseigne `message_arrivee` et `message_depart`. Tu peux utiliser : `{membre}`, `{serveur}`, `{inviteur}`, `{invitations}`, `{membres}`.",
                    ephemeral: true
                });
            }
            if (image && !isImageAttachment(image)) {
                return interaction.reply({ content: "❌ L’image doit être en PNG, JPG, GIF ou WEBP.", ephemeral: true });
            }

            const me = interaction.guild.members.me;
            if (!me?.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return interaction.reply({
                    content: "❌ Pour identifier l’inviteur, le bot doit avoir la permission **Gérer le serveur**.",
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });
            try {
                await inviteLoggerManager.configure(interaction.guild, {
                    channelId: channel.id,
                    welcomeMessage,
                    leaveMessage,
                    image
                });
                return interaction.editReply({
                    content: `✅ **InviteLogger activé** dans <#${channel.id}>.\n\n**Variables accessibles dans les messages :**\n• \`{membre}\` → membre qui rejoint/quitte\n• \`{serveur}\` → nom du serveur\n• \`{inviteur}\` → personne qui l’a invité\n• \`{invitations}\` → nombre d’utilisations du lien détecté\n• \`{membres}\` → nombre actuel de membres\n\nLes messages seront envoyés automatiquement après les redémarrages du bot.`,
                    allowedMentions: { parse: [] }
                });
            } catch (error) {
                console.error("❌ /invitelogger :", error);
                return interaction.editReply({ content: `❌ Impossible de configurer InviteLogger : ${error?.message || error}` });
            }
        }

        if (interaction.commandName === "invites") {
            const action = interaction.options.getString("action", true);
            const isAdmin = interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);

            // La consultation reste publique ; la configuration est réservée aux admins.
            if (action !== "view" && !isAdmin) {
                return interaction.reply({
                    content: "❌ Seule l’action `Voir` est accessible à tous. La configuration de `/invites` est réservée aux administrateurs.",
                    ephemeral: true
                });
            }

            if (action === "view") {
                await interaction.deferReply();
                try {
                    const member = interaction.options.getMember("membre") || interaction.member;
                    if (!member?.id) return interaction.editReply("❌ Impossible de trouver ce membre sur le serveur.");

                    const stats = await inviteStatsManager.getDetailedStats(interaction.guild, member.id);
                    const embed = new EmbedBuilder()
                        .setColor(0x5865f2)
                        .setTitle(`📨 Invitations de ${member.user?.username || member.displayName || "ce membre"}`)
                        .setThumbnail(member.displayAvatarURL?.({ size: 256 }) || null)
                        .setDescription(
                            `✅ **${stats.total}** arrivée(s)\n` +
                            `❌ **${stats.leaves}** départ(s)\n` +
                            `✨ **${stats.real}** invitation(s) active(s)`
                        )
                        .setFooter({ text: interaction.guild.name })
                        .setTimestamp();
                    return interaction.editReply({ embeds: [embed], allowedMentions: { parse: [] } });
                } catch (error) {
                    console.error("❌ /invites view :", error);
                    return interaction.editReply("❌ Impossible de lire les invitations. Vérifie que le bot possède la permission **Gérer le serveur**.");
                }
            }

            const current = inviteStatsManager.getSettings(interaction.guild.id);

            if (action === "status") {
                if (!current) {
                    return interaction.reply({ content: "ℹ️ Le système `/invites` n’est pas encore configuré.", ephemeral: true });
                }
                return interaction.reply({
                    content: `📨 **Invitations**\nÉtat : ${current.enabled ? "✅ Activé" : "⛔ Désactivé"}\nSalon : <#${current.channel_id}>\nImage : ${current.image_path ? "✅ configurée" : "Aucune"}`,
                    ephemeral: true,
                    allowedMentions: { parse: [] }
                });
            }

            if (action === "enable" || action === "disable") {
                if (!current) {
                    return interaction.reply({ content: "❌ Configure d’abord `/invites action:Configurer / modifier`.", ephemeral: true });
                }
                inviteStatsManager.setEnabled(interaction.guild.id, action === "enable");
                if (action === "enable") await inviteStatsManager.refreshInvites(interaction.guild).catch(() => {});
                return interaction.reply({
                    content: action === "enable" ? "✅ Système d’invitations activé." : "⛔ Système d’invitations désactivé.",
                    ephemeral: true
                });
            }

            if (action === "configure") {
                const channel = interaction.options.getChannel("salon") ||
                    (current?.channel_id ? interaction.guild.channels.cache.get(current.channel_id) : null);
                if (!channel?.isTextBased?.()) {
                    return interaction.reply({ content: "❌ Choisis le `salon` où publier les résultats de `/invites`.", ephemeral: true });
                }
                const image = interaction.options.getAttachment("image");
                if (image && !isImageAttachment(image)) {
                    return interaction.reply({ content: "❌ `image` doit être une image PNG, JPG, GIF ou WEBP.", ephemeral: true });
                }

                await interaction.deferReply({ ephemeral: true });
                try {
                    await inviteStatsManager.configure(interaction.guild, {
                        channelId: channel.id,
                        image,
                        title: interaction.options.getString("titre")?.trim() || null,
                        description: interaction.options.getString("description")?.trim() || null
                    });
                    return interaction.editReply(
                        `✅ **/invites configuré et activé** dans <#${channel.id}>.\n` +
                        "La commande `Voir` répond maintenant directement dans le salon où elle est utilisée."
                    );
                } catch (error) {
                    console.error("❌ /invites configure :", error);
                    return interaction.editReply(`❌ Impossible de configurer /invites : ${error?.message || error}`);
                }
            }
        }

        if (interaction.commandName === "setupticket") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: "❌ La commande `/setupticket` est réservée aux administrateurs.", ephemeral: true });
            }

            const action = interaction.options.getString("action", true);
            const panelName = interaction.options.getString("panneau")?.trim();

            if (action === "list") {
                const panels = ticketManager.listPanels(interaction.guild.id);
                if (!panels.length) return interaction.reply({ content: "📭 Aucun panneau de tickets configuré.", ephemeral: true });
                return interaction.reply({
                    content: panels.map(p => `• **${p.panel_name}** — ${p.enabled ? "✅ Activé" : "⛔ Désactivé"} — <#${p.channel_id}> — ${ticketManager.getOptions(p.id).length} demande(s)`).join("\n"),
                    ephemeral: true,
                    allowedMentions: { parse: [] }
                });
            }

            if (!panelName) return interaction.reply({ content: "❌ Indique le champ `panneau` (ex : `support` ou `agence`).", ephemeral: true });
            const panel = ticketManager.getPanel(interaction.guild.id, panelName);

            if (action === "configure") {
                const channel = interaction.options.getChannel("salon");
                if (!channel?.isTextBased?.()) return interaction.reply({ content: "❌ Choisis le `salon` où publier le panneau.", ephemeral: true });
                const category = interaction.options.getChannel("categorie");
                const transcriptChannel = interaction.options.getChannel("salon_transcript");
                const title = interaction.options.getString("titre")?.trim() || "🎫 Support";
                const description = interaction.options.getString("description")?.trim() || "Sélectionnez une catégorie pour ouvrir un ticket.";
                const color = (interaction.options.getString("couleur")?.trim() || "5865F2").replace(/^#/, "");
                const image = interaction.options.getAttachment("image");
                if (!/^[0-9a-f]{6}$/i.test(color)) return interaction.reply({ content: "❌ `couleur` doit être une couleur HEX sur 6 caractères, ex : `5865F2`.", ephemeral: true });
                if (image && !isImageAttachment(image)) return interaction.reply({ content: "❌ `image` doit être une image PNG, JPG, GIF ou WEBP.", ephemeral: true });
                await interaction.deferReply({ ephemeral: true });
                try {
                    const saved = await ticketManager.configurePanel(interaction.guild, { panelName, channelId: channel.id, categoryId: category?.id || null, transcriptChannelId: transcriptChannel?.id || null, title, description, color, image });
                    return interaction.editReply(`✅ Panneau **${saved.panel_name}** configuré dans <#${channel.id}>.${saved.transcript_channel_id ? `\n📄 Transcripts : <#${saved.transcript_channel_id}>` : "\n⚠️ Aucun salon de transcripts configuré."}\nAjoute maintenant des demandes avec \`/setupticket action:Ajouter une demande\`, puis publie avec \`Publier / actualiser\`.`);
                } catch (error) {
                    return interaction.editReply(`❌ Impossible de configurer le panneau : ${error?.message || error}`);
                }
            }

            if (!panel) return interaction.reply({ content: `❌ Le panneau **${panelName}** n’existe pas encore. Configure-le d’abord.`, ephemeral: true });

            if (action === "add_option") {
                const label = interaction.options.getString("demande")?.trim();
                if (!label) return interaction.reply({ content: "❌ Indique `demande` avec le nom à afficher dans le menu.", ephemeral: true });
                const desc = interaction.options.getString("description_demande")?.trim() || null;
                const emoji = interaction.options.getString("emoji")?.trim() || null;
                const supportRole = interaction.options.getRole("role_support");
                if (supportRole?.id === interaction.guild.id) return interaction.reply({ content: "❌ `@everyone` ne peut pas être utilisé comme rôle support.", ephemeral: true });
                try {
                    ticketManager.addOption(panel.id, { label, description: desc, emoji, supportRoleId: supportRole?.id || null });
                    if (panel.message_id) await ticketManager.publishPanel(interaction.guild, ticketManager.getPanelById(panel.id)).catch(() => {});
                    return interaction.reply({ content: `✅ Demande **${label}** ajoutée au panneau **${panel.panel_name}**.${supportRole ? `\nRôle support : <@&${supportRole.id}>` : ""}`, ephemeral: true, allowedMentions: { parse: [] } });
                } catch (error) {
                    return interaction.reply({ content: `❌ ${error?.message || error}`, ephemeral: true });
                }
            }

            if (action === "remove_option") {
                const label = interaction.options.getString("demande")?.trim();
                if (!label) return interaction.reply({ content: "❌ Indique `demande` avec le nom à retirer.", ephemeral: true });
                const removed = ticketManager.removeOption(panel.id, label);
                if (!removed) return interaction.reply({ content: `❌ La demande **${label}** n’existe pas dans ce panneau.`, ephemeral: true });
                if (panel.message_id && ticketManager.getOptions(panel.id).length) await ticketManager.publishPanel(interaction.guild, ticketManager.getPanelById(panel.id)).catch(() => {});
                return interaction.reply({ content: `🗑️ Demande **${label}** retirée du panneau **${panel.panel_name}**.`, ephemeral: true });
            }

            if (action === "publish") {
                await interaction.deferReply({ ephemeral: true });
                try {
                    const message = await ticketManager.publishPanel(interaction.guild, ticketManager.getPanelById(panel.id));
                    return interaction.editReply(`✅ Panneau **${panel.panel_name}** publié / actualisé.\n🔗 https://discord.com/channels/${interaction.guild.id}/${panel.channel_id}/${message.id}`);
                } catch (error) {
                    return interaction.editReply(`❌ Impossible de publier : ${error?.message || error}`);
                }
            }

            if (action === "enable" || action === "disable") {
                ticketManager.setEnabled(panel.id, action === "enable");
                const updated = ticketManager.getPanelById(panel.id);
                if (updated.message_id && ticketManager.getOptions(updated.id).length) await ticketManager.publishPanel(interaction.guild, updated).catch(() => {});
                return interaction.reply({ content: `${action === "enable" ? "✅" : "⛔"} Panneau **${panel.panel_name}** ${action === "enable" ? "activé" : "désactivé"}.`, ephemeral: true });
            }

            if (action === "delete") {
                ticketManager.deletePanel(panel.id);
                return interaction.reply({ content: `🗑️ Panneau **${panel.panel_name}** supprimé de la configuration. Le message déjà publié n’est pas supprimé automatiquement.`, ephemeral: true });
            }
        }

        if (interaction.commandName === "setup-boost") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: "❌ La commande `/setup-boost` est réservée aux administrateurs.", ephemeral: true });
            }
            const action = interaction.options.getString("action", true);
            const current = boostManager.getSettings(interaction.guild.id);
            const help = "`{membre}` → mention du booster • `{serveur}` → nom du serveur • `{boosts}` → nombre total de boosts • `{niveau}` → niveau de boost";
            if (action === "status") {
                return interaction.reply({ content: current ? `💜 **Setup Boost**\nÉtat : ${current.enabled ? "✅ Activé" : "⛔ Désactivé"}\nSalon : <#${current.channel_id}>\nImage : ${current.image_path ? "✅ configurée" : "Aucune"}\n\n**Variables disponibles :**\n${help}` : `ℹ️ Le système de boost n’est pas encore configuré.\n\n**Variables disponibles :**\n${help}`, ephemeral: true, allowedMentions: { parse: [] } });
            }
            if (action === "enable" || action === "disable") {
                if (!current) return interaction.reply({ content: "❌ Configure d’abord `/setup-boost action:Configurer / modifier`.", ephemeral: true });
                boostManager.setEnabled(interaction.guild.id, action === "enable");
                return interaction.reply({ content: `${action === "enable" ? "✅ Notifications de boost activées." : "⛔ Notifications de boost désactivées."}\n\n**Variables disponibles :**\n${help}`, ephemeral: true });
            }
            const channel = interaction.options.getChannel("salon");
            if (!channel?.isTextBased?.()) return interaction.reply({ content: `❌ Choisis le \`salon\` où envoyer les remerciements.\n\n**Variables disponibles :**\n${help}`, ephemeral: true });
            const title = interaction.options.getString("titre")?.trim() || "💜 Merci pour le boost, {membre} !";
            const description = interaction.options.getString("description")?.trim() || "Merci d’avoir boosté **{serveur}** ! Nous avons maintenant **{boosts}** boost(s) et le serveur est niveau **{niveau}**.";
            const color = (interaction.options.getString("couleur")?.trim() || "F47FFF").replace(/^#/, "");
            const image = interaction.options.getAttachment("image");
            if (!/^[0-9a-f]{6}$/i.test(color)) return interaction.reply({ content: "❌ `couleur` doit être une couleur HEX sur 6 caractères, ex : `F47FFF`.", ephemeral: true });
            if (image && !isImageAttachment(image)) return interaction.reply({ content: "❌ `image` doit être une image PNG, JPG, GIF ou WEBP.", ephemeral: true });
            await interaction.deferReply({ ephemeral: true });
            try {
                await boostManager.configure(interaction.guild, { channelId: channel.id, title, description, color, image });
                return interaction.editReply({ content: `✅ **Notifications de boost activées** dans <#${channel.id}>.\nL’image et les textes sont enregistrés et resteront actifs après redémarrage.\n\n**Variables disponibles dans le titre et la description :**\n${help}`, allowedMentions: { parse: [] } });
            } catch (error) {
                return interaction.editReply({ content: `❌ Impossible de configurer les boosts : ${error?.message || error}` });
            }
        }

        if (interaction.commandName === "effectif") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) return interaction.reply({ content: "❌ `/effectif` est réservé aux administrateurs.", ephemeral: true });
            const action=interaction.options.getString("action",true); const st=effectifManager.getSettings(interaction.guild.id);
            if(action==="status"){const roles=effectifManager.getRoles(interaction.guild.id);return interaction.reply({content:st?`👥 **Effectif** — ${st.enabled?"✅ Activé":"⛔ Désactivé"}\nSalon : <#${st.channel_id}>\nRôles suivis : ${roles.length}\nImage : ${st.image_path?"✅":"Aucune"}`:"ℹ️ `/effectif` n’est pas encore configuré.",ephemeral:true,allowedMentions:{parse:[]}});}
            if(action==="disable"){if(!st)return interaction.reply({content:"ℹ️ Aucun effectif configuré.",ephemeral:true});effectifManager.setEnabled(interaction.guild.id,false);return interaction.reply({content:"⛔ Effectif automatique désactivé.",ephemeral:true});}
            if(action==="refresh"){if(!st)return interaction.reply({content:"❌ Configure d’abord `/effectif`.",ephemeral:true});await interaction.deferReply({ephemeral:true});await effectifManager.refresh(interaction.guild,true);return interaction.editReply("🔄 Effectif actualisé.");}
            if(action==="add_role"||action==="remove_role"){if(!st)return interaction.reply({content:"❌ Configure d’abord le salon avec `/effectif action:Configurer / modifier`.",ephemeral:true});const role=interaction.options.getRole("role");if(!role)return interaction.reply({content:"❌ Sélectionne le `role` concerné.",ephemeral:true});if(role.id===interaction.guild.id)return interaction.reply({content:"❌ Le rôle @everyone ne peut pas être ajouté.",ephemeral:true});if(action==="add_role")effectifManager.addRole(interaction.guild.id,role.id);else effectifManager.removeRole(interaction.guild.id,role.id);await effectifManager.refresh(interaction.guild,true);return interaction.reply({content:`${action==="add_role"?"✅ Rôle ajouté":"🗑️ Rôle retiré"} : <@&${role.id}>. L’effectif a été mis à jour.`,ephemeral:true,allowedMentions:{parse:[]}});}
            const channel=interaction.options.getChannel("salon");if(!channel?.isTextBased?.())return interaction.reply({content:"❌ Choisis le `salon` où afficher l’effectif.",ephemeral:true});
            const title=interaction.options.getString("titre")?.trim()||"👥 Équipe du Serveur";const description=interaction.options.getString("description")?.trim()||"Voici l’équipe qui fait vivre **{serveur}** !";const color=(interaction.options.getString("couleur")?.trim()||"5865F2").replace(/^#/,"");const image=interaction.options.getAttachment("image");if(!/^[0-9a-f]{6}$/i.test(color))return interaction.reply({content:"❌ Couleur HEX invalide.",ephemeral:true});if(image&&!isImageAttachment(image))return interaction.reply({content:"❌ L’image doit être PNG, JPG, GIF ou WEBP.",ephemeral:true});await interaction.deferReply({ephemeral:true});try{await effectifManager.configure(interaction.guild,{channelId:channel.id,title,description,color,image});return interaction.editReply(`✅ **Effectif automatique activé** dans <#${channel.id}>.\nAjoute ensuite tes rôles avec \`/effectif action:Ajouter un rôle role:@Rôle\`.\nLe même message sera actualisé automatiquement dès qu’un membre reçoit ou perd un rôle suivi.`);}catch(e){return interaction.editReply(`❌ Impossible de configurer l’effectif : ${e?.message||e}`);}
        }

        if (interaction.commandName === "config-counter") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) return interaction.reply({ content: "❌ `/config-counter` est réservé aux administrateurs.", ephemeral: true });
            const action = interaction.options.getString("action", true);
            const st = counterManager.getSettings(interaction.guild.id);
            const help = "Utilise `{valeur}` dans un nom personnalisé : le bot le remplace automatiquement par le compteur ou la date/heure.";
            if (action === "status") return interaction.reply({ content: st ? `📊 **Compteurs serveur** — ${st.enabled ? "✅ Activés" : "⛔ Désactivés"}\nCatégorie : <#${st.category_id}>\nTous les membres : ${st.total_enabled ? "✅" : "❌"} • Membres : ${st.members_enabled ? "✅" : "❌"} • Bots : ${st.bots_enabled ? "✅" : "❌"}\nEn ligne : ${st.online_enabled ? "✅" : "❌"} • Hors ligne : ${st.offline_enabled ? "✅" : "❌"} • Date/heure FR : ${st.datetime_enabled ? "✅" : "❌"}\n\n${help}` : `ℹ️ Les compteurs ne sont pas encore configurés.\n\n${help}`, ephemeral: true, allowedMentions: { parse: [] } });
            if (action === "disable") { if (!st) return interaction.reply({ content: "ℹ️ Aucun compteur configuré.", ephemeral: true }); counterManager.setEnabled(interaction.guild.id, false); return interaction.reply({ content: "⛔ Actualisation automatique des compteurs désactivée. Les salons existants restent en place.", ephemeral: true }); }
            if (action === "refresh") { if (!st) return interaction.reply({ content: "❌ Configure d’abord `/config-counter`.", ephemeral: true }); await interaction.deferReply({ ephemeral: true }); await counterManager.refresh(interaction.guild, true); return interaction.editReply("🔄 Compteurs actualisés."); }
            const category = interaction.options.getChannel("categorie");
            await interaction.deferReply({ ephemeral: true });
            try {
                const result = await counterManager.configure(interaction.guild, {
                    categoryId: category?.id || st?.category_id || null,
                    total: interaction.options.getBoolean("tous_membres"), members: interaction.options.getBoolean("membres"), bots: interaction.options.getBoolean("bots"),
                    online: interaction.options.getBoolean("en_ligne"), offline: interaction.options.getBoolean("hors_ligne"), datetime: interaction.options.getBoolean("date_heure"),
                    totalName: interaction.options.getString("nom_total")?.trim(), membersName: interaction.options.getString("nom_membres")?.trim(),
                    botsName: interaction.options.getString("nom_bots")?.trim(), onlineName: interaction.options.getString("nom_en_ligne")?.trim(),
                    offlineName: interaction.options.getString("nom_hors_ligne")?.trim(), datetimeName: interaction.options.getString("nom_date_heure")?.trim()
                });
                return interaction.editReply(`✅ **Compteurs serveur activés** dans <#${result.category_id}>.\nIls suivent automatiquement les arrivées/départs et changements de présence. La date et l’heure utilisent **Europe/Paris**.\n\n${help}`);
            } catch (e) { return interaction.editReply(`❌ Impossible de configurer les compteurs : ${e?.message || e}`); }
        }

        if (interaction.commandName === "stats-invite") {
            await interaction.deferReply();
            try {
                const selected = interaction.options.getMember("membre");
                if (selected) {
                    const stats = await inviteStatsManager.getDetailedStats(interaction.guild, selected.id);
                    const board = await inviteStatsManager.getLeaderboard(interaction.guild, 100);
                    const position = board.findIndex(row => row.userId === selected.id);
                    const embed = new EmbedBuilder()
                        .setColor(0x5865f2)
                        .setTitle(`📊 Statistiques d’invitations — ${selected.user.username}`)
                        .setThumbnail(selected.displayAvatarURL({ size: 256 }))
                        .setDescription(
                            `🏆 **Classement :** ${position >= 0 ? `#${position + 1}` : "Non classé"}\n` +
                            `✅ **Invitations réelles :** ${stats.real}\n` +
                            `🔗 **Invitations totales :** ${stats.total}\n` +
                            `❌ **Départs :** ${stats.leaves}`
                        )
                        .setFooter({ text: interaction.guild.name })
                        .setTimestamp();
                    return interaction.editReply({ embeds: [embed], allowedMentions: { parse: [] } });
                }

                const board = await inviteStatsManager.getLeaderboard(interaction.guild, 10);
                if (!board.length) return interaction.editReply("ℹ️ Aucune statistique d’invitation n’est encore disponible.");
                const lines = board.map((row, i) =>
                    `**${i + 1}.** <@${row.userId}> → ✅ **${row.real}**  🔗 **${row.total}**  ❌ **${row.leaves}**`
                );
                const embed = new EmbedBuilder()
                    .setColor(0x5865f2)
                    .setTitle("🏆 Classement des invitations")
                    .setDescription(
                        "✅ Invitations réelles • 🔗 Invitations totales • ❌ Départs\n\n" + lines.join("\n")
                    )
                    .setFooter({ text: `Top ${board.length} • ${interaction.guild.name}` })
                    .setTimestamp();
                return interaction.editReply({ embeds: [embed], allowedMentions: { parse: [] } });
            } catch (error) {
                console.error("❌ /stats-invite :", error);
                return interaction.editReply("❌ Impossible de générer les statistiques. Vérifie notamment que le bot possède **Gérer le serveur** pour lire les invitations.");
            }
        }

        if (interaction.commandName === "anti-piratage") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: "❌ La commande `/anti-piratage` est réservée aux administrateurs.", ephemeral: true });
            }

            const action = interaction.options.getString("action", true);

            if (action === "status") {
                const settings = antiPiracyManager.get(interaction.guild.id);
                if (!settings) return interaction.reply({ content: "ℹ️ Anti-piratage n'est pas encore configuré sur ce serveur.", ephemeral: true });
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(settings.enabled ? 0x22c55e : 0x6b7280)
                        .setTitle("🚨 Anti-piratage — Statut")
                        .setDescription(
                            `**État :** ${settings.enabled ? "✅ Activé" : "❌ Désactivé"}\n` +
                            `**Salon :** <#${settings.channelId}>\n` +
                            `**Sanction :** ${antiPiracyManager.actionLabel(settings.action)}\n` +
                            `**Raison :** ${settings.reason || "Non définie"}`
                        )],
                    ephemeral: true, allowedMentions: { parse: [] }
                });
            }

            if (action === "disable") {
                const existing = antiPiracyManager.get(interaction.guild.id);
                if (!existing) return interaction.reply({ content: "ℹ️ Anti-piratage n'est pas configuré.", ephemeral: true });
                antiPiracyManager.disable(interaction.guild.id);
                return interaction.reply({ content: "✅ Anti-piratage désactivé. Le salon ne sanctionnera plus automatiquement les messages.", ephemeral: true });
            }

            const channel = interaction.options.getChannel("salon");
            const sanction = interaction.options.getString("sanction");
            if (!channel || !sanction) {
                return interaction.reply({ content: "❌ Pour **Configurer / modifier**, indique au minimum `salon` et `sanction`.", ephemeral: true });
            }
            if (!channel.isTextBased?.()) {
                return interaction.reply({ content: "❌ Choisis un salon texte valide.", ephemeral: true });
            }

            const reason = interaction.options.getString("raison")?.trim() || "Message envoyé dans le salon anti-piratage";
            const title = interaction.options.getString("titre")?.trim() || null;
            const description = interaction.options.getString("texte")?.trim() || null;
            const color = interaction.options.getString("couleur")?.trim() || "EF4444";
            if (!/^[#]?[0-9A-Fa-f]{6}$/.test(color)) {
                return interaction.reply({ content: "❌ La couleur doit être au format HEX, par exemple `EF4444`.", ephemeral: true });
            }

            await interaction.deferReply({ ephemeral: true });
            try {
                const settings = await antiPiracyManager.configure(interaction.guild, { channel, action: sanction, reason, title, description, color });
                return interaction.editReply({
                    content:
                        `✅ **Anti-piratage activé automatiquement.**\n` +
                        `📍 Salon : <#${settings.channelId}>\n` +
                        `⚖️ Sanction : **${antiPiracyManager.actionLabel(settings.action)}**\n` +
                        `🛡️ Les administrateurs, le propriétaire du serveur et les bots sont protégés.\n` +
                        `💾 La configuration est enregistrée et reste active après redémarrage.`,
                    allowedMentions: { parse: [] }
                });
            } catch (error) {
                console.error("❌ /anti-piratage :", error);
                return interaction.editReply("❌ Impossible de configurer le salon. Vérifie que le bot peut **voir le salon, envoyer des messages, intégrer des liens et épingler des messages**.");
            }
        }

        if (interaction.commandName === "security") {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({
                    content: "❌ La commande `/security` est réservée aux administrateurs.",
                    ephemeral: true
                });
            }

            const action = interaction.options.getString("action", true);
            const threshold = interaction.options.getInteger("seuil");
            const windowSeconds = interaction.options.getInteger("fenetre");

            if (action === "status") {
                const settings = securityManager.get(interaction.guild.id);
                const lockedAt = settings.lockedAt
                    ? `<t:${Math.floor(settings.lockedAt / 1000)}:R>`
                    : "Non";

                return interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(settings.locked ? 0xef4444 : 0x8b5cf6)
                            .setTitle("🛡️ Sécurité Nexora")
                            .setDescription(
                                `**Anti-raid :** ${settings.antiRaidEnabled ? "✅ Activé" : "❌ Désactivé"}\n` +
                                `**Détection :** ${settings.joinThreshold} arrivées / ${settings.windowSeconds}s\n` +
                                `**Lockdown :** ${settings.locked ? "🔒 Actif" : "🔓 Inactif"}\n` +
                                `**Verrouillé depuis :** ${lockedAt}`
                            )
                    ],
                    ephemeral: true
                });
            }

            if (action === "antiraid_on") {
                const settings = securityManager.setAntiRaid(
                    interaction.guild.id,
                    true,
                    { threshold, windowSeconds }
                );
                return interaction.reply({
                    content:
                        `✅ Anti-raid activé : **${settings.joinThreshold} arrivées en ${settings.windowSeconds}s** déclencheront un lockdown automatique.`,
                    ephemeral: true
                });
            }

            if (action === "antiraid_off") {
                securityManager.setAntiRaid(interaction.guild.id, false);
                return interaction.reply({
                    content: "✅ Anti-raid désactivé. Un lockdown déjà actif n’est pas retiré automatiquement.",
                    ephemeral: true
                });
            }

            if (action === "lockdown") {
                await interaction.deferReply({ ephemeral: true });
                try {
                    const result = await securityManager.lockGuild(
                        interaction.guild,
                        `Lockdown manuel demandé par ${interaction.user.tag}`
                    );
                    if (result.alreadyLocked) {
                        return interaction.editReply("ℹ️ Le serveur est déjà en lockdown.");
                    }
                    return interaction.editReply(
                        `🔒 Lockdown activé : **${result.changed}** salon(s) verrouillé(s)` +
                        (result.failed ? ` • ⚠️ **${result.failed}** échec(s)` : "")
                    );
                } catch (error) {
                    if (error?.message === "MISSING_MANAGE_CHANNELS") {
                        return interaction.editReply("❌ Le bot a besoin de la permission **Gérer les salons** pour le lockdown.");
                    }
                    throw error;
                }
            }

            if (action === "unlock") {
                await interaction.deferReply({ ephemeral: true });
                try {
                    const result = await securityManager.unlockGuild(
                        interaction.guild,
                        `Fin du lockdown demandée par ${interaction.user.tag}`
                    );
                    if (result.alreadyUnlocked) {
                        return interaction.editReply("ℹ️ Aucun lockdown n’est actuellement actif.");
                    }
                    return interaction.editReply(
                        `🔓 Lockdown retiré : permissions restaurées sur **${result.changed}** salon(s)` +
                        (result.failed ? ` • ⚠️ **${result.failed}** échec(s)` : "")
                    );
                } catch (error) {
                    if (error?.message === "MISSING_MANAGE_CHANNELS") {
                        return interaction.editReply("❌ Le bot a besoin de la permission **Gérer les salons** pour restaurer les permissions.");
                    }
                    throw error;
                }
            }
        }

        if (interaction.commandName === "testtiktok") {
            const username = cleanUsername(
                interaction.options.getString("pseudo", true)
            );

            if (!isValidUsername(username)) {
                return interaction.reply({
                    content: "❌ Pseudonyme TikTok invalide.",
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });

            const live = await liveManager.getLiveState(username);

            if (live === true) {
                return interaction.editReply(
                    `🔴 **@${username} est actuellement en LIVE !**`
                );
            }

            if (live === false) {
                return interaction.editReply(
                    `⚫ **@${username} est actuellement HORS LIVE.**`
                );
            }

            return interaction.editReply(
                `🟠 **Impossible de confirmer l'état de @${username}.**\n` +
                `TikTok n'a pas renvoyé un statut suffisamment fiable. Le bot conserve l'ancien état pour éviter les fausses notifications.`
            );
        }

        if (interaction.commandName === "testnotification") {
            const settings = ConfigManager.get(interaction.guild.id);

            if (!settings.notifyChannelId) {
                return interaction.reply({
                    content:
                        "❌ Configure d'abord le salon avec `/setuptiktok`.",
                    ephemeral: true
                });
            }

            const username =
                cleanUsername(
                    interaction.options.getString("pseudo")
                ) || "compte_test";

            await liveManager.sendNotification(
                interaction.guild.id,
                username
            );

            return interaction.reply({
                content:
                    `✅ Notification envoyée dans <#${settings.notifyChannelId}>.`,
                ephemeral: true
            });
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith("regle:verify:")) {
        const roleId = interaction.customId.split(":")[2];
        const role = interaction.guild.roles.cache.get(roleId);
        if (!role) {
            return interaction.reply({ content: "❌ Le rôle de vérification n’existe plus.", ephemeral: true });
        }

        const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
        if (!member) return interaction.reply({ content: "❌ Impossible de retrouver ton profil sur le serveur.", ephemeral: true });

        if (member.roles.cache.has(role.id)) {
            return interaction.reply({ content: "✅ Tu es déjà vérifié.", ephemeral: true });
        }

        const me = interaction.guild.members.me;
        if (!me?.permissions.has(PermissionFlagsBits.ManageRoles) || me.roles.highest.comparePositionTo(role) <= 0) {
            return interaction.reply({ content: "❌ Je ne peux pas attribuer ce rôle. Un administrateur doit vérifier la hiérarchie des rôles.", ephemeral: true });
        }

        try {
            await member.roles.add(role, `Vérification via bouton /règle par ${interaction.user.tag}`);
            return interaction.reply({ content: `✅ Tu es maintenant vérifié et tu as reçu le rôle **${role.name}**.`, ephemeral: true });
        } catch (error) {
            console.error("❌ Erreur bouton /règle :", error);
            return interaction.reply({ content: "❌ Impossible de t’attribuer le rôle pour le moment.", ephemeral: true });
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith("say:")) {
        const [, action, token] = interaction.customId.split(":");
        const pending = pendingSay.get(token);

        if (!pending || pending.guildId !== interaction.guild.id) {
            return interaction.reply({
                content: "❌ Cette confirmation `/say` a expiré. Relance la commande.",
                ephemeral: true
            });
        }

        if (pending.userId !== interaction.user.id) {
            return interaction.reply({
                content: "❌ Seule la personne qui a lancé `/say` peut confirmer cet envoi.",
                ephemeral: true
            });
        }

        if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: "❌ La commande `/say` est réservée aux administrateurs.",
                ephemeral: true
            });
        }

        if (action === "cancel") {
            pendingSay.delete(token);
            return interaction.update({
                content: "✅ Envoi `/say` annulé.",
                embeds: [],
                components: []
            });
        }

        if (action !== "confirm") return;

        const channel = interaction.guild.channels.cache.get(pending.channelId);
        if (!channel?.isTextBased?.()) {
            pendingSay.delete(token);
            return interaction.update({
                content: "❌ Le salon sélectionné n’existe plus ou n’est plus accessible.",
                embeds: [],
                components: []
            });
        }

        await interaction.update({
            content: "⏳ Envoi du message…",
            embeds: [],
            components: []
        });

        try {
            const payload = {
                content: pending.message,
                allowedMentions: { parse: ["users", "roles"], repliedUser: false }
            };

            if (pending.attachments.length) {
                payload.files = pending.attachments.map(file => ({
                    attachment: file.url,
                    name: file.name
                }));
            }

            const sent = await channel.send(payload);
            pendingSay.delete(token);

            return interaction.editReply({
                content: `✅ Message envoyé par le bot dans <#${channel.id}>.\n🔗 Message : https://discord.com/channels/${interaction.guild.id}/${channel.id}/${sent.id}`,
                embeds: [],
                components: [],
                allowedMentions: { parse: [] }
            });
        } catch (error) {
            console.error("❌ /say :", error);
            pendingSay.delete(token);
            return interaction.editReply({
                content: "❌ Impossible d’envoyer le message. Vérifie que le bot peut **voir le salon, envoyer des messages et joindre des fichiers**.",
                embeds: [],
                components: []
            });
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith("dmall:")) {
        const [, action, token] = interaction.customId.split(":");
        const pending = pendingDmall.get(token);

        if (!pending || pending.guildId !== interaction.guild.id) {
            return interaction.reply({
                content: "❌ Cette confirmation DMALL a expiré. Relance `/dmall`.",
                ephemeral: true
            });
        }

        if (pending.userId !== interaction.user.id) {
            return interaction.reply({
                content: "❌ Seule la personne qui a lancé `/dmall` peut confirmer cet envoi.",
                ephemeral: true
            });
        }

        if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: "❌ La commande `/dmall` est réservée aux administrateurs.",
                ephemeral: true
            });
        }

        if (action === "cancel") {
            pendingDmall.delete(token);
            return interaction.update({
                content: "✅ Envoi DMALL annulé.",
                embeds: [],
                components: []
            });
        }

        if (action !== "confirm") return;

        pendingDmall.delete(token);
        await interaction.update({
            content: "⏳ Envoi des messages privés en cours…",
            embeds: [],
            components: []
        });

        let members;
        try {
            members = await interaction.guild.members.fetch();
        } catch (error) {
            console.error("❌ Impossible de charger les membres pour /dmall :", error);
            return interaction.editReply({
                content:
                    "❌ Impossible de récupérer les membres du serveur. Active **Server Members Intent** dans le Discord Developer Portal, puis redémarre le bot.",
                embeds: [],
                components: []
            });
        }

        const targetRole = interaction.guild.roles.cache.get(pending.roleId);
        if (!targetRole) {
            return interaction.editReply({
                content: "❌ Le rôle sélectionné n’existe plus. Relance `/dmall` avec un autre rôle.",
                embeds: [],
                components: []
            });
        }

        const recipients = [...members.values()].filter(
            member =>
                !member.user.bot &&
                member.id !== interaction.client.user.id &&
                member.roles.cache.has(pending.roleId)
        );

        if (recipients.length === 0) {
            return interaction.editReply({
                content: `ℹ️ Aucun membre humain ne possède le rôle <@&${pending.roleId}>. Aucun DM n’a été envoyé.`,
                embeds: [],
                components: [],
                allowedMentions: { parse: [] }
            });
        }

        let sent = 0;
        let failed = 0;

        for (let i = 0; i < recipients.length; i++) {
            const member = recipients[i];
            const dmEmbed = new EmbedBuilder()
                .setColor(0x8b5cf6)
                .setDescription(pending.text)
                .setFooter({
                    text: `Message de ${interaction.guild.name}`
                });

            const guildIcon = interaction.guild.iconURL({ size: 128 });
            if (guildIcon) {
                dmEmbed.setAuthor({
                    name: interaction.guild.name,
                    iconURL: guildIcon
                });
            }

            if (pending.imageUrl) dmEmbed.setImage(pending.imageUrl);

            try {
                await member.send({
                    embeds: [dmEmbed],
                    allowedMentions: { parse: [] }
                });
                sent++;
            } catch (error) {
                failed++;
                console.warn(`⚠️ DM impossible pour ${member.user.tag}: ${error?.message || error}`);
            }

            // Petit délai volontaire pour éviter une rafale de requêtes.
            await new Promise(resolve => setTimeout(resolve, 500));

            if ((i + 1) % 25 === 0 || i === recipients.length - 1) {
                try {
                    await interaction.editReply({
                        content:
                            `⏳ DMALL en cours : **${i + 1}/${recipients.length}** membres traités\n` +
                            `✅ Envoyés : **${sent}** • ❌ Échecs : **${failed}**`,
                        embeds: [],
                        components: []
                    });
                } catch {
                    // L'envoi continue même si l'aperçu de progression ne peut plus être modifié.
                }
            }
        }

        return interaction.editReply({
            content:
                `📨 **DMALL terminé**\n` +
                `✅ Envoyés : **${sent}**\n` +
                `❌ Non envoyés : **${failed}**\n` +
                `🎯 Rôle ciblé : **${pending.roleName}**\n` +
                `👥 Membres traités : **${recipients.length}**`,
            embeds: [],
            components: [],
            allowedMentions: { parse: [] }
        });
    }

    if (
        interaction.isStringSelectMenu() &&
        interaction.customId.startsWith("rolereact:menu:")
    ) {
        const roleId = interaction.values[0];
        const role = interaction.guild.roles.cache.get(roleId);
        let member;
        try {
            member = await interaction.guild.members.fetch(interaction.user.id);
        } catch {
            return interaction.reply({
                content: "❌ Impossible de récupérer ton profil sur le serveur.",
                ephemeral: true
            });
        }

        if (!role) {
            return interaction.reply({ content: "❌ Ce rôle n’existe plus.", ephemeral: true });
        }
        if (role.managed || !role.editable) {
            return interaction.reply({
                content: "❌ Je ne peux plus gérer ce rôle. Vérifie la hiérarchie des rôles du bot.",
                ephemeral: true
            });
        }

        try {
            if (member.roles.cache.has(roleId)) {
                await member.roles.remove(roleId, "Retrait via menu /rolereact");
                return interaction.reply({
                    content: `➖ Rôle **${role.name}** retiré.`,
                    ephemeral: true
                });
            }

            await member.roles.add(roleId, "Ajout via menu /rolereact");
            return interaction.reply({
                content: `✅ Rôle **${role.name}** ajouté.`,
                ephemeral: true
            });
        } catch (error) {
            console.error("❌ RoleReact :", error);
            return interaction.reply({
                content: "❌ Impossible de modifier ton rôle. Vérifie les permissions et la hiérarchie du bot.",
                ephemeral: true
            });
        }
    }

    if (
        interaction.isButton() &&
        interaction.customId === "tiktok:channel"
    ) {
        const select = new ChannelSelectMenuBuilder()
            .setCustomId("tiktok:channel:select")
            .setPlaceholder("Sélectionne le salon")
            .setChannelTypes(ChannelType.GuildText)
            .setMinValues(1)
            .setMaxValues(1);

        return interaction.reply({
            content: "📢 Choisis le salon de notification :",
            components: [
                new ActionRowBuilder().addComponents(select)
            ],
            ephemeral: true
        });
    }

    if (
        interaction.isChannelSelectMenu() &&
        interaction.customId === "tiktok:channel:select"
    ) {
        const channelId = interaction.values[0];

        ConfigManager.update(interaction.guild.id, {
            notifyChannelId: channelId
        });

        return interaction.update({
            content: `✅ Salon configuré : <#${channelId}>`,
            components: [],
            allowedMentions: { parse: [] }
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId === "tiktok:role"
    ) {
        const select = new RoleSelectMenuBuilder()
            .setCustomId("tiktok:role:select")
            .setPlaceholder("Sélectionne le rôle")
            .setMinValues(1)
            .setMaxValues(1);

        const noRole = new ButtonBuilder()
            .setCustomId("tiktok:role:none")
            .setLabel("Ne ping aucun rôle")
            .setStyle(ButtonStyle.Secondary);

        return interaction.reply({
            content: "🔔 Choisis le rôle à ping :",
            components: [
                new ActionRowBuilder().addComponents(select),
                new ActionRowBuilder().addComponents(noRole)
            ],
            ephemeral: true
        });
    }

    if (
        interaction.isRoleSelectMenu() &&
        interaction.customId === "tiktok:role:select"
    ) {
        const roleId = interaction.values[0];

        ConfigManager.update(interaction.guild.id, {
            pingRoleId: roleId
        });

        return interaction.update({
            content: `✅ Rôle configuré : <@&${roleId}>`,
            components: [],
            allowedMentions: { parse: [] }
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId === "tiktok:role:none"
    ) {
        ConfigManager.update(interaction.guild.id, {
            pingRoleId: null
        });

        return interaction.update({
            content: "✅ Aucun rôle ne sera ping.",
            components: []
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId === "tiktok:add"
    ) {
        const modal = new ModalBuilder()
            .setCustomId("tiktok:add:modal")
            .setTitle("Ajouter des comptes TikTok");

        const input = new TextInputBuilder()
            .setCustomId("usernames")
            .setLabel("Pseudonymes TikTok")
            .setPlaceholder(
                "pseudo1, pseudo2, pseudo3\nou un pseudo par ligne"
            )
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(4000);

        modal.addComponents(
            new ActionRowBuilder().addComponents(input)
        );

        return interaction.showModal(modal);
    }

    if (
        interaction.isModalSubmit() &&
        interaction.customId === "tiktok:add:modal"
    ) {
        const usernames = parseUsernames(
            interaction.fields.getTextInputValue("usernames")
        );

        if (usernames.length === 0) {
            return interaction.reply({
                content: "❌ Aucun pseudonyme valide trouvé.",
                ephemeral: true
            });
        }

        await interaction.deferReply({ ephemeral: true });

        const result = TikTokAccountManager.addMany(
            interaction.guild.id,
            usernames
        );

        // V4 : vérifie immédiatement uniquement les nouveaux comptes.
        // Un compte déjà LIVE déclenche sa notification sans attendre le prochain scan.
        const checks = [];
        for (const username of result.added) {
            try {
                const status = await liveManager.handleNewAccount(
                    interaction.guild.id,
                    username
                );
                checks.push({ username, status });
            } catch (error) {
                console.error(
                    `❌ Vérification immédiate impossible pour @${username}:`,
                    error
                );
                checks.push({ username, status: "unknown" });
            }

            // Petite pause entre les requêtes pour limiter les blocages TikTok.
            await new Promise(resolve => setTimeout(resolve, 1_000));
        }

        const liveNotified = checks
            .filter(item => item.status === "live_notified")
            .map(item => item.username);
        const offline = checks
            .filter(item => item.status === "offline")
            .map(item => item.username);
        const unknown = checks
            .filter(item => item.status === "unknown")
            .map(item => item.username);

        let content =
            `✅ **${result.added.length} compte(s) ajouté(s)**\n` +
            (
                result.added.length
                    ? result.added
                          .map(username => `• @${username}`)
                          .join("\n")
                    : "Aucun nouveau compte."
            );

        if (liveNotified.length) {
            content +=
                `\n\n🔴 **Déjà en LIVE — notification envoyée immédiatement :**\n` +
                liveNotified.map(username => `• @${username}`).join("\n");
        }

        if (offline.length) {
            content +=
                `\n\n⚫ **Hors live actuellement :**\n` +
                offline.map(username => `• @${username}`).join("\n");
        }

        if (unknown.length) {
            content +=
                `\n\n🟠 **Vérification TikTok indéterminée (surveillance activée) :**\n` +
                unknown.map(username => `• @${username}`).join("\n");
        }

        if (result.duplicates.length) {
            content +=
                `\n\n⚠️ **Déjà enregistrés :**\n` +
                result.duplicates.map(username => `• @${username}`).join("\n");
        }

        return interaction.editReply({
            content,
            allowedMentions: { parse: [] }
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId === "tiktok:list"
    ) {
        const accounts = TikTokAccountManager.listAll(
            interaction.guild.id
        );

        if (accounts.length === 0) {
            return interaction.reply({
                content: "📭 Aucun compte TikTok surveillé.",
                ephemeral: true
            });
        }

        const settings = ConfigManager.get(interaction.guild.id);
        const description = accounts
            .map((account, index) => {
                const status = account.enabled ? "🟢" : "⚫";
                const channel = account.notifyChannelId
                    ? `<#${account.notifyChannelId}>`
                    : settings.notifyChannelId
                        ? `<#${settings.notifyChannelId}> *(défaut)*`
                        : "Aucun salon";
                const role = account.pingRoleId
                    ? `<@&${account.pingRoleId}>`
                    : settings.pingRoleId
                        ? `<@&${settings.pingRoleId}> *(défaut)*`
                        : "Aucun rôle";
                return `**${index + 1}.** ${status} @${account.username}\n↳ 📢 ${channel} • 🔔 ${role}`;
            })
            .join("\n\n")
            .slice(0, 4000);

        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor(0xff0050)
                    .setTitle("📱 Comptes TikTok surveillés")
                    .setDescription(description)
                    .setFooter({
                        text: `${accounts.length} compte${
                            accounts.length > 1 ? "s" : ""
                        }`
                    })
            ],
            ephemeral: true
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId === "tiktok:lives"
    ) {
        const accounts = TikTokAccountManager.list(
            interaction.guild.id
        );

        if (accounts.length === 0) {
            return interaction.reply({
                content: "📭 Aucun compte TikTok surveillé.",
                ephemeral: true
            });
        }

        // V5 : cette « page » privée vérifie les comptes surveillés au moment du clic
        // afin d'afficher uniquement les lives réellement actifs.
        await interaction.deferReply({ ephemeral: true });

        const liveAccounts = [];
        const unknownAccounts = [];

        for (const username of accounts) {
            try {
                const state = await liveManager.getLiveState(username);

                if (state === true) {
                    liveAccounts.push(username);
                } else if (state === null) {
                    unknownAccounts.push(username);
                }
            } catch (error) {
                console.error(
                    `❌ Impossible de vérifier @${username} depuis la page des lives :`,
                    error
                );
                unknownAccounts.push(username);
            }

            // Évite d'envoyer trop de requêtes rapprochées à TikTok.
            await new Promise(resolve => setTimeout(resolve, 750));
        }

        const embeds = [];

        if (liveAccounts.length === 0) {
            embeds.push(
                new EmbedBuilder()
                    .setColor(0x8b5cf6)
                    .setTitle("🟣 Lives TikTok en cours")
                    .setDescription(
                        "⚫ **Aucun des comptes surveillés n'est actuellement en live.**"
                    )
                    .setFooter({
                        text: `${accounts.length} compte${accounts.length > 1 ? "s" : ""} vérifié${accounts.length > 1 ? "s" : ""}`
                    })
                    .setTimestamp()
            );
        } else {
            const pageSize = 20;

            for (let i = 0; i < liveAccounts.length; i += pageSize) {
                const page = liveAccounts.slice(i, i + pageSize);
                const pageNumber = Math.floor(i / pageSize) + 1;
                const totalPages = Math.ceil(liveAccounts.length / pageSize);

                embeds.push(
                    new EmbedBuilder()
                        .setColor(0x8b5cf6)
                        .setTitle(
                            totalPages > 1
                                ? `🟣 Lives TikTok en cours — ${pageNumber}/${totalPages}`
                                : "🟣 Lives TikTok en cours"
                        )
                        .setDescription(
                            page
                                .map(
                                    username =>
                                        `🔴 **[@${username}](https://www.tiktok.com/@${username}/live)** — [Regarder le live](https://www.tiktok.com/@${username}/live)`
                                )
                                .join("\n\n")
                        )
                        .setFooter({
                            text: `${liveAccounts.length} live${liveAccounts.length > 1 ? "s" : ""} actif${liveAccounts.length > 1 ? "s" : ""} sur ${accounts.length} compte${accounts.length > 1 ? "s" : ""} surveillé${accounts.length > 1 ? "s" : ""}`
                        })
                        .setTimestamp()
                );
            }
        }

        // Discord accepte jusqu'à 10 embeds par message. Dans le cas improbable
        // de plus de 200 lives simultanés, on garde les 10 premières pages.
        const visibleEmbeds = embeds.slice(0, 10);

        let note = "";
        if (unknownAccounts.length) {
            note =
                `\n🟠 ${unknownAccounts.length} compte${unknownAccounts.length > 1 ? "s" : ""} n'${unknownAccounts.length > 1 ? "ont" : "a"} pas pu être vérifié${unknownAccounts.length > 1 ? "s" : ""} par TikTok.`;
        }

        if (embeds.length > 10) {
            note +=
                `\n⚠️ La liste dépasse la limite Discord : ${liveAccounts.length - 200} live(s) supplémentaire(s) ne sont pas affichés.`;
        }

        const refreshButton = new ButtonBuilder()
            .setCustomId("tiktok:lives")
            .setLabel("Actualiser les lives")
            .setEmoji("🔄")
            .setStyle(ButtonStyle.Primary);

        return interaction.editReply({
            content: note || undefined,
            embeds: visibleEmbeds,
            components: [
                new ActionRowBuilder().addComponents(refreshButton)
            ],
            allowedMentions: { parse: [] }
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId === "tiktok:configure"
    ) {
        const accounts = TikTokAccountManager.listAll(interaction.guild.id);

        if (accounts.length === 0) {
            return interaction.reply({
                content: "📭 Ajoute d'abord un compte TikTok.",
                ephemeral: true
            });
        }

        const select = new StringSelectMenuBuilder()
            .setCustomId("tiktok:configure:select")
            .setPlaceholder("Choisis le compte à configurer")
            .addOptions(
                accounts.slice(0, 25).map(account => ({
                    label: `@${account.username}`.slice(0, 100),
                    value: account.username,
                    description: account.enabled ? "Notifications activées" : "Notifications désactivées"
                }))
            );

        return interaction.reply({
            content: accounts.length > 25
                ? "⚙️ Seuls les 25 premiers comptes sont affichés."
                : "⚙️ Choisis le compte TikTok à configurer :",
            components: [new ActionRowBuilder().addComponents(select)],
            ephemeral: true
        });
    }

    if (
        interaction.isStringSelectMenu() &&
        interaction.customId === "tiktok:configure:select"
    ) {
        const username = interaction.values[0];
        const account = TikTokAccountManager.get(interaction.guild.id, username);
        const defaults = ConfigManager.get(interaction.guild.id);

        if (!account) {
            return interaction.update({
                content: "❌ Ce compte n'existe plus.",
                components: []
            });
        }

        const effectiveChannel = account.notifyChannelId || defaults.notifyChannelId;
        const effectiveRole = account.pingRoleId || defaults.pingRoleId;

        const channelButton = new ButtonBuilder()
            .setCustomId(`tiktok:account:channel:${username}`)
            .setLabel("Choisir le salon")
            .setEmoji("📢")
            .setStyle(ButtonStyle.Primary);
        const roleButton = new ButtonBuilder()
            .setCustomId(`tiktok:account:role:${username}`)
            .setLabel("Choisir le rôle")
            .setEmoji("🔔")
            .setStyle(ButtonStyle.Primary);
        const imageButton = new ButtonBuilder()
            .setCustomId(`tiktok:account:image:${username}`)
            .setLabel("Photo de l'embed")
            .setEmoji("🖼️")
            .setStyle(ButtonStyle.Primary);
        const toggleButton = new ButtonBuilder()
            .setCustomId(`tiktok:account:toggle:${username}`)
            .setLabel(account.enabled ? "Désactiver" : "Activer")
            .setEmoji(account.enabled ? "⏸️" : "▶️")
            .setStyle(account.enabled ? ButtonStyle.Danger : ButtonStyle.Success);
        const defaultsButton = new ButtonBuilder()
            .setCustomId(`tiktok:account:defaults:${username}`)
            .setLabel("Utiliser les défauts")
            .setEmoji("↩️")
            .setStyle(ButtonStyle.Secondary);

        return interaction.update({
            content:
                `⚙️ **Configuration de @${username}**\n` +
                `**Statut :** ${account.enabled ? "🟢 Actif" : "⚫ Désactivé"}\n` +
                `**Salon :** ${account.notifyChannelId ? `<#${account.notifyChannelId}>` : effectiveChannel ? `<#${effectiveChannel}> *(défaut)*` : "Non configuré"}\n` +
                `**Rôle :** ${account.pingRoleId ? `<@&${account.pingRoleId}>` : effectiveRole ? `<@&${effectiveRole}> *(défaut)*` : "Aucun rôle"}\n` +
                `**Photo embed :** ${account.imageUrl ? "✅ Configurée" : "Aucune"}`,
            components: [
                new ActionRowBuilder().addComponents(channelButton, roleButton, imageButton),
                new ActionRowBuilder().addComponents(toggleButton, defaultsButton)
            ],
            allowedMentions: { parse: [] }
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId.startsWith("tiktok:account:channel:")
    ) {
        const username = interaction.customId.split(":").slice(3).join(":");
        const select = new ChannelSelectMenuBuilder()
            .setCustomId(`tiktok:account:channel:select:${username}`)
            .setPlaceholder(`Salon pour @${username}`.slice(0, 150))
            .setChannelTypes(ChannelType.GuildText)
            .setMinValues(1)
            .setMaxValues(1);

        return interaction.reply({
            content: `📢 Choisis le salon où **@${username}** enverra ses notifications :`,
            components: [new ActionRowBuilder().addComponents(select)],
            ephemeral: true
        });
    }

    if (
        interaction.isChannelSelectMenu() &&
        interaction.customId.startsWith("tiktok:account:channel:select:")
    ) {
        const username = interaction.customId.split(":").slice(4).join(":");
        const channelId = interaction.values[0];
        const updated = TikTokAccountManager.update(interaction.guild.id, username, {
            notifyChannelId: channelId
        });

        return interaction.update({
            content: updated
                ? `✅ **@${username}** enverra maintenant ses notifications dans <#${channelId}>.`
                : "❌ Ce compte n'existe plus.",
            components: [],
            allowedMentions: { parse: [] }
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId.startsWith("tiktok:account:role:")
    ) {
        const username = interaction.customId.split(":").slice(3).join(":");
        const select = new RoleSelectMenuBuilder()
            .setCustomId(`tiktok:account:role:select:${username}`)
            .setPlaceholder(`Rôle pour @${username}`.slice(0, 150))
            .setMinValues(1)
            .setMaxValues(1);
        const none = new ButtonBuilder()
            .setCustomId(`tiktok:account:role:none:${username}`)
            .setLabel("Aucun rôle")
            .setStyle(ButtonStyle.Secondary);

        return interaction.reply({
            content: `🔔 Choisis le rôle à mentionner pour **@${username}** :`,
            components: [
                new ActionRowBuilder().addComponents(select),
                new ActionRowBuilder().addComponents(none)
            ],
            ephemeral: true
        });
    }

    if (
        interaction.isRoleSelectMenu() &&
        interaction.customId.startsWith("tiktok:account:role:select:")
    ) {
        const username = interaction.customId.split(":").slice(4).join(":");
        const roleId = interaction.values[0];
        const updated = TikTokAccountManager.update(interaction.guild.id, username, {
            pingRoleId: roleId
        });

        return interaction.update({
            content: updated
                ? `✅ **@${username}** mentionnera maintenant <@&${roleId}>.`
                : "❌ Ce compte n'existe plus.",
            components: [],
            allowedMentions: { parse: [] }
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId.startsWith("tiktok:account:role:none:")
    ) {
        const username = interaction.customId.split(":").slice(4).join(":");
        const updated = TikTokAccountManager.update(interaction.guild.id, username, {
            pingRoleId: null
        });

        return interaction.update({
            content: updated
                ? `✅ Aucun rôle spécifique ne sera mentionné pour **@${username}**.`
                : "❌ Ce compte n'existe plus.",
            components: []
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId.startsWith("tiktok:account:image:")
    ) {
        const username = interaction.customId.split(":").slice(3).join(":");
        const account = TikTokAccountManager.get(interaction.guild.id, username);

        if (!account) {
            return interaction.reply({ content: "❌ Ce compte n'existe plus.", ephemeral: true });
        }

        const modal = new ModalBuilder()
            .setCustomId(`tiktok:account:image:modal:${username}`)
            .setTitle(`Photo de @${username}`.slice(0, 45));

        const input = new TextInputBuilder()
            .setCustomId("imageUrl")
            .setLabel("Lien direct de l'image")
            .setPlaceholder("https://.../photo.png (laisse vide pour retirer)")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMaxLength(1000);

        if (account.imageUrl) input.setValue(account.imageUrl.slice(0, 1000));

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
    }

    if (
        interaction.isModalSubmit() &&
        interaction.customId.startsWith("tiktok:account:image:modal:")
    ) {
        const username = interaction.customId.split(":").slice(5).join(":");
        const imageUrl = interaction.fields.getTextInputValue("imageUrl").trim();

        if (imageUrl) {
            let parsed;
            try {
                parsed = new URL(imageUrl);
            } catch {
                return interaction.reply({
                    content: "❌ Le lien de l'image n'est pas valide. Utilise une URL commençant par `https://`.",
                    ephemeral: true
                });
            }

            if (parsed.protocol !== "https:") {
                return interaction.reply({
                    content: "❌ L'image doit utiliser un lien sécurisé `https://`.",
                    ephemeral: true
                });
            }
        }

        const updated = TikTokAccountManager.update(interaction.guild.id, username, {
            imageUrl: imageUrl || null
        });

        return interaction.reply({
            content: updated
                ? imageUrl
                    ? `✅ Photo de l'embed configurée pour **@${username}**.`
                    : `✅ Photo de l'embed retirée pour **@${username}**.`
                : "❌ Ce compte n'existe plus.",
            ephemeral: true
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId.startsWith("tiktok:account:toggle:")
    ) {
        const username = interaction.customId.split(":").slice(3).join(":");
        const account = TikTokAccountManager.get(interaction.guild.id, username);
        if (!account) {
            return interaction.update({ content: "❌ Ce compte n'existe plus.", components: [] });
        }
        const updated = TikTokAccountManager.update(interaction.guild.id, username, {
            enabled: !account.enabled
        });
        return interaction.update({
            content: `${updated.enabled ? "▶️" : "⏸️"} Surveillance de **@${username}** ${updated.enabled ? "activée" : "désactivée"}.`,
            components: []
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId.startsWith("tiktok:account:defaults:")
    ) {
        const username = interaction.customId.split(":").slice(3).join(":");
        const updated = TikTokAccountManager.update(interaction.guild.id, username, {
            notifyChannelId: null,
            pingRoleId: null
        });
        return interaction.update({
            content: updated
                ? `↩️ **@${username}** utilise de nouveau le salon et le rôle par défaut de /setuptiktok.`
                : "❌ Ce compte n'existe plus.",
            components: []
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId === "tiktok:remove"
    ) {
        const accounts = TikTokAccountManager.listAll(
            interaction.guild.id
        );

        if (accounts.length === 0) {
            return interaction.reply({
                content: "📭 Aucun compte à supprimer.",
                ephemeral: true
            });
        }

        const select = new StringSelectMenuBuilder()
            .setCustomId("tiktok:remove:select")
            .setPlaceholder("Sélectionne un compte")
            .addOptions(
                accounts.slice(0, 25).map(account => ({
                    label: `@${account.username}`.slice(0, 100),
                    value: account.username,
                    description: account.enabled ? "Actif • Supprimer ce compte" : "Désactivé • Supprimer ce compte"
                }))
            );

        return interaction.reply({
            content:
                accounts.length > 25
                    ? "🗑️ Seuls les 25 premiers comptes sont affichés."
                    : "🗑️ Sélectionne le compte à supprimer :",
            components: [
                new ActionRowBuilder().addComponents(select)
            ],
            ephemeral: true
        });
    }

    if (
        interaction.isStringSelectMenu() &&
        interaction.customId === "tiktok:remove:select"
    ) {
        const username = interaction.values[0];

        TikTokAccountManager.remove(
            interaction.guild.id,
            username
        );

        return interaction.update({
            content: `🗑️ **@${username}** a été supprimé.`,
            components: []
        });
    }

    if (
        interaction.isButton() &&
        interaction.customId === "tiktok:refresh"
    ) {
        return interaction.update({
            embeds: [createSetupEmbed(interaction.guild.id)],
            components: createSetupButtons(),
            allowedMentions: { parse: [] }
        });
    }
}
