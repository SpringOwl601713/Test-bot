import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";

const dataDir = path.resolve("./data");
fs.mkdirSync(dataDir, { recursive: true });

// Node.js 22 inclut SQLite directement via node:sqlite.
// Aucun module natif externe (better-sqlite3) n'est nécessaire.
// Le même fichier serenity.sqlite est conservé, donc les données existantes
// restent utilisables si elles sont déjà présentes sur le serveur.
const db = new DatabaseSync(path.join(dataDir, "serenity.sqlite"));

db.exec("PRAGMA journal_mode = WAL;");
db.exec("PRAGMA foreign_keys = ON;");

db.exec(`
    CREATE TABLE IF NOT EXISTS guild_settings (
        guild_id TEXT PRIMARY KEY,
        notify_channel_id TEXT,
        ping_role_id TEXT,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    CREATE TABLE IF NOT EXISTS tiktok_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        username TEXT NOT NULL,
        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
        UNIQUE(guild_id, username)
    );

    CREATE INDEX IF NOT EXISTS idx_tiktok_accounts_guild
        ON tiktok_accounts(guild_id);

    CREATE TABLE IF NOT EXISTS youtube_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT NOT NULL, channel_name TEXT NOT NULL,
        youtube_channel_id TEXT NOT NULL, notify_channel_id TEXT NOT NULL, ping_role_id TEXT,
        embed_title TEXT, embed_description TEXT, embed_color TEXT NOT NULL DEFAULT 'FF0000',
        image_url TEXT, enabled INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL DEFAULT (unixepoch()),
        updated_at INTEGER NOT NULL DEFAULT (unixepoch()), UNIQUE(guild_id, channel_name)
    );
    CREATE INDEX IF NOT EXISTS idx_youtube_accounts_guild ON youtube_accounts(guild_id);

    CREATE TABLE IF NOT EXISTS twitch_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        login TEXT NOT NULL,
        twitch_user_id TEXT,
        notify_channel_id TEXT NOT NULL,
        ping_role_id TEXT,
        embed_title TEXT,
        embed_description TEXT,
        embed_color TEXT NOT NULL DEFAULT '9146FF',
        image_url TEXT,
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
        updated_at INTEGER NOT NULL DEFAULT (unixepoch()),
        UNIQUE(guild_id, login)
    );

    CREATE INDEX IF NOT EXISTS idx_twitch_accounts_guild
        ON twitch_accounts(guild_id);

    CREATE TABLE IF NOT EXISTS kick_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        slug TEXT NOT NULL,
        notify_channel_id TEXT NOT NULL,
        ping_role_id TEXT,
        embed_title TEXT,
        embed_description TEXT,
        embed_color TEXT NOT NULL DEFAULT '53FC18',
        image_url TEXT,
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
        updated_at INTEGER NOT NULL DEFAULT (unixepoch()),
        UNIQUE(guild_id, slug)
    );

    CREATE INDEX IF NOT EXISTS idx_kick_accounts_guild
        ON kick_accounts(guild_id);

    CREATE TABLE IF NOT EXISTS anti_piracy_settings (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER NOT NULL DEFAULT 1,
        channel_id TEXT NOT NULL,
        action TEXT NOT NULL DEFAULT 'ban',
        reason TEXT,
        embed_title TEXT,
        embed_description TEXT,
        embed_color TEXT NOT NULL DEFAULT 'EF4444',
        warning_message_id TEXT,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    CREATE TABLE IF NOT EXISTS role_react_panels (
        guild_id TEXT NOT NULL,
        target_message_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        menu_message_id TEXT NOT NULL,
        options_json TEXT NOT NULL DEFAULT '[]',
        updated_at INTEGER NOT NULL DEFAULT (unixepoch()),
        PRIMARY KEY (guild_id, target_message_id)
    );

    CREATE TABLE IF NOT EXISTS invite_logger_settings (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER NOT NULL DEFAULT 1,
        channel_id TEXT NOT NULL,
        welcome_message TEXT NOT NULL,
        leave_message TEXT NOT NULL,
        image_path TEXT,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    CREATE TABLE IF NOT EXISTS member_invite_history (
        guild_id TEXT NOT NULL,
        member_id TEXT NOT NULL,
        inviter_id TEXT,
        invite_code TEXT,
        invite_uses INTEGER NOT NULL DEFAULT 0,
        joined_at INTEGER NOT NULL DEFAULT (unixepoch()),
        PRIMARY KEY (guild_id, member_id)
    );

    CREATE TABLE IF NOT EXISTS invite_stats_settings (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER NOT NULL DEFAULT 1,
        channel_id TEXT NOT NULL,
        embed_title TEXT,
        embed_description TEXT,
        image_path TEXT,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    CREATE TABLE IF NOT EXISTS inviter_stats (
        guild_id TEXT NOT NULL,
        inviter_id TEXT NOT NULL,
        joins INTEGER NOT NULL DEFAULT 0,
        leaves INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch()),
        PRIMARY KEY (guild_id, inviter_id)
    );

    CREATE TABLE IF NOT EXISTS invite_stats_member_history (
        guild_id TEXT NOT NULL,
        member_id TEXT NOT NULL,
        inviter_id TEXT,
        invite_code TEXT,
        joined_at INTEGER NOT NULL DEFAULT (unixepoch()),
        PRIMARY KEY (guild_id, member_id)
    );

    CREATE TABLE IF NOT EXISTS boost_settings (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER NOT NULL DEFAULT 1,
        channel_id TEXT NOT NULL,
        embed_title TEXT NOT NULL,
        embed_description TEXT NOT NULL,
        embed_color TEXT NOT NULL DEFAULT 'F47FFF',
        image_path TEXT,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    CREATE TABLE IF NOT EXISTS staff_effectif_settings (
        guild_id TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, channel_id TEXT NOT NULL,
        message_id TEXT, embed_title TEXT NOT NULL DEFAULT '👥 Équipe du Serveur',
        embed_description TEXT NOT NULL DEFAULT 'Voici l’équipe qui fait vivre **{serveur}** !',
        embed_color TEXT NOT NULL DEFAULT '5865F2', image_path TEXT, updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS staff_effectif_roles (
        guild_id TEXT NOT NULL, role_id TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, role_id)
    );

    CREATE TABLE IF NOT EXISTS counter_settings (
        guild_id TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, category_id TEXT NOT NULL,
        total_enabled INTEGER NOT NULL DEFAULT 1, members_enabled INTEGER NOT NULL DEFAULT 1, bots_enabled INTEGER NOT NULL DEFAULT 1,
        online_enabled INTEGER NOT NULL DEFAULT 1, offline_enabled INTEGER NOT NULL DEFAULT 1, datetime_enabled INTEGER NOT NULL DEFAULT 1,
        total_name TEXT NOT NULL DEFAULT '👥 Tous les membres: {valeur}', members_name TEXT NOT NULL DEFAULT '👤 Membres: {valeur}',
        bots_name TEXT NOT NULL DEFAULT '🤖 Bots: {valeur}', online_name TEXT NOT NULL DEFAULT '🟢 En ligne: {valeur}',
        offline_name TEXT NOT NULL DEFAULT '⚫ Hors ligne: {valeur}', datetime_name TEXT NOT NULL DEFAULT '🕐 {valeur}',
        total_channel_id TEXT, members_channel_id TEXT, bots_channel_id TEXT, online_channel_id TEXT, offline_channel_id TEXT, datetime_channel_id TEXT,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    CREATE TABLE IF NOT EXISTS ticket_panels (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        panel_name TEXT NOT NULL COLLATE NOCASE,
        enabled INTEGER NOT NULL DEFAULT 1,
        channel_id TEXT NOT NULL,
        category_id TEXT,
        message_id TEXT,
        embed_title TEXT NOT NULL DEFAULT '🎫 Support',
        embed_description TEXT NOT NULL DEFAULT 'Sélectionnez une catégorie pour ouvrir un ticket.',
        embed_color TEXT NOT NULL DEFAULT '5865F2',
        image_path TEXT,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch()),
        UNIQUE(guild_id, panel_name)
    );
    CREATE INDEX IF NOT EXISTS idx_ticket_panels_guild ON ticket_panels(guild_id);

    CREATE TABLE IF NOT EXISTS ticket_options (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        panel_id INTEGER NOT NULL,
        label TEXT NOT NULL COLLATE NOCASE,
        description TEXT,
        emoji TEXT,
        support_role_id TEXT,
        position INTEGER NOT NULL DEFAULT 0,
        UNIQUE(panel_id, label),
        FOREIGN KEY(panel_id) REFERENCES ticket_panels(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ticket_opened (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        panel_id INTEGER NOT NULL,
        option_id INTEGER NOT NULL,
        guild_id TEXT NOT NULL,
        channel_id TEXT NOT NULL UNIQUE,
        user_id TEXT NOT NULL,
        closed INTEGER NOT NULL DEFAULT 0,
        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
        closed_at INTEGER,
        FOREIGN KEY(panel_id) REFERENCES ticket_panels(id) ON DELETE CASCADE,
        FOREIGN KEY(option_id) REFERENCES ticket_options(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_ticket_opened_user ON ticket_opened(guild_id, user_id, closed);


    CREATE TABLE IF NOT EXISTS recovery_settings (
        guild_id TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, restore_roles INTEGER NOT NULL DEFAULT 1,
        restore_nickname INTEGER NOT NULL DEFAULT 1, dm_enabled INTEGER NOT NULL DEFAULT 1, channel_id TEXT,
        role_mode TEXT NOT NULL DEFAULT 'selected', embed_title TEXT NOT NULL DEFAULT '💾 Récupération terminée',
        embed_description TEXT NOT NULL DEFAULT 'Bienvenue {membre} !\nTes anciens rôles et/ou ton pseudo ont été récupérés.\n**Rôles restaurés :** {roles}\n**Pseudo restauré :** {pseudo}',
        embed_color TEXT NOT NULL DEFAULT 'EB126B', image_path TEXT, updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS recovery_allowed_roles (guild_id TEXT NOT NULL, role_id TEXT NOT NULL, PRIMARY KEY(guild_id, role_id));
    CREATE TABLE IF NOT EXISTS recovery_members (guild_id TEXT NOT NULL, user_id TEXT NOT NULL, roles_json TEXT NOT NULL DEFAULT '[]', nickname TEXT, saved_at INTEGER NOT NULL DEFAULT (unixepoch()), PRIMARY KEY(guild_id,user_id));

    CREATE TABLE IF NOT EXISTS server_log_settings (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER NOT NULL DEFAULT 1,
        category_id TEXT,
        moderation_channel_id TEXT,
        messages_channel_id TEXT,
        members_channel_id TEXT,
        voice_channel_id TEXT,
        server_channel_id TEXT,
        invites_channel_id TEXT,
        commands_channel_id TEXT,
        viewer_role_id TEXT,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
`);

// Migration tickets : salon de transcripts configurable par panneau.
const ticketPanelColumns = new Set(db.prepare("PRAGMA table_info(ticket_panels)").all().map(column => column.name));
if (!ticketPanelColumns.has("transcript_channel_id")) {
    db.exec("ALTER TABLE ticket_panels ADD COLUMN transcript_channel_id TEXT;");
}

// Migration V6.1 : configuration par compte TikTok, sans casser les anciennes données.
const accountColumns = new Set(
    db.prepare("PRAGMA table_info(tiktok_accounts)").all().map(column => column.name)
);

if (!accountColumns.has("enabled")) {
    db.exec("ALTER TABLE tiktok_accounts ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1;");
}
if (!accountColumns.has("notify_channel_id")) {
    db.exec("ALTER TABLE tiktok_accounts ADD COLUMN notify_channel_id TEXT;");
}
if (!accountColumns.has("ping_role_id")) {
    db.exec("ALTER TABLE tiktok_accounts ADD COLUMN ping_role_id TEXT;");
}
if (!accountColumns.has("image_url")) {
    db.exec("ALTER TABLE tiktok_accounts ADD COLUMN image_url TEXT;");
}

export default db;
