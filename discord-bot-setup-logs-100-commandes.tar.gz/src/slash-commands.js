import { legacySlashCommands } from "./legacy-slash-commands.js";
import {
    PermissionFlagsBits,
    SlashCommandBuilder
} from "discord.js";

export const slashCommands = [
    new SlashCommandBuilder()
        .setName("setuptiktok")
        .setDescription("Ouvre le panneau privé de configuration TikTok")
        .setDefaultMemberPermissions(
            PermissionFlagsBits.ManageGuild
        ),

    new SlashCommandBuilder()
        .setName("testtiktok")
        .setDescription("Vérifie si un compte TikTok est en direct")
        .addStringOption(option =>
            option
                .setName("pseudo")
                .setDescription("Pseudo TikTok à vérifier")
                .setRequired(true)
        )
        .setDefaultMemberPermissions(
            PermissionFlagsBits.ManageGuild
        ),

    new SlashCommandBuilder()
        .setName("lives")
        .setDescription("Ouvre la page des lives TikTok actuellement actifs")
        .setDefaultMemberPermissions(
            PermissionFlagsBits.ManageGuild
        ),

    new SlashCommandBuilder()
        .setName("activity")
        .setDescription("Change l'activité affichée par le bot")
        .addStringOption(option =>
            option
                .setName("type")
                .setDescription("Type d'activité")
                .setRequired(true)
                .addChoices(
                    { name: "Listen", value: "listen" },
                    { name: "Play", value: "play" },
                    { name: "Stream", value: "stream" },
                    { name: "Watch", value: "watch" },
                    { name: "Compet", value: "compet" },
                    { name: "Custom", value: "custom" },
                    { name: "Stop", value: "stop" }
                )
        )
        .addStringOption(option =>
            option
                .setName("texte")
                .setDescription("Texte de l'activité (facultatif)")
                .setRequired(false)
                .setMaxLength(128)
        )
        .addStringOption(option =>
            option
                .setName("url")
                .setDescription("Lien Twitch/YouTube pour Stream (facultatif hors Stream)")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(
            PermissionFlagsBits.ManageGuild
        ),

    new SlashCommandBuilder()
        .setName("règle")
        .setDescription("Publie le règlement avec un bouton de vérification")
        .addStringOption(option =>
            option.setName("titre").setDescription("Titre du règlement").setRequired(true).setMaxLength(256)
        )
        .addStringOption(option =>
            option.setName("description").setDescription("Description / règlement").setRequired(true).setMaxLength(4000)
        )
        .addRoleOption(option =>
            option.setName("role").setDescription("Rôle attribué après vérification").setRequired(true)
        )
        .addChannelOption(option =>
            option.setName("salon").setDescription("Salon où publier le règlement").addChannelTypes(0).setRequired(true)
        )
        .addAttachmentOption(option =>
            option.setName("banniere").setDescription("Bannière depuis ta galerie (facultatif)").setRequired(false)
        )
        .addStringOption(option =>
            option.setName("couleur").setDescription("Couleur HEX de l’embed, ex: 57F287").setRequired(false).setMaxLength(7)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("say")
        .setDescription("Fait envoyer un message par le bot avec image ou fichiers")
        .addStringOption(option =>
            option
                .setName("message")
                .setDescription("Message que le bot doit envoyer")
                .setRequired(true)
                .setMaxLength(2000)
        )
        .addChannelOption(option =>
            option
                .setName("salon")
                .setDescription("Salon où envoyer le message (par défaut : salon actuel)")
                .addChannelTypes(0)
                .setRequired(false)
        )
        .addAttachmentOption(option =>
            option
                .setName("image")
                .setDescription("Image facultative depuis ta galerie")
                .setRequired(false)
        )
        .addAttachmentOption(option =>
            option
                .setName("fichier1")
                .setDescription("Premier fichier facultatif")
                .setRequired(false)
        )
        .addAttachmentOption(option =>
            option
                .setName("fichier2")
                .setDescription("Deuxième fichier facultatif")
                .setRequired(false)
        )
        .addAttachmentOption(option =>
            option
                .setName("fichier3")
                .setDescription("Troisième fichier facultatif")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(
            PermissionFlagsBits.Administrator
        ),

    new SlashCommandBuilder()
        .setName("dmall")
        .setDescription("Envoie un message privé aux membres d’un rôle précis")
        .addRoleOption(option =>
            option
                .setName("role")
                .setDescription("Rôle dont les membres recevront le message privé")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("texte")
                .setDescription("Texte du message privé")
                .setRequired(true)
                .setMaxLength(4000)
        )
        .addAttachmentOption(option =>
            option
                .setName("image")
                .setDescription("Image facultative depuis ta galerie")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(
            PermissionFlagsBits.Administrator
        ),

    new SlashCommandBuilder()
        .setName("security")
        .setDescription("Protection anti-raid et verrouillage de sécurité du serveur")
        .addStringOption(option =>
            option
                .setName("action")
                .setDescription("Action de sécurité à effectuer")
                .setRequired(true)
                .addChoices(
                    { name: "Statut", value: "status" },
                    { name: "Activer anti-raid", value: "antiraid_on" },
                    { name: "Désactiver anti-raid", value: "antiraid_off" },
                    { name: "Lockdown", value: "lockdown" },
                    { name: "Déverrouiller", value: "unlock" }
                )
        )
        .addIntegerOption(option =>
            option
                .setName("seuil")
                .setDescription("Arrivées déclenchant l’anti-raid (3 à 30, défaut 6)")
                .setMinValue(3)
                .setMaxValue(30)
                .setRequired(false)
        )
        .addIntegerOption(option =>
            option
                .setName("fenetre")
                .setDescription("Fenêtre de détection en secondes (3 à 60, défaut 10)")
                .setMinValue(3)
                .setMaxValue(60)
                .setRequired(false)
        )
        .setDefaultMemberPermissions(
            PermissionFlagsBits.Administrator
        ),

    new SlashCommandBuilder()
        .setName("rolereact")
        .setDescription("Ajoute un rôle dans un menu lié à un message déjà posté")
        .addStringOption(option =>
            option
                .setName("message_id")
                .setDescription("ID du message auquel rattacher le menu de rôles")
                .setRequired(true)
        )
        .addRoleOption(option =>
            option
                .setName("role")
                .setDescription("Rôle donné/retiré quand le membre choisit cette option")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("nom")
                .setDescription("Nom affiché dans le menu")
                .setRequired(true)
                .setMaxLength(100)
        )
        .addStringOption(option =>
            option
                .setName("description")
                .setDescription("Petite description affichée sous le nom (facultatif)")
                .setRequired(false)
                .setMaxLength(100)
        )
        .addStringOption(option =>
            option
                .setName("emoji")
                .setDescription("Emoji affiché devant l’option, ex : 🛠️ (facultatif)")
                .setRequired(false)
                .setMaxLength(100)
        )
        .addChannelOption(option =>
            option
                .setName("salon")
                .setDescription("Salon du message (par défaut : salon actuel)")
                .addChannelTypes(0)
                .setRequired(false)
        )
        .setDefaultMemberPermissions(
            PermissionFlagsBits.ManageRoles
        ),

    new SlashCommandBuilder()
        .setName("twitch")
        .setDescription("Configure les notifications automatiques LIVE Twitch")
        .addStringOption(option =>
            option
                .setName("action")
                .setDescription("Action Twitch")
                .setRequired(true)
                .addChoices(
                    { name: "Configurer / modifier", value: "configure" },
                    { name: "Supprimer", value: "remove" },
                    { name: "Liste", value: "list" }
                )
        )
        .addStringOption(option =>
            option
                .setName("nom")
                .setDescription("Nom/pseudo Twitch, ex : zerator")
                .setRequired(false)
                .setMaxLength(50)
        )
        .addChannelOption(option =>
            option
                .setName("salon")
                .setDescription("Salon où envoyer les notifications Twitch")
                .addChannelTypes(0)
                .setRequired(false)
        )
        .addRoleOption(option =>
            option
                .setName("role")
                .setDescription("Rôle à mentionner lors du LIVE (facultatif)")
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("titre")
                .setDescription("Titre personnalisé de l'embed (variables : {name}, {title}, {game})")
                .setRequired(false)
                .setMaxLength(256)
        )
        .addStringOption(option =>
            option
                .setName("description")
                .setDescription("Description personnalisée de l'embed")
                .setRequired(false)
                .setMaxLength(2000)
        )
        .addStringOption(option =>
            option
                .setName("couleur")
                .setDescription("Couleur HEX de l'embed, ex : 9146FF")
                .setRequired(false)
                .setMaxLength(7)
        )
        .addAttachmentOption(option =>
            option
                .setName("image")
                .setDescription("Image personnalisée de l'embed depuis ta galerie")
                .setRequired(false)
        ),

    new SlashCommandBuilder()
        .setName("kicklive")
        .setDescription("Configure les notifications automatiques LIVE Kick")
        .addStringOption(option =>
            option
                .setName("action")
                .setDescription("Action Kick")
                .setRequired(true)
                .addChoices(
                    { name: "Configurer / modifier", value: "configure" },
                    { name: "Supprimer", value: "remove" },
                    { name: "Liste", value: "list" }
                )
        )
        .addStringOption(option =>
            option
                .setName("nom")
                .setDescription("Nom/pseudo Kick ou lien, ex : xqc")
                .setRequired(false)
                .setMaxLength(100)
        )
        .addChannelOption(option =>
            option
                .setName("salon")
                .setDescription("Salon où envoyer les notifications Kick")
                .addChannelTypes(0)
                .setRequired(false)
        )
        .addRoleOption(option =>
            option
                .setName("role")
                .setDescription("Rôle à mentionner lors du LIVE (facultatif)")
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("titre")
                .setDescription("Titre embed (variables : {name}, {title}, {category})")
                .setRequired(false)
                .setMaxLength(256)
        )
        .addStringOption(option =>
            option
                .setName("description")
                .setDescription("Description personnalisée de l'embed")
                .setRequired(false)
                .setMaxLength(2000)
        )
        .addStringOption(option =>
            option
                .setName("couleur")
                .setDescription("Couleur HEX de l'embed, ex : 53FC18")
                .setRequired(false)
                .setMaxLength(7)
        )
        .addAttachmentOption(option =>
            option
                .setName("image")
                .setDescription("Image personnalisée de l'embed depuis ta galerie")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("youtube")
        .setDescription("Configure les notifications automatiques LIVE YouTube")
        .addStringOption(o=>o.setName("action").setDescription("Action YouTube").setRequired(true).addChoices({name:"Configurer / modifier",value:"configure"},{name:"Supprimer",value:"remove"},{name:"Liste",value:"list"}))
        .addStringOption(o=>o.setName("nom").setDescription("Nom, @handle ou lien de la chaîne YouTube").setRequired(false).setMaxLength(150))
        .addChannelOption(o=>o.setName("salon").setDescription("Salon des notifications YouTube").addChannelTypes(0).setRequired(false))
        .addRoleOption(o=>o.setName("role").setDescription("Rôle à mentionner (facultatif)").setRequired(false))
        .addStringOption(o=>o.setName("titre").setDescription("Titre embed (variables : {name}, {title}, {url})").setRequired(false).setMaxLength(256))
        .addStringOption(o=>o.setName("description").setDescription("Description personnalisée de l'embed").setRequired(false).setMaxLength(2000))
        .addStringOption(o=>o.setName("couleur").setDescription("Couleur HEX, ex : FF0000").setRequired(false).setMaxLength(7))
        .addAttachmentOption(o=>o.setName("image").setDescription("Image personnalisée depuis ta galerie").setRequired(false))
        .setDefaultMemberPermissions(
            PermissionFlagsBits.Administrator
        ),


    new SlashCommandBuilder()
        .setName("invitelogger")
        .setDescription("Configure les messages automatiques d’arrivée et de départ")
        .addStringOption(option =>
            option
                .setName("action")
                .setDescription("Configurer, voir le statut ou désactiver")
                .setRequired(true)
                .addChoices(
                    { name: "Configurer / modifier", value: "configure" },
                    { name: "Statut", value: "status" },
                    { name: "Désactiver", value: "disable" }
                )
        )
        .addChannelOption(option =>
            option
                .setName("salon")
                .setDescription("Salon des messages d’arrivée et de départ")
                .addChannelTypes(0)
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("message_arrivee")
                .setDescription("Variables: {membre} {serveur} {inviteur} {invitations} {membres}")
                .setRequired(false)
                .setMaxLength(4000)
        )
        .addStringOption(option =>
            option
                .setName("message_depart")
                .setDescription("Variables: {membre} {serveur} {inviteur} {invitations} {membres}")
                .setRequired(false)
                .setMaxLength(4000)
        )
        .addAttachmentOption(option =>
            option
                .setName("image")
                .setDescription("Image / bannière depuis ta galerie (facultatif)")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("invites")
        .setDescription("Affiche et configure le compteur d’invitations du serveur")
        .addStringOption(option =>
            option
                .setName("action")
                .setDescription("Voir les invitations ou gérer le système")
                .setRequired(true)
                .addChoices(
                    { name: "Voir", value: "view" },
                    { name: "Configurer / modifier", value: "configure" },
                    { name: "Activer", value: "enable" },
                    { name: "Désactiver", value: "disable" },
                    { name: "Statut", value: "status" }
                )
        )
        .addUserOption(option =>
            option
                .setName("membre")
                .setDescription("Membre dont tu veux voir les invitations (par défaut : toi)")
                .setRequired(false)
        )
        .addChannelOption(option =>
            option
                .setName("salon")
                .setDescription("Salon où publier les résultats de /invites")
                .addChannelTypes(0)
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("titre")
                .setDescription("Titre personnalisé : {membre} {serveur} {invitations} {arrivees} {departs}")
                .setRequired(false)
                .setMaxLength(256)
        )
        .addStringOption(option =>
            option
                .setName("description")
                .setDescription("Texte personnalisé avec les mêmes variables")
                .setRequired(false)
                .setMaxLength(4000)
        )
        .addAttachmentOption(option =>
            option
                .setName("image")
                .setDescription("Image / bannière depuis ta galerie (facultatif)")
                .setRequired(false)
        ),

    new SlashCommandBuilder()
        .setName("setup-boost")
        .setDescription("Configure les remerciements automatiques des boosts")
        .addStringOption(option => option.setName("action").setDescription("Configurer, activer, désactiver ou voir le statut").setRequired(true).addChoices(
            { name: "Configurer / modifier", value: "configure" },
            { name: "Activer", value: "enable" },
            { name: "Désactiver", value: "disable" },
            { name: "Statut", value: "status" }
        ))
        .addChannelOption(option => option.setName("salon").setDescription("Salon où envoyer les remerciements de boost").addChannelTypes(0).setRequired(false))
        .addStringOption(option => option.setName("titre").setDescription("Titre. Variables : {membre} {serveur} {boosts} {niveau}").setRequired(false).setMaxLength(256))
        .addStringOption(option => option.setName("description").setDescription("Message. Variables : {membre} {serveur} {boosts} {niveau}").setRequired(false).setMaxLength(4000))
        .addStringOption(option => option.setName("couleur").setDescription("Couleur HEX de l’embed, ex : F47FFF").setRequired(false).setMaxLength(7))
        .addAttachmentOption(option => option.setName("image").setDescription("Image / bannière depuis ta galerie (facultatif)").setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("effectif")
        .setDescription("Configure l’effectif automatique du serveur")
        .addStringOption(o => o.setName("action").setDescription("Action à effectuer").setRequired(true).addChoices(
            { name: "Configurer / modifier", value: "configure" }, { name: "Ajouter un rôle", value: "add_role" },
            { name: "Retirer un rôle", value: "remove_role" }, { name: "Actualiser", value: "refresh" },
            { name: "Statut", value: "status" }, { name: "Désactiver", value: "disable" }
        ))
        .addChannelOption(o => o.setName("salon").setDescription("Salon où afficher l’effectif").addChannelTypes(0).setRequired(false))
        .addRoleOption(o => o.setName("role").setDescription("Rôle à ajouter ou retirer de l’effectif").setRequired(false))
        .addStringOption(o => o.setName("titre").setDescription("Titre de l’embed. Variables : {serveur} {membres}").setRequired(false).setMaxLength(256))
        .addStringOption(o => o.setName("description").setDescription("Description. Variables : {serveur} {membres}").setRequired(false).setMaxLength(3000))
        .addStringOption(o => o.setName("couleur").setDescription("Couleur HEX, ex : 5865F2").setRequired(false).setMaxLength(7))
        .addAttachmentOption(o => o.setName("image").setDescription("Bannière / image depuis ta galerie").setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("setupticket")
        .setDescription("Configure plusieurs panneaux de tickets avec catégories personnalisées")
        .addStringOption(o => o.setName("action").setDescription("Action à effectuer").setRequired(true).addChoices(
            { name: "Configurer / modifier un panneau", value: "configure" },
            { name: "Ajouter une demande", value: "add_option" },
            { name: "Retirer une demande", value: "remove_option" },
            { name: "Publier / actualiser", value: "publish" },
            { name: "Activer", value: "enable" },
            { name: "Désactiver", value: "disable" },
            { name: "Liste des panneaux", value: "list" },
            { name: "Supprimer un panneau", value: "delete" }
        ))
        .addStringOption(o => o.setName("panneau").setDescription("Nom interne du panneau, ex : support ou agence").setRequired(false).setMaxLength(50))
        .addChannelOption(o => o.setName("salon").setDescription("Salon où publier le panneau").addChannelTypes(0).setRequired(false))
        .addChannelOption(o => o.setName("categorie").setDescription("Catégorie Discord où créer les tickets").addChannelTypes(4).setRequired(false))
        .addChannelOption(o => o.setName("salon_transcript").setDescription("Salon où envoyer les transcripts à la fermeture").addChannelTypes(0).setRequired(false))
        .addStringOption(o => o.setName("titre").setDescription("Titre de l’embed du panneau").setRequired(false).setMaxLength(256))
        .addStringOption(o => o.setName("description").setDescription("Description du panneau").setRequired(false).setMaxLength(4000))
        .addStringOption(o => o.setName("couleur").setDescription("Couleur HEX, ex : 5865F2").setRequired(false).setMaxLength(7))
        .addAttachmentOption(o => o.setName("image").setDescription("Bannière / image depuis ta galerie").setRequired(false))
        .addStringOption(o => o.setName("demande").setDescription("Nom de la demande à ajouter/retirer").setRequired(false).setMaxLength(100))
        .addStringOption(o => o.setName("description_demande").setDescription("Description affichée sous la demande").setRequired(false).setMaxLength(100))
        .addStringOption(o => o.setName("emoji").setDescription("Emoji de la demande, ex : 👩‍💻").setRequired(false).setMaxLength(100))
        .addRoleOption(o => o.setName("role_support").setDescription("Rôle pouvant voir et répondre à cette demande").setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("config-counter")
        .setDescription("Configure les compteurs automatiques du serveur")
        .addStringOption(o => o.setName("action").setDescription("Configurer, actualiser, statut ou désactiver").setRequired(true).addChoices(
            { name: "Configurer / modifier", value: "configure" }, { name: "Actualiser", value: "refresh" },
            { name: "Statut", value: "status" }, { name: "Désactiver", value: "disable" }
        ))
        .addChannelOption(o => o.setName("categorie").setDescription("Catégorie où placer les compteurs (sinon créée automatiquement)").addChannelTypes(4).setRequired(false))
        .addBooleanOption(o => o.setName("tous_membres").setDescription("Afficher le nombre total de membres + bots").setRequired(false))
        .addBooleanOption(o => o.setName("membres").setDescription("Afficher le nombre de membres humains").setRequired(false))
        .addBooleanOption(o => o.setName("bots").setDescription("Afficher le nombre de bots").setRequired(false))
        .addBooleanOption(o => o.setName("en_ligne").setDescription("Afficher les membres humains en ligne").setRequired(false))
        .addBooleanOption(o => o.setName("hors_ligne").setDescription("Afficher les membres humains hors ligne").setRequired(false))
        .addBooleanOption(o => o.setName("date_heure").setDescription("Afficher la date et l’heure française").setRequired(false))
        .addStringOption(o => o.setName("nom_total").setDescription("Ex : 👥 Tous les membres: {valeur}").setRequired(false).setMaxLength(100))
        .addStringOption(o => o.setName("nom_membres").setDescription("Ex : 👤 Membres: {valeur}").setRequired(false).setMaxLength(100))
        .addStringOption(o => o.setName("nom_bots").setDescription("Ex : 🤖 Bots: {valeur}").setRequired(false).setMaxLength(100))
        .addStringOption(o => o.setName("nom_en_ligne").setDescription("Ex : 🟢 En ligne: {valeur}").setRequired(false).setMaxLength(100))
        .addStringOption(o => o.setName("nom_hors_ligne").setDescription("Ex : ⚫ Hors ligne: {valeur}").setRequired(false).setMaxLength(100))
        .addStringOption(o => o.setName("nom_date_heure").setDescription("Ex : 🕐 {valeur}").setRequired(false).setMaxLength(100))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("stats-invite")
        .setDescription("Affiche le classement des invitations du serveur ou les statistiques d’un membre")
        .addUserOption(option =>
            option
                .setName("membre")
                .setDescription("Membre à afficher (facultatif : sans membre = classement général)")
                .setRequired(false)
        ),

    new SlashCommandBuilder()
        .setName("anti-piratage")
        .setDescription("Configure un salon piège anti-comptes piratés / arnaques")
        .addStringOption(option =>
            option
                .setName("action")
                .setDescription("Configurer, afficher le statut ou désactiver")
                .setRequired(true)
                .addChoices(
                    { name: "Configurer / modifier", value: "configure" },
                    { name: "Statut", value: "status" },
                    { name: "Désactiver", value: "disable" }
                )
        )
        .addChannelOption(option =>
            option
                .setName("salon")
                .setDescription("Salon piège à surveiller automatiquement")
                .addChannelTypes(0)
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("sanction")
                .setDescription("Sanction appliquée à tout membre non-admin qui écrit dans le salon")
                .setRequired(false)
                .addChoices(
                    { name: "Ban définitif", value: "ban" },
                    { name: "Exclure", value: "kick" },
                    { name: "Muet pendant 1 jour", value: "timeout_1d" }
                )
        )
        .addStringOption(option => option.setName("raison").setDescription("Raison de la sanction").setRequired(false).setMaxLength(400))
        .addStringOption(option => option.setName("titre").setDescription("Titre personnalisé de l'embed").setRequired(false).setMaxLength(256))
        .addStringOption(option => option.setName("texte").setDescription("Texte personnalisé de l'embed").setRequired(false).setMaxLength(4000))
        .addStringOption(option => option.setName("couleur").setDescription("Couleur HEX de l'embed, ex : EF4444").setRequired(false).setMaxLength(7))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("testnotification")
        .setDescription("Envoie une notification TikTok de test")
        .addStringOption(option =>
            option
                .setName("pseudo")
                .setDescription("Pseudo utilisé dans le test")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(
            PermissionFlagsBits.ManageGuild
        ),
    ...legacySlashCommands
];


// Commandes publiques supplémentaires
slashCommands.push(
    new SlashCommandBuilder()
        .setName("autorank")
        .setDescription("Remplir le formulaire d’autorank"),
    new SlashCommandBuilder()
        .setName("change")
        .setDescription("Modifie le pseudo d’un membre")
        .addUserOption(o => o.setName("membre").setDescription("Membre dont le pseudo doit être modifié").setRequired(true))
        .addStringOption(o => o.setName("pseudo").setDescription("Nouveau pseudo (32 caractères maximum)").setRequired(true).setMaxLength(32))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames),
    new SlashCommandBuilder()
        .setName("ping")
        .setDescription("Affiche les informations et la latence du bot en temps réel")
        .addAttachmentOption(o => o.setName("image").setDescription("Image ou bannière à afficher dans l’embed (facultatif)").setRequired(false))
    ,new SlashCommandBuilder()
        .setName("giveaway")
        .setDescription("Lance un giveaway personnalisé")
        .addStringOption(o => o.setName("durée").setDescription("Ex: 30s, 10m, 2h, 3j").setRequired(true))
        .addIntegerOption(o => o.setName("gagnants").setDescription("Nombre de gagnants").setMinValue(1).setMaxValue(20).setRequired(true))
        .addStringOption(o => o.setName("prix").setDescription("Prix à gagner").setMaxLength(200).setRequired(true))
        .addChannelOption(o => o.setName("salon").setDescription("Salon du giveaway (facultatif)").addChannelTypes(0).setRequired(false))
        .addStringOption(o => o.setName("texte").setDescription("Texte personnalisé dans l’embed").setMaxLength(1024).setRequired(false))
        .addAttachmentOption(o => o.setName("image").setDescription("Image/banner depuis ta galerie").setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder()
        .setName("giveaway-end")
        .setDescription("Termine immédiatement un giveaway")
        .addStringOption(o => o.setName("id").setDescription("ID du message giveaway").setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder()
        .setName("reroll")
        .setDescription("Retire au sort de nouveaux gagnants")
        .addStringOption(o => o.setName("id").setDescription("ID du message giveaway").setRequired(true))
        .addIntegerOption(o => o.setName("gagnants").setDescription("Nombre de nouveaux gagnants").setMinValue(1).setMaxValue(20).setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
,
    new SlashCommandBuilder()
        .setName("recuperation")
        .setDescription("Configure la sauvegarde et récupération automatique des rôles/pseudos")
        .addStringOption(o => o.setName("action").setDescription("Action à effectuer").setRequired(true).addChoices(
            {name:"Configurer / modifier",value:"configure"},{name:"Statut",value:"status"},{name:"Activer",value:"enable"},{name:"Désactiver",value:"disable"},{name:"Ajouter un rôle",value:"add_role"},{name:"Retirer un rôle",value:"remove_role"}
        ))
        .addChannelOption(o => o.setName("salon").setDescription("Salon où annoncer les récupérations").addChannelTypes(0).setRequired(false))
        .addBooleanOption(o => o.setName("roles").setDescription("Sauvegarder et redonner les rôles").setRequired(false))
        .addBooleanOption(o => o.setName("pseudo").setDescription("Sauvegarder et redonner le pseudo serveur").setRequired(false))
        .addBooleanOption(o => o.setName("dm").setDescription("Informer aussi le membre en message privé").setRequired(false))
        .addStringOption(o => o.setName("mode_roles").setDescription("Quels rôles sauvegarder").setRequired(false).addChoices({name:"Rôles sélectionnés",value:"selected"},{name:"Tous les rôles compatibles",value:"all"}))
        .addRoleOption(o => o.setName("role").setDescription("Rôle à ajouter/retirer de la liste de récupération").setRequired(false))
        .addStringOption(o => o.setName("titre").setDescription("Titre personnalisé de l’embed").setMaxLength(256).setRequired(false))
        .addStringOption(o => o.setName("description").setDescription("Texte personnalisé : {membre} {serveur} {roles} {pseudo}").setMaxLength(4000).setRequired(false))
        .addStringOption(o => o.setName("couleur").setDescription("Couleur HEX, ex : EB126B").setMaxLength(7).setRequired(false))
        .addAttachmentOption(o => o.setName("image").setDescription("Image/banner depuis ta galerie").setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    new SlashCommandBuilder()
        .setName("backup")
        .setDescription("Sauvegarde et restaure le serveur")
        .addSubcommand(s => s.setName("create").setDescription("Crée une sauvegarde du serveur").addStringOption(o=>o.setName("nom").setDescription("Nom du backup").setMaxLength(40)).addBooleanOption(o=>o.setName("messages").setDescription("Sauvegarder les messages (oui par défaut)")).addIntegerOption(o=>o.setName("limite_messages").setDescription("Maximum par salon (défaut 1000)").setMinValue(1).setMaxValue(10000)))
        .addSubcommand(s => s.setName("list").setDescription("Liste les sauvegardes du serveur"))
        .addSubcommand(s => s.setName("info").setDescription("Affiche le contenu d’une sauvegarde").addStringOption(o=>o.setName("id").setDescription("ID du backup").setRequired(true)))
        .addSubcommand(s => s.setName("delete").setDescription("Supprime une sauvegarde").addStringOption(o=>o.setName("id").setDescription("ID du backup").setRequired(true)))
        .addSubcommand(s => s.setName("load").setDescription("Restaure une sauvegarde (action sensible)").addStringOption(o=>o.setName("id").setDescription("ID du backup").setRequired(true)).addStringOption(o=>o.setName("confirmation").setDescription("Écris CONFIRMER pour lancer la restauration").setRequired(true)).addBooleanOption(o=>o.setName("roles").setDescription("Supprimer/recréer les rôles (défaut oui)")).addBooleanOption(o=>o.setName("salons").setDescription("Supprimer/recréer les salons (défaut oui)")).addBooleanOption(o=>o.setName("parametres").setDescription("Restaurer les paramètres (défaut oui)")).addBooleanOption(o=>o.setName("membres").setDescription("Restaurer rôles/pseudos des membres présents")).addBooleanOption(o=>o.setName("bans").setDescription("Restaurer les bannissements")).addBooleanOption(o=>o.setName("messages").setDescription("Republier les messages sauvegardés")))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("join")
        .setDescription("Fait rejoindre le bot dans un salon vocal")
        .addChannelOption(option =>
            option
                .setName("salon")
                .setDescription("Salon vocal que le bot doit rejoindre")
                .setRequired(true)
                .addChannelTypes(2, 13)
        ),
    new SlashCommandBuilder()
        .setName("leave")
        .setDescription("Fait quitter le salon vocal au bot"),

    new SlashCommandBuilder().setName("nrj").setDescription("Lance NRJ dans ton salon vocal"),
    new SlashCommandBuilder().setName("skyrock").setDescription("Lance Skyrock dans ton salon vocal"),
    new SlashCommandBuilder().setName("funradio").setDescription("Lance Fun Radio dans ton salon vocal"),
    new SlashCommandBuilder().setName("virginradio").setDescription("Lance Virgin Radio dans ton salon vocal"),
    new SlashCommandBuilder().setName("autoroute1077").setDescription("Lance la radio d’autoroute 107.7 dans ton salon vocal"),

    new SlashCommandBuilder()
        .setName("setup-logs")
        .setDescription("Configure automatiquement tous les logs du serveur")
        .addStringOption(o => o.setName("action").setDescription("Action à effectuer").setRequired(true).addChoices(
            { name: "Installer / réparer les logs", value: "setup" },
            { name: "Voir le statut", value: "status" },
            { name: "Désactiver les logs", value: "disable" },
            { name: "Réactiver les logs", value: "enable" },
            { name: "Envoyer un test", value: "test" }
        ))
        .addRoleOption(o => o.setName("role").setDescription("Rôle staff autorisé à voir les salons de logs").setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    new SlashCommandBuilder()
        .setName("language")
        .setDescription("Change la langue du bot pour ce serveur")
        .addStringOption(o => o.setName("action").setDescription("Action à effectuer").setRequired(true).addChoices(
            { name: "Changer la langue", value: "set" },
            { name: "Langue actuelle", value: "current" },
            { name: "Réinitialiser en français", value: "reset" }
        ))
        .addStringOption(o => o.setName("langue").setDescription("Recherche une langue par nom ou code").setRequired(false).setAutocomplete(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    new SlashCommandBuilder()
        .setName("help")
        .setDescription("Affiche le menu d’aide et toutes les commandes du bot"),
    new SlashCommandBuilder()
        .setName("clearall")
        .setDescription("Supprime tous les messages du salon après confirmation")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
);

export const slashCommandsJson = slashCommands.map(command => command.toJSON());
