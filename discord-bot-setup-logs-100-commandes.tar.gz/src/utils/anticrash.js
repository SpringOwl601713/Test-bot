export function installAntiCrash(client) {
    client.on("error", err => console.error("❌ Erreur Discord non capturée :", err));
    process.on("uncaughtExceptionMonitor", (err, origin) => console.error("❌ uncaughtExceptionMonitor", origin, err));
    process.on("rejectionHandled", promise => console.warn("⚠️ Rejection handled tardivement :", promise));
    process.on("warning", warning => console.warn("⚠️ Node warning :", warning));
    process.on("uncaughtException", error => console.error("❌ Erreur non interceptée :", error));
    process.on("unhandledRejection", reason => console.error("❌ Promesse non gérée :", reason));
    process.on("exit", code => console.log(`ℹ️ Processus terminé avec le code ${code}`));
}
