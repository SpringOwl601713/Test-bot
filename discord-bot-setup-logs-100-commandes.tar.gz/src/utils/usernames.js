export function cleanUsername(value) {
    if (!value) return "";

    return value
        .trim()
        .replace(/^https?:\/\/(www\.)?tiktok\.com\/@/i, "")
        .replace(/\/live\/?$/i, "")
        .replace(/^@/, "")
        .replace(/[/?#].*$/, "")
        .toLowerCase();
}

export function isValidUsername(username) {
    return /^[a-z0-9._]{2,24}$/i.test(username);
}

export function parseUsernames(value) {
    return [
        ...new Set(
            value
                .split(/[\n,; ]+/)
                .map(cleanUsername)
                .filter(Boolean)
                .filter(isValidUsername)
        )
    ];
}
