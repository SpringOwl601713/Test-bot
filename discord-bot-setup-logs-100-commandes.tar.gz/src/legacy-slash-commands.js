import { ChannelType, PermissionFlagsBits, SlashCommandBuilder } from "discord.js";

const A = PermissionFlagsBits.Administrator;
const M = PermissionFlagsBits.ManageGuild;
const MM = PermissionFlagsBits.ManageMessages;
const MR = PermissionFlagsBits.ManageRoles;

const base = (name, description, perms = A) => {
    const b = new SlashCommandBuilder().setName(name).setDescription(description.slice(0, 100));
    if (perms !== null) b.setDefaultMemberPermissions(perms);
    return b;
};
const user = (b, required = true, name = "membre") => b.addUserOption(o => o.setName(name).setDescription("Membre concerné").setRequired(required));
const role = (b, required = true, name = "role") => b.addRoleOption(o => o.setName(name).setDescription("Rôle concerné").setRequired(required));
const textChannel = (b, required = false, name = "salon") => b.addChannelOption(o => o.setName(name).setDescription("Salon concerné").addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement).setRequired(required));
const onoff = b => b.addStringOption(o => o.setName("etat").setDescription("Activer ou désactiver").setRequired(true).addChoices({name:"Activer",value:"on"},{name:"Désactiver",value:"off"}));

export const legacySlashCommands = [
    role(user(base("addrole", "Ajoute un rôle à un membre", MR)), true),
    base("alladmins", "Affiche la liste des administrateurs", null),
    base("allbans", "Affiche la liste des membres bannis", null),
    base("allbots", "Affiche la liste des bots du serveur", null),
    onoff(base("antiban", "Active ou désactive l'anti-ban")),
    onoff(base("antibot", "Active ou désactive l'anti-bot")),
    onoff(base("antichannel", "Active ou désactive l'anti-salon")),
    onoff(base("antieveryone", "Active ou désactive l'anti-everyone")),
    onoff(base("antilink", "Active ou désactive l'anti-liens")).addStringOption(o=>o.setName("type").setDescription("Type de liens bloqués").setRequired(false).addChoices({name:"Tous les liens",value:"all"},{name:"Invitations Discord",value:"invite"})),
    onoff(base("antirole", "Active ou désactive l'anti-rôle")),
    onoff(base("antispam", "Configure l'anti-spam")).addIntegerOption(o=>o.setName("messages").setDescription("Nombre de messages").setMinValue(2).setMaxValue(20)).addIntegerOption(o=>o.setName("secondes").setDescription("Fenêtre en secondes").setMinValue(2).setMaxValue(60)).addIntegerOption(o=>o.setName("timeout_minutes").setDescription("Timeout en minutes").setMinValue(1).setMaxValue(10080)),
    onoff(base("antiupdate", "Active ou désactive l'anti-modification serveur")),
    onoff(base("antivanity", "Active ou désactive l'anti-vanity")),
    onoff(base("antiwebhook", "Active ou désactive l'anti-webhook")),
    user(base("ban", "Bannit un membre", PermissionFlagsBits.BanMembers), true).addStringOption(o=>o.setName("raison").setDescription("Raison du bannissement").setRequired(false).setMaxLength(500)),
    base("clear", "Supprime des messages du salon", MM).addIntegerOption(o=>o.setName("nombre").setDescription("Nombre de messages à supprimer").setRequired(true).setMinValue(1).setMaxValue(100)),
    user(base("delallsanction", "Supprime toutes les sanctions enregistrées d'un membre"), true),
    base("delcommand", "Retire une règle de permission d'une commande").addStringOption(o=>o.setName("commande").setDescription("Nom de la commande").setRequired(true)).addRoleOption(o=>o.setName("role").setDescription("Rôle concerné (facultatif)")),
    base("delperm", "Retire une permission de commande à un rôle").addRoleOption(o=>o.setName("role").setDescription("Rôle concerné").setRequired(true)).addStringOption(o=>o.setName("commande").setDescription("Commande concernée").setRequired(true)),
    role(user(base("delrole", "Retire un rôle à un membre", MR)), true),
    user(base("delsanction", "Supprime une sanction enregistrée d'un membre"), true).addIntegerOption(o=>o.setName("numero").setDescription("Numéro de la sanction").setRequired(true).setMinValue(1)),
    user(base("derank", "Retire les rôles attribuables d'un membre", MR), true).addStringOption(o=>o.setName("raison").setDescription("Raison").setRequired(false)),
    base("emoji", "Ajoute un emoji personnalisé depuis un emoji ou une image").addStringOption(o=>o.setName("emoji").setDescription("Emoji custom à copier, ex: <:nom:id>").setRequired(false)).addAttachmentOption(o=>o.setName("image").setDescription("Image depuis la galerie").setRequired(false)).addStringOption(o=>o.setName("nom").setDescription("Nom du nouvel emoji").setRequired(false)),
    base("gend", "Termine un giveaway").addStringOption(o=>o.setName("message_id").setDescription("ID du message du giveaway").setRequired(true)),
    base("ghostping", "Configure les salons surveillés pour les ghostpings").addStringOption(o=>o.setName("salons").setDescription("IDs/mentions séparés par des virgules").setRequired(true)),
    base("greroll", "Choisit un nouveau gagnant d'un giveaway").addStringOption(o=>o.setName("message_id").setDescription("ID du giveaway").setRequired(true)),
    base("gstart", "Démarre un giveaway").addStringOption(o=>o.setName("duree").setDescription("Durée: 30s, 10m, 2h, 1d").setRequired(true)).addIntegerOption(o=>o.setName("gagnants").setDescription("Nombre de gagnants").setRequired(true).setMinValue(1).setMaxValue(20)).addStringOption(o=>o.setName("prix").setDescription("Prix à gagner").setRequired(true).setMaxLength(500)).addChannelOption(o=>o.setName("salon").setDescription("Salon du giveaway").addChannelTypes(ChannelType.GuildText).setRequired(false)),
    user(base("kick", "Expulse un membre", PermissionFlagsBits.KickMembers), true).addStringOption(o=>o.setName("raison").setDescription("Raison").setRequired(false)),
    textChannel(base("lock", "Verrouille un salon", M), false),
    user(base("mute", "Met un membre en timeout", PermissionFlagsBits.ModerateMembers), true).addStringOption(o=>o.setName("duree").setDescription("Durée: 10m, 1h, 1d").setRequired(true)).addStringOption(o=>o.setName("raison").setDescription("Raison").setRequired(false)),
    base("owner", "Affiche les owners enregistrés"),
    base("perms", "Affiche les permissions des commandes importées"),
    textChannel(base("renew", "Recrée un salon texte", M), false),
    role(base("roleinfo", "Affiche les informations d'un rôle", null), true),
    role(base("rolemembers", "Affiche les membres ayant un rôle", null), true),
    user(base("sanction", "Affiche les sanctions d'un membre", null), false),
    base("serverbanner", "Affiche la bannière du serveur", null),
    base("serverinfo", "Affiche les informations du serveur", null),
    base("setcolor", "Change la couleur par défaut des embeds importés").addStringOption(o=>o.setName("couleur").setDescription("HEX, ex: 5865F2").setRequired(true)),
    base("setcommand", "Configure l'accès à une commande importée").addStringOption(o=>o.setName("commande").setDescription("Nom de la commande").setRequired(true)).addStringOption(o=>o.setName("acces").setDescription("Accès").setRequired(true).addChoices({name:"Public",value:"public"},{name:"Administrateur",value:"admin"})).addRoleOption(o=>o.setName("role").setDescription("Rôle autorisé en plus (facultatif)")),
    base("setconfess", "Configure le salon des confessions").addBooleanOption(o=>o.setName("actif").setDescription("Activer/désactiver").setRequired(true)).addChannelOption(o=>o.setName("salon").setDescription("Salon concerné").addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement).setRequired(false)),
    user(base("setowner", "Ajoute un owner aux commandes importées"), true),
    base("setperm", "Autorise un rôle à utiliser une commande importée").addRoleOption(o=>o.setName("role").setDescription("Rôle autorisé").setRequired(true)).addStringOption(o=>o.setName("commande").setDescription("Commande autorisée").setRequired(true)),
    onoff(base("setpublic", "Active ou désactive le mode public des commandes importées")),
    base("setsuggest", "Configure le salon des suggestions").addBooleanOption(o=>o.setName("actif").setDescription("Activer/désactiver").setRequired(true)).addChannelOption(o=>o.setName("salon").setDescription("Salon concerné").addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement).setRequired(false)),
    base("snipe", "Affiche le dernier message supprimé du salon", null),
    base("soutien", "Configure un rôle et un texte de soutien").addStringOption(o=>o.setName("action").setDescription("Action").setRequired(true).addChoices({name:"Configurer",value:"set"},{name:"Désactiver",value:"clear"})).addRoleOption(o=>o.setName("role").setDescription("Rôle de soutien")).addStringOption(o=>o.setName("texte").setDescription("Texte de soutien")),
    base("tempvoc", "Configure les salons vocaux temporaires").addStringOption(o=>o.setName("action").setDescription("Action").setRequired(true).addChoices({name:"Activer",value:"on"},{name:"Désactiver",value:"off"})).addChannelOption(o=>o.setName("salon").setDescription("Salon vocal déclencheur").addChannelTypes(ChannelType.GuildVoice)).addChannelOption(o=>o.setName("categorie").setDescription("Catégorie de création").addChannelTypes(ChannelType.GuildCategory)),
    base("unban", "Débannit un utilisateur", PermissionFlagsBits.BanMembers).addStringOption(o=>o.setName("user_id").setDescription("ID de l’utilisateur banni").setRequired(true)),
    textChannel(base("unlock", "Déverrouille un salon", M), false),
    user(base("unmute", "Retire le timeout d'un membre", PermissionFlagsBits.ModerateMembers), true),
    user(base("unowner", "Retire un owner des commandes importées"), true),
    user(base("unwhitelist", "Retire un membre de la whitelist importée"), true),
    user(base("userinfo", "Affiche les informations d'un membre", null), false),
    base("variable", "Affiche les variables disponibles pour les messages", null),
    base("vc", "Affiche les statistiques vocales du serveur", null),
    user(base("vmute", "Rend muet un membre en vocal", PermissionFlagsBits.MuteMembers), true).addStringOption(o=>o.setName("duree").setDescription("Durée indicative: 10m, 1h, 1d").setRequired(false)).addStringOption(o=>o.setName("raison").setDescription("Raison").setRequired(false)),
    user(base("voicemove", "Déplace un membre dans ton salon vocal", PermissionFlagsBits.MoveMembers), true),
    user(base("warn", "Ajoute un avertissement à un membre", M), true).addStringOption(o=>o.setName("raison").setDescription("Raison de l'avertissement").setRequired(true).setMaxLength(500)),
    user(base("whitelist", "Ajoute un membre à la whitelist des commandes importées"), true)
];

export const legacySlashCommandNames = new Set(legacySlashCommands.map(command => command.name));
