import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder
} from "discord.js";
import { ConfigManager } from "../managers/ConfigManager.js";
import { TikTokAccountManager } from "../managers/TikTokAccountManager.js";

export function createSetupEmbed(guildId) {
    const settings = ConfigManager.get(guildId);
    const accounts = TikTokAccountManager.listAll(guildId);

    const preview =
        accounts.length === 0
            ? "Aucun compte enregistré."
            : accounts
                  .slice(0, 10)
                  .map(account => {
                      const status = account.enabled ? "🟢" : "⚫";
                      const channel = account.notifyChannelId
                          ? `<#${account.notifyChannelId}>`
                          : "défaut";
                      return `• ${status} @${account.username} → ${channel}`;
                  })
                  .join("\n") +
              (accounts.length > 10
                  ? `\n… et ${accounts.length - 10} autre(s).`
                  : "");

    return new EmbedBuilder()
        .setColor(0xff0050)
        .setTitle("Z7 KIRITO")
        .setDescription(
            "Configure les notifications TikTok depuis ce panneau privé.\n\n" +
            "Les réglages **globaux** restent les valeurs par défaut. Tu peux maintenant aussi attribuer un **salon, un rôle et un statut différents à chaque compte**."
        )
        .addFields(
            {
                name: "📢 Salon par défaut",
                value: settings.notifyChannelId
                    ? `<#${settings.notifyChannelId}>`
                    : "Non configuré",
                inline: true
            },
            {
                name: "🔔 Rôle par défaut",
                value: settings.pingRoleId
                    ? `<@&${settings.pingRoleId}>`
                    : "Aucun rôle",
                inline: true
            },
            {
                name: `👥 Comptes enregistrés : ${accounts.length}`,
                value: preview
            }
        )
        .setFooter({
            text: "Ce panneau est visible uniquement par toi."
        })
        .setTimestamp();
}

export function createSetupButtons() {
    return [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("tiktok:channel")
                .setLabel("Salon par défaut")
                .setEmoji("📢")
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId("tiktok:role")
                .setLabel("Rôle par défaut")
                .setEmoji("🔔")
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId("tiktok:add")
                .setLabel("Ajouter des comptes")
                .setEmoji("➕")
                .setStyle(ButtonStyle.Success)
        ),
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("tiktok:configure")
                .setLabel("Configurer un compte")
                .setEmoji("⚙️")
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId("tiktok:list")
                .setLabel("Voir la liste")
                .setEmoji("📋")
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId("tiktok:remove")
                .setLabel("Supprimer")
                .setEmoji("🗑️")
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId("tiktok:refresh")
                .setLabel("Actualiser")
                .setEmoji("🔄")
                .setStyle(ButtonStyle.Secondary)
        )
    ];
}
