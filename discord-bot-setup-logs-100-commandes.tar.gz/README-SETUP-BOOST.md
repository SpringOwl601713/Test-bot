# /setup-boost

Commande administrateur pour remercier automatiquement les membres lorsqu'ils commencent à booster le serveur.

Actions : Configurer / modifier, Activer, Désactiver, Statut.

Options de configuration : salon, titre, description, couleur HEX, image/bannière depuis la galerie.

Variables disponibles directement dans `titre` et `description` :
- `{membre}` : mention du booster
- `{serveur}` : nom du serveur
- `{boosts}` : nombre total de boosts
- `{niveau}` : niveau de boost du serveur

La configuration est sauvegardée dans SQLite et persiste après redémarrage.
