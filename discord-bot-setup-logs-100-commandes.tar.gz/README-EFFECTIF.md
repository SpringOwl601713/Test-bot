# /effectif

Commande administrateur pour afficher automatiquement l’effectif du serveur.

- Configurer / modifier : choisit le salon, le titre, la description, la couleur et une image depuis la galerie.
- Ajouter un rôle / Retirer un rôle : gère les rôles suivis.
- Actualiser : force la mise à jour.
- Statut / Désactiver.

Le bot modifie toujours le même message dès qu’un membre reçoit ou perd un rôle suivi. La configuration est persistante dans SQLite.
Variables : `{serveur}` et `{membres}`.
