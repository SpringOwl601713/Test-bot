# Fusion des deux archives de commandes

Cette version conserve toutes les fonctionnalités déjà présentes dans la V6 Nexora et ajoute les fichiers reçus dans `partie-handler.rar.zip` et `partie-assemblage.rar.zip`.

## Ce qui a été intégré

- Le handler anti-crash a été adapté au projet Node.js actuel (`src/utils/anticrash.js`).
- Les 60 anciennes commandes à préfixe ont été enregistrées en commandes slash `/` via `src/legacy-slash-commands.js`.
- Le gestionnaire de compatibilité se trouve dans `src/managers/LegacyCommandsManager.js`.
- Les sources originales JavaScript sont conservées dans `src/legacy-source/` pour référence, mais ne sont pas exécutées directement.

## Intents Discord

Comme certaines commandes importées utilisent le contenu des messages et les vocaux, active aussi dans le Developer Portal :

- Server Members Intent
- Presence Intent
- Message Content Intent

## À propos des protections legacy

Les fichiers fournis contenaient les commandes de configuration, mais pas tous les anciens fichiers d'événements/audit nécessaires à certaines protections. Les protections pouvant être reproduites sans ambiguïté (anti-liens, anti-spam, anti-everyone, anti-bot) sont actives. Les autres réglages anti-* sont conservés/configurables sans simuler une action destructive qui n'était pas définie dans les fichiers fournis.

## Démarrage

```bash
npm install
npm start
```

Les commandes slash sont resynchronisées automatiquement au démarrage.
