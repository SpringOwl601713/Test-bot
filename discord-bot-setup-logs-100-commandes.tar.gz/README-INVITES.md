# /invites — Compteur d'invitations

La commande `/invites` permet de suivre automatiquement les invitations Discord et d'afficher les statistiques d'un membre dans un salon configuré.

## Configuration administrateur

- `/invites action:Configurer / modifier salon:#invitations`
- Options facultatives : `image`, `titre`, `description`
- `/invites action:Activer`
- `/invites action:Désactiver`
- `/invites action:Statut`

Variables disponibles dans le titre et la description :

- `{membre}` : mention du membre
- `{serveur}` : nom du serveur
- `{invitations}` : invitations actives (arrivées - départs)
- `{arrivees}` : nombre de membres arrivés via ses invitations
- `{departs}` : nombre de ces membres qui ont quitté

## Consultation

`/invites action:Voir membre:@Utilisateur`

Le membre est facultatif : sans membre, la commande affiche les statistiques de la personne qui l'utilise. Le résultat est publié dans le salon choisi par l'administrateur.

Le bot doit avoir `Gérer le serveur` pour lire les invitations et `Server Members Intent` doit être activé.
