# /setup-logs — Logs automatiques du serveur

La commande `/setup-logs` crée et configure automatiquement une catégorie privée `📜・LOGS SERVEUR` avec 7 salons :

- `🛡️・moderation` : bans, débans, expulsions et actions de modération détectables.
- `💬・messages` : messages supprimés, modifiés et suppressions massives.
- `👥・membres` : arrivées, départs, rôles, pseudos et timeouts.
- `🔊・vocal` : connexions, déconnexions, déplacements et changements vocaux.
- `⚙️・serveur` : salons, rôles, emojis, stickers, webhooks, fils, événements et paramètres serveur.
- `🔗・invitations` : créations et suppressions d'invitations.
- `⌨️・commandes` : utilisation des commandes slash.

## Installation

Utilise `/setup-logs` avec l'action **Installer / réparer les logs**.
Tu peux fournir un rôle dans l'option `role` pour lui donner accès aux salons. Sans rôle, la catégorie reste privée ; les administrateurs Discord peuvent toujours la voir.

Autres actions : **Voir le statut**, **Désactiver les logs**, **Réactiver les logs**, **Envoyer un test**.

## Permissions recommandées pour le bot

Le bot doit notamment pouvoir gérer les salons, voir les Audit Logs, envoyer des messages et intégrer des liens. Pour obtenir le plus d'événements possible, les intents utilisés par le bot incluent aussi modération, membres, messages, vocal, invitations, expressions, webhooks et événements planifiés.

Discord ne fournit pas toujours le contenu d'un ancien message supprimé s'il n'était pas présent dans le cache du bot. De même, l'auteur exact d'une action n'est affiché que lorsque l'Audit Log Discord permet de l'identifier de façon fiable.
