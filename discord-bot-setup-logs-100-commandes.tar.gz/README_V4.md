# Nexora TikTok — V4

Cette V4 ajoute la vérification immédiate lors de l'ajout d'un compte TikTok.

- Si le compte ajouté est déjà LIVE, la notification Discord est envoyée immédiatement.
- Le cache est ensuite initialisé sur LIVE afin que le scan automatique ne renvoie pas la même notification.
- Si le compte est hors live, il est enregistré comme hors live et la surveillance continue normalement.
- Si TikTok ne permet pas de confirmer l'état, aucune fausse notification n'est envoyée et la surveillance reste active.
- Les protections V3 (validation du statut réel et anti-spam) sont conservées.
