# /config-counter

Commande administrateur pour créer et gérer des compteurs Discord sous forme de salons vocaux non rejoignables.

Compteurs disponibles :
- Tous les membres (humains + bots)
- Membres humains
- Bots
- Membres humains en ligne
- Membres humains hors ligne
- Date + heure française (Europe/Paris)

Actions : Configurer / modifier, Actualiser, Statut, Désactiver.

Chaque compteur peut être activé/désactivé et renommé. Utilisez `{valeur}` dans les noms personnalisés.
Si aucune catégorie n'est sélectionnée, le bot crée `📊・STATS DU SERVEUR`.

Important : activez **Server Members Intent** et **Presence Intent** dans Discord Developer Portal > Bot > Privileged Gateway Intents. Le bot doit aussi pouvoir gérer/créer des salons.

Les changements de membres/statuts déclenchent une mise à jour temporisée et un rafraîchissement périodique est effectué, afin de respecter les limites de renommage de salons de Discord.
