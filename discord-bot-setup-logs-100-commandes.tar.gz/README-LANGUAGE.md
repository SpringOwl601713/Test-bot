# /language — langues du bot

La commande `/language` permet de choisir la langue des réponses du bot pour chaque serveur.

## Utilisation

- `/language action:Changer la langue langue:<langue>`
- `/language action:Langue actuelle`
- `/language action:Réinitialiser en français`

Le champ `langue` utilise l'autocomplétion Discord et propose plus de 130 langues/codes.
Le choix est conservé dans SQLite (`language_settings`) après redémarrage.

## Portée

La couche de traduction est installée avant le traitement des interactions : elle s'applique donc aux réponses des commandes Slash existantes, y compris les commandes importées/legacy, ainsi qu'aux embeds, boutons, menus et modales envoyés pendant une interaction.

La traduction utilise le service public Google Translate au moment de la réponse. Si le service de traduction est temporairement inaccessible, le bot conserve automatiquement le texte français d'origine au lieu de faire échouer la commande.

Les noms des commandes Slash (`/kick`, `/help`, etc.) restent identiques afin de ne pas casser les commandes, permissions et habitudes existantes.
