# /recuperation

Configuration automatique de récupération des rôles et du pseudo lorsqu'un membre quitte puis revient sur le serveur.

- `action: Configurer / modifier` : active et configure le système.
- `action: Statut` : affiche la configuration.
- `action: Activer / Désactiver` : active ou suspend le système sans effacer les données.
- `action: Ajouter un rôle / Retirer un rôle` : gère les rôles utilisés avec le mode « Rôles sélectionnés ».
- `salon` : salon d'information au retour du membre.
- `roles`, `pseudo`, `dm` : options activables/désactivables.
- `mode_roles` : rôles sélectionnés ou tous les rôles compatibles.
- `image` : image/banner depuis la galerie, copiée localement dans `data/recovery-images`.
- Variables de texte : `{membre}`, `{serveur}`, `{roles}`, `{pseudo}`.

Sécurité Discord : les rôles gérés par Discord/intégrations, @everyone et les rôles au-dessus du rôle du bot ne sont jamais restaurés. Le bot doit disposer de Gérer les rôles et, pour le pseudo, Gérer les pseudos.
