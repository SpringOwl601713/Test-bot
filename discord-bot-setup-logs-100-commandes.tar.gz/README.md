# Serenity Discord Bot — ZenodeHost / Node.js 22

Bot Discord de notifications TikTok.

## Compatibilité

- Node.js 22.5 ou plus récent (branche 22)
- `better-sqlite3` a été supprimé
- La base utilise maintenant `node:sqlite`, intégré directement à Node.js 22
- Le fichier de base reste `data/serenity.sqlite`, donc une base existante peut être conservée

## Installation sur ZenodeHost

Supprime d'abord l'ancien dossier `node_modules` s'il existe, puis installe les dépendances :

```bash
rm -rf node_modules
npm install
```

Démarrage :

```bash
npm start
```

Pour enregistrer les commandes Slash :

```bash
npm run deploy
```

## Variables .env

Le projet charge automatiquement `.env` avec `dotenv/config`.

Variables utilisées :

```env
DISCORD_TOKEN=...
CLIENT_ID=...
CHECK_INTERVAL_SECONDS=30
```

Ne publie jamais ton token Discord.



Ajoute dans `.env` :

```env
```

- `PORT` : port HTTP écouté par le bot (sur certains hébergeurs, la variable `PORT` est fournie automatiquement).
- La commande `/lives` fournit un bouton Discord vers la page `/lives/<id_du_serveur>`.

### Limite Discord importante

Discord ne permet pas à un bot de remplacer la pastille de présence native du profil (verte/jaune/rouge/grise) par une pastille violette personnalisée, ni de rendre cette pastille cliquable vers une page arbitraire. La V6 utilise donc la solution prise en charge par Discord : une commande/bouton **🌐 Lives TikTok** ouvrant la page dédiée.

La commande `/lives` ouvre maintenant la page profil Nexora (`/nexora/<guildId>`), avec bannière, profil, onglets et lives TikTok actualisés toutes les 15 secondes.
Variables optionnelles :
- `DISCORD_INVITE_URL=https://discord.gg/ton-invitation`
