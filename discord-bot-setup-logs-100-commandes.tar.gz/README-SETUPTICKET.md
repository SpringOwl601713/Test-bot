# /setupticket — panneaux de tickets multiples

La commande `/setupticket` permet de créer plusieurs panneaux indépendants (par exemple `support`, `agence`, `partenariat`) dans des salons différents.

## Mise en place

1. `/setupticket action:Configurer / modifier un panneau panneau:support salon:#tickets categorie:Tickets titre:... description:... image:...`
2. Ajoute jusqu’à 25 demandes avec `action:Ajouter une demande`, en indiquant `demande`, `description_demande`, `emoji` et éventuellement `role_support`.
3. Lance `action:Publier / actualiser` pour poster le menu.

Quand un membre sélectionne une demande, un salon privé est créé automatiquement. Le membre, le bot et le rôle support choisi peuvent le voir. Un bouton rouge `🔒 Fermer le ticket` est ajouté dans le ticket.

## Plusieurs panneaux

Utilise simplement un nom `panneau` différent. Chaque panneau garde son propre salon, sa propre catégorie, son image et ses demandes.

## Permissions nécessaires au bot

- Gérer les salons
- Voir les salons
- Envoyer des messages
- Lire l’historique des messages
- Intégrer des liens / joindre des fichiers

`/setupticket` est réservé aux administrateurs. Les menus d’ouverture et les boutons de fermeture fonctionnent pour les membres autorisés.


## Transcripts automatiques
Lors de `Configurer / modifier un panneau`, renseigne `salon_transcript`. À la fermeture d’un ticket, le bot récupère l’historique avant suppression, crée un fichier HTML lisible (auteurs, dates, messages et liens vers les pièces jointes), puis l’envoie dans ce salon avec le panneau, la demande, l’auteur du ticket et la personne qui l’a fermé. Chaque panneau peut avoir son propre salon de transcripts.
