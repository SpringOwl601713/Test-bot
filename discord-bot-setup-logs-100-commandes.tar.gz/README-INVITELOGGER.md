# /invitelogger

Commande administrateur pour configurer les messages automatiques d’arrivée et de départ.

## Variables accessibles dans les textes

- `{membre}` : mention du membre qui rejoint/quitte
- `{serveur}` : nom du serveur Discord
- `{inviteur}` : membre ayant créé l’invitation détectée (ou « Invitation inconnue »)
- `{invitations}` : nombre d’utilisations du lien d’invitation détecté
- `{membres}` : nombre actuel de membres du serveur

## Exemple

`/invitelogger action:Configurer / modifier salon:#bienvenue message_arrivee:👋 Bienvenue {membre} sur {serveur} ! Tu as été invité par {inviteur} ({invitations} invitations). Nous sommes {membres}. message_depart:👋 {membre} vient de quitter {serveur}. Il avait été invité par {inviteur}. image:[image]`

La configuration est enregistrée dans SQLite et reste active après redémarrage.

Pour identifier l’inviteur, le bot doit avoir **Gérer le serveur** et le **Server Members Intent** doit être activé dans le Developer Portal.
