# Notifications Twitch — commande `/twitch`

La V6 peut maintenant surveiller automatiquement des chaînes Twitch et envoyer une notification Discord quand elles passent en LIVE.

## 1. Relier Twitch au bot

Crée une application Twitch dans la console développeur Twitch, puis récupère le **Client ID** et crée un **Client Secret**.

Dans `.env` :

```env
TWITCH_CLIENT_ID=TON_CLIENT_ID_TWITCH
TWITCH_CLIENT_SECRET=TON_CLIENT_SECRET_TWITCH
TWITCH_CHECK_INTERVAL_SECONDS=60
```

Ne partage jamais le Client Secret.

## 2. Configurer une chaîne

Exemple :

```text
/twitch action:Configurer / modifier nom:zerator salon:#lives-twitch role:@Twitch titre:🟣 {name} est en LIVE ! couleur:9146FF
```

Options disponibles :
- `nom` : pseudo/URL Twitch
- `salon` : salon de notification
- `role` : rôle à mentionner, facultatif
- `titre` : titre personnalisé de l'embed
- `description` : description personnalisée
- `couleur` : couleur HEX, ex. `9146FF`
- `image` : image facultative depuis la galerie

Variables utilisables dans le titre/description :
`{name}`, `{login}`, `{url}`, `{title}`, `{game}`, `{viewers}`.

Si aucune image personnalisée n'est fournie, le bot utilise automatiquement la miniature actuelle du stream Twitch et la photo de profil en miniature d'embed.

## 3. Gérer les chaînes

- `/twitch action:Liste`
- `/twitch action:Supprimer nom:pseudo`

Le bot vérifie Twitch automatiquement et n'envoie une nouvelle notification qu'au passage hors ligne → en ligne.

## Commande publique

La commande `/twitch` est publique : aucune permission Administrateur/Gérer le serveur n'est imposée par le bot pour ses actions Configurer / modifier, Supprimer et Liste. Les administrateurs Discord peuvent toujours restreindre la commande via Paramètres du serveur > Intégrations.
