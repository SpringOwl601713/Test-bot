# Commande /say

`/say` permet à un administrateur de faire envoyer un message par le bot.

Options :
- `message` : texte du message (obligatoire)
- `salon` : salon cible (facultatif, salon actuel par défaut)
- `image` : image depuis la galerie (facultatif)
- `fichier1`, `fichier2`, `fichier3` : fichiers supplémentaires facultatifs

Le bot affiche d'abord un aperçu privé avec **Envoyer** et **Annuler**. Seule la personne qui a lancé la commande peut confirmer. La commande est réservée aux administrateurs.
