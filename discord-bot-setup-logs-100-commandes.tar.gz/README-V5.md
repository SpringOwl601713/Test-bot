# Nexora TikTok Anti-Spam V5

Ajout V5 :
- Nouveau bouton violet **🟣 Lives en cours** dans `/setuptiktok`.
- Au clic, le bot ouvre une réponse privée séparée et revérifie tous les comptes TikTok surveillés.
- Seuls les comptes réellement détectés en LIVE sont affichés.
- Chaque compte en live contient un lien direct vers son live TikTok.
- Bouton **🔄 Actualiser les lives** sur cette page.
- Les comptes dont TikTok ne permet pas de confirmer l'état sont signalés séparément sans faux positif.

Les fonctions V4 restent présentes : notification immédiate à l'ajout d'un compte déjà en live, vérification renforcée et anti-spam.

Note : la liste concerne les comptes TikTok enregistrés dans le bot, pas l'ensemble des lives publics de toute la plateforme TikTok.
