# Commande /règle

Commande administrateur pour publier un règlement avec :
- titre et description personnalisés ;
- salon cible ;
- bannière facultative envoyée depuis la galerie ;
- couleur HEX facultative ;
- rôle de vérification ;
- bouton vert `✅ Se vérifier`.

Le bouton attribue le rôle sélectionné. Si le membre possède déjà le rôle, le bot répond qu'il est déjà vérifié sans le retirer.
Le bouton continue de fonctionner après un redémarrage car l'identifiant du rôle est inclus dans le composant Discord persistant.

Le bot doit avoir `Gérer les rôles` et son rôle doit être au-dessus du rôle de vérification.
