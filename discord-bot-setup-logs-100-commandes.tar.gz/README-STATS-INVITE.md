# /stats-invite

Commande publique de classement des invitations.

- `/stats-invite` : top 10 du serveur.
- `/stats-invite membre:@Utilisateur` : statistiques et position d’un membre.

Compteurs affichés : invitations réelles (total - départs), invitations totales observées / utilisations actuelles des liens, départs.
La commande réutilise les données de `/invites`. Le bot doit avoir **Gérer le serveur** pour lire les liens d’invitation Discord.
