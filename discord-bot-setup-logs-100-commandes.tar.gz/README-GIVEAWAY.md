# Giveaways Nexora

Commandes réservées aux membres avec la permission **Gérer le serveur** :

- `/giveaway durée gagnants prix [salon] [texte] [image]` : crée un giveaway avec bouton vert **🎉 Participer** et image facultative choisie depuis la galerie.
- `/giveaway-end id` : termine immédiatement un giveaway à partir de l'ID de son message.
- `/reroll id [gagnants]` : tire de nouveaux gagnants parmi les participants qui n'ont pas déjà gagné.

Durées acceptées : `30s`, `10m`, `2h`, `3j` (minimum 10 secondes, maximum 30 jours).

Les giveaways actifs sont enregistrés dans `data/giveaways.json` afin de survivre à un redémarrage du bot. Les membres peuvent cliquer une seconde fois sur le bouton pour retirer leur participation.
