# Installation Autorank

## autorank.js
Place-le par exemple dans :

```text
/home/container/autorank.js
```

Puis ajoute dans `index.js`, après la création de `client` et avant `client.login(...)` :

```js
require("./autorank.js")(client);
```

## deploy-autorank.js
Place-le à la racine :

```text
/home/container/deploy-autorank.js
```

Le `.env` doit contenir :

```env
DISCORD_TOKEN=
CLIENT_ID=
GUILD_ID=
```

Puis exécute une seule fois :

```bash
node deploy-autorank.js
```

## Configuration
Dans `autorank.js`, remplace :

```js
const ROLE_AUTORANK_VALIDATOR = "REMPLACE_PAR_ID_ROLE_VALIDATEUR";
```

par l'identifiant du rôle autorisé à valider/refuser.

Vérifie également tous les IDs de rôles et l'ID du salon de logs.
