# /rolereact

La commande `/rolereact` permet de rattacher un menu de rôles à un message Discord déjà publié.

Exemple :

`/rolereact message_id:123456789012345678 role:@Support nom:Support Technique description:Support aide ou questions techniques emoji:👩‍💻`

- `message_id` : ID du message déjà publié.
- `role` : rôle à ajouter/retirer.
- `nom` : texte affiché dans le menu.
- `description` : facultative.
- `emoji` : facultatif.
- `salon` : facultatif ; le salon courant est utilisé par défaut.

Le bot répond au message ciblé avec un menu `Sélectionnez une catégorie...`.
Relancer `/rolereact` avec le même `message_id` ajoute une nouvelle option au même menu, jusqu'à 25 options.
Quand un membre choisit une option, le rôle est ajouté ; s'il possède déjà le rôle, il est retiré.

Le bot doit avoir `Gérer les rôles`, `Voir le salon`, `Envoyer des messages` et `Lire l'historique des messages`. Son rôle Discord doit être placé au-dessus des rôles qu'il attribue.
