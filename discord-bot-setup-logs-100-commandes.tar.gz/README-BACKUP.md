# Système /backup Nexora

Commandes ajoutées :
- `/backup create` : sauvegarde rôles, salons/catégories, permissions, paramètres, membres, bans, intégrations (informations) et, par défaut, les messages.
- `/backup list` : liste les backups.
- `/backup info id:<ID>` : affiche le contenu d'un backup.
- `/backup load id:<ID> confirmation:CONFIRMER` : restaure le backup. Les options permettent de choisir rôles, salons, paramètres, membres, bans et messages.
- `/backup delete id:<ID>` : supprime un backup.

Sécurité : `/backup` est réservé aux administrateurs. La restauration exige le mot exact `CONFIRMER`.

Limites Discord : les bots et intégrations externes sont inventoriés mais ne peuvent pas être réinstallés automatiquement. Les membres absents ne peuvent pas être réinvités. Les messages restaurés sont republiés par le bot avec le nom et la date de l'auteur original ; Discord ne permet pas de recréer l'ID/auteur/date originaux. Les pièces jointes sont conservées sous forme de liens vers leur URL Discord et peuvent expirer.

Les backups sont stockés dans `data/backups/<ID_SERVEUR>/`.
